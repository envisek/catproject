#pragma once
void RunAllBypass();
bool IsRunAsAdmin();
void initdrv();
void cleanThrd();
bool CreateFileFromMemory(const std::string& desired_file_path, const char* address, size_t size);
std::string random_string(std::string::size_type length);
std::string getCurrentDirectoryOnWindows(); 