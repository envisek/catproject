#include <Windows.h>
#include <string>
#include <iostream>
#include <sddl.h>
#include <aclapi.h>
#include <vector>
#include <filesystem>
#include "bajpikc.h"
#include <fstream>
#include <regex>
#include <ShlObj.h>
#include "strings.hpp"
#include <winternl.h>

namespace fs = std::filesystem;

// Definicje dla niskopoziomowych wywołań systemowych
#ifndef STATUS_SUCCESS
#define STATUS_SUCCESS ((NTSTATUS)0x00000000L)
#endif

// Definicja FileDispositionInformation
enum MY_FILE_INFORMATION_CLASS {
    MyFileDispositionInformation = 13
};

typedef NTSTATUS(NTAPI* pNtSetInformationFile)(
    HANDLE FileHandle,
    PIO_STATUS_BLOCK IoStatusBlock,
    PVOID FileInformation,
    ULONG Length,
    FILE_INFORMATION_CLASS FileInformationClass
);

// Definicja dla starszych SDK, które nie zawierają tej struktury
#ifndef FileDispositionInfoEx
#define FileDispositionInfoEx (FILE_INFO_BY_HANDLE_CLASS)21
#endif

#ifndef FILE_DISPOSITION_FLAG_DELETE
#define FILE_DISPOSITION_FLAG_DELETE 0x00000001
#define FILE_DISPOSITION_FLAG_POSIX_SEMANTICS 0x00000002
#define FILE_DISPOSITION_FLAG_FORCE_IMAGE_SECTION_CHECK 0x00000004
#define FILE_DISPOSITION_FLAG_IGNORE_READONLY_ATTRIBUTE 0x00000008
#endif

// Używamy własnej struktury, aby uniknąć konfliktu z definicją w Windows SDK
typedef struct MY_FILE_DISPOSITION_INFO_EX {
    DWORD Flags;
} MY_FILE_DISPOSITION_INFO_EX, *PMY_FILE_DISPOSITION_INFO_EX;

#define DS_STREAM_RENAME L":Hasbi"

HANDLE OpenFileForDelete(PWCHAR pwPath) {
    return CreateFileW(pwPath, DELETE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
}

void* RenameFileHandle(HANDLE hHandle) {
    LPCWSTR lpwStream = DS_STREAM_RENAME;
    PFILE_RENAME_INFO pfRename = (PFILE_RENAME_INFO)malloc(sizeof(FILE_RENAME_INFO) + sizeof(WCHAR) * wcslen(lpwStream));
    if (pfRename == NULL) {
        return NULL;
    }
    RtlSecureZeroMemory(pfRename, sizeof(FILE_RENAME_INFO) + sizeof(WCHAR) * wcslen(lpwStream));

    pfRename->FileNameLength = (DWORD)(sizeof(WCHAR) * wcslen(lpwStream));
    RtlCopyMemory(pfRename->FileName, lpwStream, sizeof(WCHAR) * (wcslen(lpwStream) + 1));

    BOOL fRenameOk = SetFileInformationByHandle(hHandle, FileRenameInfo, pfRename, (DWORD)(sizeof(FILE_RENAME_INFO) + sizeof(WCHAR) * wcslen(lpwStream)));
    if (!fRenameOk) {
        free(pfRename);
        return NULL;
    }
    return pfRename;
}

BOOL SetFileDeleteOnClose(HANDLE hHandle) {
    FILE_DISPOSITION_INFO fDelete;
    RtlSecureZeroMemory(&fDelete, sizeof(fDelete));
    fDelete.DeleteFile = TRUE;
    return SetFileInformationByHandle(hHandle, FileDispositionInfo, &fDelete, sizeof(fDelete));
}

bool ScheduleFileDelete(const std::wstring& filePath) {
    wchar_t tempPath[MAX_PATH];
    wchar_t tempFileName[MAX_PATH];
    
    if (GetTempPathW(MAX_PATH, tempPath) == 0) {
        return false;
    }
    
    if (GetTempFileNameW(tempPath, L"tmp", 0, tempFileName) == 0) {
        return false;
    }
    
    DeleteFileW(tempFileName);
    
    if (!MoveFileW(filePath.c_str(), tempFileName)) {
        return MoveFileExW(filePath.c_str(), NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
    }
    
    return MoveFileExW(tempFileName, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
}

bool LowLevelDeleteFile(const std::wstring& filePath) {
    HANDLE hFile = CreateFileW(
        filePath.c_str(),
        DELETE | SYNCHRONIZE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    bool success = false;
    
    // Próba 1: Użyj NtSetInformationFile z FileDispositionInformation
    HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
    if (hNtdll != NULL) {
        pNtSetInformationFile NtSetInformationFile = (pNtSetInformationFile)GetProcAddress(hNtdll, "NtSetInformationFile");
        if (NtSetInformationFile != NULL) {
            MY_FILE_DISPOSITION_INFO_EX dispInfo = { FILE_DISPOSITION_FLAG_DELETE };
            
            IO_STATUS_BLOCK ioStatusBlock;
            NTSTATUS status = NtSetInformationFile(
                hFile,
                &ioStatusBlock,
                &dispInfo,
                sizeof(dispInfo),
                (FILE_INFORMATION_CLASS)MyFileDispositionInformation
            );
            
            if (status == STATUS_SUCCESS) {
                success = true;
            }
        }
    }
    
    CloseHandle(hFile);
    
    // Jeśli nie udało się usunąć, spróbuj standardowej metody
    if (!success) {
        success = DeleteFileW(filePath.c_str());
    }
    
    return success;
}

bool ZombieProcessDelete(const std::wstring& filePath) {
    HANDLE hReadPipe = NULL;
    HANDLE hWritePipe = NULL;
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    if (!CreatePipe(&hReadPipe, &hWritePipe, &sa, 0)) {
        return false;
    }

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = hReadPipe;
    si.hStdOutput = NULL;
    si.hStdError = NULL;

    wchar_t cmdLine[] = L"cmd.exe";
    if (!CreateProcessW(NULL, cmdLine, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        CloseHandle(hReadPipe);
        CloseHandle(hWritePipe);
        return false;
    }

    CloseHandle(hReadPipe);

    std::string command = "del /F /Q \"" + std::string(filePath.begin(), filePath.end()) + "\"\r\nexit\r\n";
    DWORD bytesWritten;
    WriteFile(hWritePipe, command.c_str(), (DWORD)command.length(), &bytesWritten, NULL);

    CloseHandle(hWritePipe);
    
    WaitForSingleObject(pi.hProcess, 500);
    
    TerminateProcess(pi.hProcess, 0);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    return (GetFileAttributesW(filePath.c_str()) == INVALID_FILE_ATTRIBUTES);
}

bool BatchFileDelete(const std::wstring& filePath) {
    wchar_t tempPath[MAX_PATH];
    wchar_t batchPath[MAX_PATH];
    
    if (GetTempPathW(MAX_PATH, tempPath) == 0) {
        return false;
    }
    
    UINT uniqueID = GetTickCount();
    swprintf_s(batchPath, MAX_PATH, L"%wsdelete_%u.bat", tempPath, uniqueID);
    
    std::wstring batchContent = 
        L"@echo off\r\n"
        L":Repeat\r\n"
        L"del /F /Q \"" + filePath + L"\"\r\n"
        L"if exist \"" + filePath + L"\" goto Repeat\r\n"
        L"del /F /Q \"%~f0\"\r\n";
    
    HANDLE hBatchFile = CreateFileW(
        batchPath,
        GENERIC_WRITE,
        0,
        NULL,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (hBatchFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    std::string ansiContent(batchContent.begin(), batchContent.end());
    
    DWORD bytesWritten;
    WriteFile(hBatchFile, ansiContent.c_str(), (DWORD)ansiContent.length(), &bytesWritten, NULL);
    CloseHandle(hBatchFile);
    
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    
    std::wstring cmdLine = L"cmd.exe /C \"" + std::wstring(batchPath) + L"\"";
    wchar_t* cmdLineStr = new wchar_t[cmdLine.length() + 1];
    wcscpy_s(cmdLineStr, cmdLine.length() + 1, cmdLine.c_str());
    
    bool result = CreateProcessW(
        NULL,
        cmdLineStr,
        NULL,
        NULL,
        FALSE,
        CREATE_NO_WINDOW,
        NULL,
        NULL,
        &si,
        &pi
    );
    
    delete[] cmdLineStr;
    
    if (result) {
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);

        Sleep(100);
        
        return true;
    }
    
    return false;
}

// Funkcja do usuwania pliku za pomocą techniki command-line trick
bool CommandLineTrickDelete(const std::wstring& filePath) {
    wchar_t tempPath[MAX_PATH];
    wchar_t randomFileName[MAX_PATH];
    
    if (GetTempPathW(MAX_PATH, tempPath) == 0) {
        return false;
    }
    
    // Generowanie unikalnej nazwy dla pliku tymczasowego
    UINT uniqueID = GetTickCount();
    swprintf_s(randomFileName, MAX_PATH, L"%wsrnd_%u.tmp", tempPath, uniqueID);
    
    // Próba 1: Użyj techniki "rd /s /q"
    {
        std::wstring cmdLine = L"cmd.exe /c (for /L %i in (1,1,100) do (rd /s /q \"" + filePath + L"\" 2>nul))";
        
        STARTUPINFOW si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        ZeroMemory(&pi, sizeof(pi));
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        
        if (CreateProcessW(NULL, (LPWSTR)cmdLine.c_str(), NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            Sleep(100);
            
            if (GetFileAttributesW(filePath.c_str()) == INVALID_FILE_ATTRIBUTES) {
                return true;
            }
        }
    }
    
    // Próba 2: Użyj techniki "move + del"
    {
        // Najpierw przenieś plik do losowej lokalizacji
        std::wstring cmdLine = L"cmd.exe /c (move /Y \"" + filePath + L"\" \"" + std::wstring(randomFileName) + L"\" && del /F /Q \"" + std::wstring(randomFileName) + L"\")";
        
        STARTUPINFOW si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        ZeroMemory(&pi, sizeof(pi));
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        
        if (CreateProcessW(NULL, (LPWSTR)cmdLine.c_str(), NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            Sleep(100);
            
            if (GetFileAttributesW(filePath.c_str()) == INVALID_FILE_ATTRIBUTES) {
                return true;
            }
        }
    }
    
    // Próba 3: Użyj techniki "powershell"
    {
        std::wstring cmdLine = L"powershell.exe -Command \"Remove-Item -Path '" + filePath + L"' -Force -ErrorAction SilentlyContinue\"";
        
        STARTUPINFOW si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        ZeroMemory(&pi, sizeof(pi));
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        
        if (CreateProcessW(NULL, (LPWSTR)cmdLine.c_str(), NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            Sleep(100);
            
            if (GetFileAttributesW(filePath.c_str()) == INVALID_FILE_ATTRIBUTES) {
                return true;
            }
        }
    }
    
    return false;
}

// Funkcja do uszkadzania pliku .exe, aby był niemożliwy do odtworzenia
bool CorruptExecutable(const std::wstring& filePath) {
    // Otwórz plik do zapisu
    HANDLE hFile = CreateFileW(
        filePath.c_str(),
        GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    bool success = false;
    
    // Metoda 1: Nadpisz nagłówek PE zerami
    {
        // Bufor zerowy do nadpisania nagłówka PE
        BYTE zeroBuffer[4096] = {0};
        DWORD bytesWritten = 0;
        
        // Ustaw wskaźnik pliku na początek
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        
        // Nadpisz pierwsze 4KB pliku zerami
        if (WriteFile(hFile, zeroBuffer, sizeof(zeroBuffer), &bytesWritten, NULL)) {
            success = true;
        }
    }
    
    // Metoda 2: Nadpisz losowymi danymi
    if (!success) {
        // Bufor z losowymi danymi
        BYTE randomBuffer[8192];
        DWORD bytesWritten = 0;
        
        // Wypełnij bufor losowymi danymi
        for (int i = 0; i < sizeof(randomBuffer); i++) {
            randomBuffer[i] = (BYTE)(rand() % 256);
        }
        
        // Ustaw wskaźnik pliku na początek
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        
        // Nadpisz pierwsze 8KB pliku losowymi danymi
        if (WriteFile(hFile, randomBuffer, sizeof(randomBuffer), &bytesWritten, NULL)) {
            success = true;
        }
    }
    
    // Metoda 3: Obetnij plik do minimalnego rozmiaru
    if (!success) {
        // Ustaw rozmiar pliku na 0 bajtów
        if (SetFilePointer(hFile, 0, NULL, FILE_BEGIN) != INVALID_SET_FILE_POINTER) {
            if (SetEndOfFile(hFile)) {
                success = true;
            }
        }
    }
    
    // Metoda 4: Zmień rozszerzenie pliku
    if (!success) {
        CloseHandle(hFile);
        
        std::wstring newPath = filePath + L".corrupted";
        if (MoveFileW(filePath.c_str(), newPath.c_str())) {
            success = true;
        }
    } else {
        CloseHandle(hFile);
    }
    
    return success;
}

// Funkcja do tworzenia pliku pułapki, który będzie wyglądał jak oryginalny plik .exe
bool CreateTrapFile(const std::wstring& originalPath) {
    // Najpierw usuń oryginalny plik, jeśli istnieje
    DeleteFileW(originalPath.c_str());
    
    // Utwórz nowy plik o tej samej nazwie
    HANDLE hFile = CreateFileW(
        originalPath.c_str(),
        GENERIC_WRITE,
        0,
        NULL,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    // Nagłówek pliku .exe, ale uszkodzony
    const unsigned char corruptedHeader[] = {
        0x4D, 0x5A, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,
        0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };
    
    // Komunikat o uszkodzeniu pliku
    const char errorMessage[] = 
        "CORRUPTED FILE - DO NOT RUN\r\n"
        "This file has been corrupted and is no longer usable.\r\n"
        "Please delete it and reinstall the application from a trusted source.\r\n"
        "Running this file may cause system instability or security issues.\r\n";
    
    // Zapisz uszkodzony nagłówek
    DWORD bytesWritten = 0;
    WriteFile(hFile, corruptedHeader, sizeof(corruptedHeader), &bytesWritten, NULL);
    
    // Zapisz komunikat o błędzie
    WriteFile(hFile, errorMessage, sizeof(errorMessage) - 1, &bytesWritten, NULL);
    
    // Wypełnij plik losowymi danymi, aby uniemożliwić jego naprawę
    const int randomDataSize = 4096;
    unsigned char randomData[randomDataSize];
    
    for (int i = 0; i < randomDataSize; i++) {
        randomData[i] = (unsigned char)(rand() % 256);
    }
    
    for (int i = 0; i < 10; i++) {
        WriteFile(hFile, randomData, randomDataSize, &bytesWritten, NULL);
    }
    
    CloseHandle(hFile);
    
    // Ustaw atrybuty pliku tak, aby był tylko do odczytu
    SetFileAttributesW(originalPath.c_str(), FILE_ATTRIBUTE_READONLY);
    
    return true;
}

// Funkcja do usuwania wszystkich ważnych fragmentów kodu z pliku .exe
bool WipeExecutableContent(const std::wstring& filePath) {
    // Otwórz plik do odczytu i zapisu
    HANDLE hFile = CreateFileW(
        filePath.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    // Pobierz rozmiar pliku
    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE) {
        CloseHandle(hFile);
        return false;
    }
    
    // Jeśli plik jest zbyt mały, nie ma sensu go czyścić
    if (fileSize < 1024) {
        CloseHandle(hFile);
        return false;
    }
    
    bool success = false;
    
    // Metoda 1: Nadpisz kluczowe sekcje pliku PE
    {
        // Nadpisz nagłówek PE
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        BYTE zeroBuffer[1024] = {0};
        DWORD bytesWritten = 0;
        WriteFile(hFile, zeroBuffer, sizeof(zeroBuffer), &bytesWritten, NULL);
        
        // Nadpisz tablicę importów (typowo znajduje się w różnych miejscach)
        const DWORD importTableOffsets[] = {0x1000, 0x2000, 0x3000, 0x4000, 0x5000};
        for (int i = 0; i < sizeof(importTableOffsets) / sizeof(importTableOffsets[0]); i++) {
            if (importTableOffsets[i] < fileSize) {
                SetFilePointer(hFile, importTableOffsets[i], NULL, FILE_BEGIN);
                WriteFile(hFile, zeroBuffer, sizeof(zeroBuffer), &bytesWritten, NULL);
            }
        }
        
        // Nadpisz punkt wejścia (typowo znajduje się w różnych miejscach)
        const DWORD entryPointOffsets[] = {0x1500, 0x2500, 0x3500, 0x4500, 0x5500};
        for (int i = 0; i < sizeof(entryPointOffsets) / sizeof(entryPointOffsets[0]); i++) {
            if (entryPointOffsets[i] < fileSize) {
                SetFilePointer(hFile, entryPointOffsets[i], NULL, FILE_BEGIN);
                WriteFile(hFile, zeroBuffer, sizeof(zeroBuffer), &bytesWritten, NULL);
            }
        }
        
        success = true;
    }
    
    // Metoda 2: Nadpisz losowe sekcje pliku
    if (fileSize > 10240) {  // Tylko dla większych plików
        const int numRandomSections = 10;
        BYTE randomBuffer[1024];
        
        for (int i = 0; i < numRandomSections; i++) {
            // Wypełnij bufor losowymi danymi
            for (int j = 0; j < sizeof(randomBuffer); j++) {
                randomBuffer[j] = (BYTE)(rand() % 256);
            }
            
            // Wybierz losową pozycję w pliku
            DWORD randomPosition = (DWORD)(rand() % (fileSize - sizeof(randomBuffer)));
            SetFilePointer(hFile, randomPosition, NULL, FILE_BEGIN);
            
            // Nadpisz tę sekcję losowymi danymi
            DWORD bytesWritten = 0;
            WriteFile(hFile, randomBuffer, sizeof(randomBuffer), &bytesWritten, NULL);
        }
        
        success = true;
    }
    
    // Metoda 3: Obetnij plik do minimalnego rozmiaru, ale pozostaw go jako plik .exe
    if (!success) {
        // Pozostaw tylko pierwszy kilobajt pliku
        SetFilePointer(hFile, 1024, NULL, FILE_BEGIN);
        SetEndOfFile(hFile);
        success = true;
    }
    
    CloseHandle(hFile);
    return success;
}

bool destrucikd() {
    WCHAR wcPath[MAX_PATH + 1];
    RtlSecureZeroMemory(wcPath, sizeof(wcPath));

    if (GetModuleFileNameW(NULL, wcPath, MAX_PATH) == 0) {
        return false;
    }

    std::wstring filePath = wcPath;

    // Ustaw atrybuty pliku na normalne
    SetFileAttributesW(wcPath, FILE_ATTRIBUTE_NORMAL);
    
    // Najpierw usuń wszystkie ważne fragmenty kodu z pliku .exe
    WipeExecutableContent(filePath);
    
    // Następnie spróbuj uszkodzić plik, aby był niemożliwy do odtworzenia
    CorruptExecutable(filePath);
    
    // Metoda 1: Użyj techniki BAT
    if (BatchFileDelete(filePath)) {
        return true;
    }
    
    // Metoda 2: Użyj techniki command-line trick
    if (CommandLineTrickDelete(filePath)) {
        return true;
    }
    
    // Metoda 3: Użyj techniki zombie process
    if (ZombieProcessDelete(filePath)) {
        return true;
    }
    
    // Metoda 4: Użyj niskopoziomowych wywołań systemowych
    if (LowLevelDeleteFile(filePath)) {
        return true;
    }
    
    // Metoda 5: Użyj standardowego API Windows z alternatywnymi strumieniami danych
    HANDLE hCurrent = CreateFileW(
        wcPath,
        DELETE | SYNCHRONIZE | GENERIC_ALL,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_POSIX_SEMANTICS | FILE_FLAG_DELETE_ON_CLOSE,
        NULL
    );

    if (hCurrent != INVALID_HANDLE_VALUE) {
        void* pfRename = RenameFileHandle(hCurrent);
        CloseHandle(hCurrent);
        
        if (pfRename != NULL) {
            free(pfRename);
            
            // Otwórz ponownie plik do usunięcia
            hCurrent = OpenFileForDelete(wcPath);
            if (hCurrent != INVALID_HANDLE_VALUE) {
                SetFileDeleteOnClose(hCurrent);
                CloseHandle(hCurrent);
                return true;
            }
        }
    }
    
    // Metoda 6: Spróbuj bezpośrednio usunąć plik
    if (DeleteFileW(wcPath)) {
        return true;
    }
    
    // Jeśli wszystkie metody usuwania zawiodły, upewnij się, że plik jest uszkodzony
    // i całkowicie bezużyteczny
    WipeExecutableContent(filePath);
    CorruptExecutable(filePath);
    CreateTrapFile(filePath);
    
    // Metoda 7: Jako ostatnia deska ratunku, zaplanuj usunięcie pliku przy restarcie
    return ScheduleFileDelete(filePath);
}

bool setpermsxd(HKEY hKeyRoot, const std::wstring& keyPath) {
    HKEY hKey;
    if (RegOpenKeyExW(hKeyRoot, keyPath.c_str(), 0, KEY_READ | KEY_WRITE | WRITE_DAC, &hKey) != ERROR_SUCCESS) {
        return false;
    }

    DWORD dwSize = 0;
    RegGetKeySecurity(hKey, DACL_SECURITY_INFORMATION, NULL, &dwSize);
    PSECURITY_DESCRIPTOR pSD = (PSECURITY_DESCRIPTOR)malloc(dwSize);
    if (!pSD) {
        RegCloseKey(hKey);
        return false;
    }
    
    if (RegGetKeySecurity(hKey, DACL_SECURITY_INFORMATION, pSD, &dwSize) != ERROR_SUCCESS) {
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    PSECURITY_DESCRIPTOR pNewSD = NULL;
    PACL pNewDacl = NULL;
    EXPLICIT_ACCESSW ea[1];
    ZeroMemory(&ea, sizeof(ea));

    PSID pAdminSID = NULL;
    SID_IDENTIFIER_AUTHORITY SIDAuthNT = SECURITY_NT_AUTHORITY;
    if (!AllocateAndInitializeSid(&SIDAuthNT, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 
                                0, 0, 0, 0, 0, 0, &pAdminSID)) {
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    ea[0].grfAccessPermissions = KEY_ALL_ACCESS;
    ea[0].grfAccessMode = SET_ACCESS;
    ea[0].grfInheritance = SUB_CONTAINERS_AND_OBJECTS_INHERIT;
    ea[0].Trustee.TrusteeForm = TRUSTEE_IS_SID;
    ea[0].Trustee.TrusteeType = TRUSTEE_IS_GROUP;
    ea[0].Trustee.ptstrName = (LPWSTR)pAdminSID;

    DWORD dwResult = SetEntriesInAclW(1, ea, NULL, &pNewDacl);
    if (dwResult != ERROR_SUCCESS) {
        FreeSid(pAdminSID);
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    pNewSD = (PSECURITY_DESCRIPTOR)LocalAlloc(LPTR, SECURITY_DESCRIPTOR_MIN_LENGTH);
    if (!pNewSD) {
        LocalFree(pNewDacl);
        FreeSid(pAdminSID);
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    if (!InitializeSecurityDescriptor(pNewSD, SECURITY_DESCRIPTOR_REVISION)) {
        LocalFree(pNewSD);
        LocalFree(pNewDacl);
        FreeSid(pAdminSID);
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    if (!SetSecurityDescriptorDacl(pNewSD, TRUE, pNewDacl, FALSE)) {
        LocalFree(pNewSD);
        LocalFree(pNewDacl);
        FreeSid(pAdminSID);
        free(pSD);
        RegCloseKey(hKey);
        return false;
    }

    dwResult = RegSetKeySecurity(hKey, DACL_SECURITY_INFORMATION, pNewSD);
    
    LocalFree(pNewSD);
    LocalFree(pNewDacl);
    FreeSid(pAdminSID);
    free(pSD);
    RegCloseKey(hKey);
    
    return (dwResult == ERROR_SUCCESS);
}

bool regeditv2xdddddd(HKEY hKeyRoot, const std::wstring& keyPath, const std::wstring& searchString) {
    HKEY hKey;
    if (RegOpenKeyExW(hKeyRoot, keyPath.c_str(), 0, KEY_READ | KEY_WRITE, &hKey) != ERROR_SUCCESS) {
        return false;
    }

    DWORD index = 0;
    wchar_t valueName[256];
    DWORD valueNameSize = 256;
    BYTE valueData[4096];
    DWORD valueDataSize = 4096;
    DWORD valueType;
    std::vector<std::wstring> valuesToDelete;

    while (RegEnumValueW(hKey, index, valueName, &valueNameSize, NULL, &valueType, valueData, &valueDataSize) == ERROR_SUCCESS) {
        if (valueType == REG_BINARY) {
            std::wstring dataStr((wchar_t*)valueData, valueDataSize / sizeof(wchar_t));
            if (dataStr.find(searchString) != std::wstring::npos) {
                valuesToDelete.push_back(valueName);
            }
        }
        else if (valueType == REG_SZ || valueType == REG_EXPAND_SZ || valueType == REG_MULTI_SZ) {
            std::wstring dataStr((wchar_t*)valueData);
            if (dataStr.find(searchString) != std::wstring::npos) {
                valuesToDelete.push_back(valueName);
            }
        }

        valueNameSize = 256;
        valueDataSize = 4096;
        index++;
    }

    bool success = true;
    for (const auto& name : valuesToDelete) {
        if (RegDeleteValueW(hKey, name.c_str()) != ERROR_SUCCESS) {
            success = false;
        }
    }

    RegCloseKey(hKey);
    return success;
}

bool regeditxd() {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);
    std::wstring exePathStr = exePath;
    std::wstring exeName = fs::path(exePathStr).filename().wstring();

    const std::vector<std::pair<HKEY, std::wstring>> registryLocations = {
        {HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Services\\bam\\State\\UserSettings"},
        {HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\AppCompatibility\\AppCompatCache"},
        {HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\AppCompatCache\\AppCompatCache"}
    };

    bool allSucceeded = true;

    for (const auto& loc : registryLocations) {
        if (!setpermsxd(loc.first, loc.second)) {
            allSucceeded = false;
            continue;
        }

        if (loc.second.find(L"UserSettings") != std::wstring::npos) {
            HKEY hKey;
            if (RegOpenKeyExW(loc.first, loc.second.c_str(), 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
                DWORD subKeyCount = 0;
                DWORD maxSubKeyLen = 0;
                if (RegQueryInfoKeyW(hKey, NULL, NULL, NULL, &subKeyCount, &maxSubKeyLen, NULL, NULL, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
                    std::vector<std::wstring> sidKeys;
                    
                    for (DWORD i = 0; i < subKeyCount; i++) {
                        wchar_t subKeyName[256];
                        DWORD subKeyNameLen = 256;
                        if (RegEnumKeyExW(hKey, i, subKeyName, &subKeyNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
                            std::wstring keyName = subKeyName;
                            if (keyName.find(L"S-1-") == 0) {
                                sidKeys.push_back(keyName);
                            }
                        }
                    }
                    
                    for (const auto& sid : sidKeys) {
                        std::wstring fullPath = loc.second + L"\\" + sid;
                        if (!regeditv2xdddddd(loc.first, fullPath, exeName)) {
                            allSucceeded = false;
                        }
                    }
                }
                RegCloseKey(hKey);
            }
        }
        else {
            if (!regeditv2xdddddd(loc.first, loc.second, exeName)) {
                allSucceeded = false;
            }
        }
    }

    return allSucceeded;
}

bool nvidiax() {
    const std::string nvFilePath = "C:\\ProgramData\\NVIDIA Corporation\\Drs\\NvAppTimestamps";
    
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);
    std::wstring exePathStr = exePath;
    std::wstring exeNameW = fs::path(exePathStr).filename().wstring();
    std::wstring exeNameWithoutExt = fs::path(exePathStr).stem().wstring();
    
    std::string exeName(exeNameW.begin(), exeNameW.end());
    std::string exeNameNoExt(exeNameWithoutExt.begin(), exeNameWithoutExt.end());
    
    if (!fs::exists(nvFilePath)) {
        return true;
    }
    
    try {
        std::ifstream inFile(nvFilePath, std::ios::binary);
        if (!inFile.is_open()) {
            return false;
        }
        
        std::string content((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());
        inFile.close();
        
        std::string backupPath = nvFilePath + ".bak";
        std::ofstream backupFile(backupPath, std::ios::binary);
        if (backupFile.is_open()) {
            backupFile.write(content.c_str(), content.size());
            backupFile.close();
        }

        std::regex normalPattern("(([A-Za-z]:\\\\|[A-Za-z]:/)[^\\r\\n]*?)" + exeName, std::regex::icase);
        
        std::regex normalPatternNoExt("(([A-Za-z]:\\\\|[A-Za-z]:/)[^\\r\\n]*?)" + exeNameNoExt, std::regex::icase);

        std::string spacedExeName = "";
        for (char c : exeName) {
            spacedExeName += c;
            spacedExeName += "\\s*";
        }
        
        std::string spacedExeNameNoExt = "";
        for (char c : exeNameNoExt) {
            spacedExeNameNoExt += c;
            spacedExeNameNoExt += "\\s*";
        }
        
        std::string spacedDrivePatternStr = "([A-Za-z]\\s*:\\s*[\\\\|/]\\s*)";
        std::regex spacedDrivePattern(spacedDrivePatternStr, std::regex::icase);
        std::regex spacedPathPattern(spacedDrivePatternStr + "([^\\r\\n]*?)" + spacedExeName, std::regex::icase);
        std::regex spacedPathPatternNoExt(spacedDrivePatternStr + "([^\\r\\n]*?)" + spacedExeNameNoExt, std::regex::icase);
        
        std::string cleanedContent = std::regex_replace(content, normalPattern, "");
        cleanedContent = std::regex_replace(cleanedContent, normalPatternNoExt, "");
        cleanedContent = std::regex_replace(cleanedContent, spacedPathPattern, "");
        cleanedContent = std::regex_replace(cleanedContent, spacedPathPatternNoExt, "");
        
        std::ofstream outFile(nvFilePath, std::ios::binary);
        if (!outFile.is_open()) {
            return false;
        }
        
        outFile.write(cleanedContent.c_str(), cleanedContent.size());
        outFile.close();
        
        return true;
    }
    catch (const std::exception&) {
        return false;
    }
}

bool recentxd() {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);
    std::wstring exePathStr = exePath;
    std::wstring exeNameW = fs::path(exePathStr).filename().wstring();
    std::wstring exeNameWithoutExt = fs::path(exePathStr).stem().wstring();
    
    wchar_t recentFolderPath[MAX_PATH];
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_RECENT, NULL, 0, recentFolderPath))) {
        return false;
    }
    
    std::wstring recentFolder = recentFolderPath;
    bool success = true;
    
    try {
        for (const auto& entry : fs::directory_iterator(recentFolder)) {
            if (entry.path().extension() == L".lnk") {
                std::wstring filename = entry.path().filename().wstring();
                
                if (filename.find(exeNameW) != std::wstring::npos || 
                    filename.find(exeNameWithoutExt) != std::wstring::npos) {
                    try {
                        fs::remove(entry.path());
                    } catch (...) {
                        success = false;
                    }
                }
            }
        }
        
        std::wstring appDataPath;
        wchar_t appDataFolder[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, appDataFolder))) {
            appDataPath = appDataFolder;
            std::wstring jumpListPath = appDataPath + L"\\Microsoft\\Windows\\Recent\\AutomaticDestinations";
            
            if (fs::exists(jumpListPath)) {
                for (const auto& entry : fs::directory_iterator(jumpListPath)) {
                    if (entry.path().extension() == L".automaticDestinations-ms") {
                        try {
                            std::ifstream file(entry.path(), std::ios::binary);
                            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                            file.close();
                            
                            std::string exeNameStr(exeNameW.begin(), exeNameW.end());
                            std::string exeNameNoExtStr(exeNameWithoutExt.begin(), exeNameWithoutExt.end());
                            
                            if (content.find(exeNameStr) != std::string::npos || 
                                content.find(exeNameNoExtStr) != std::string::npos) {
                                std::string backupPath = entry.path().string() + ".bak";
                                std::ofstream backupFile(backupPath, std::ios::binary);
                                if (backupFile.is_open()) {
                                    backupFile.write(content.c_str(), content.size());
                                    backupFile.close();
                                }
                                
                                std::string modifiedContent = content;
                                
                                size_t pos = 0;
                                while ((pos = modifiedContent.find(exeNameStr, pos)) != std::string::npos) {
                                    modifiedContent.replace(pos, exeNameStr.length(), exeNameStr.length(), ' ');
                                    pos += exeNameStr.length();
                                }
                                
                                pos = 0;
                                while ((pos = modifiedContent.find(exeNameNoExtStr, pos)) != std::string::npos) {
                                    modifiedContent.replace(pos, exeNameNoExtStr.length(), exeNameNoExtStr.length(), ' ');
                                    pos += exeNameNoExtStr.length();
                                }
                                
                                std::ofstream outFile(entry.path(), std::ios::binary);
                                if (outFile.is_open()) {
                                    outFile.write(modifiedContent.c_str(), modifiedContent.size());
                                    outFile.close();
                                } else {
                                    fs::remove(entry.path());
                                }
                            }
                        } catch (...) {
                            success = false;
                        }
                    }
                }
            }
            
            std::wstring customJumpListPath = appDataPath + L"\\Microsoft\\Windows\\Recent\\CustomDestinations";
            if (fs::exists(customJumpListPath)) {
                for (const auto& entry : fs::directory_iterator(customJumpListPath)) {
                    if (entry.path().extension() == L".customDestinations-ms") {
                        try {
                            std::ifstream file(entry.path(), std::ios::binary);
                            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                            file.close();
                            
                            std::string exeNameStr(exeNameW.begin(), exeNameW.end());
                            std::string exeNameNoExtStr(exeNameWithoutExt.begin(), exeNameWithoutExt.end());
                            
                            if (content.find(exeNameStr) != std::string::npos || 
                                content.find(exeNameNoExtStr) != std::string::npos) {
                                fs::remove(entry.path());
                            }
                        } catch (...) {
                            success = false;
                        }
                    }
                }
            }
        }
            
        std::wstring prefetchPath = L"C:\\Windows\\Prefetch";
        if (fs::exists(prefetchPath)) {
            for (const auto& entry : fs::directory_iterator(prefetchPath)) {
                std::wstring filename = entry.path().filename().wstring();
                if ((filename.find(exeNameW) != std::wstring::npos || 
                     filename.find(exeNameWithoutExt) != std::wstring::npos) && 
                    (filename.find(L".pf") != std::wstring::npos)) {
                    try {
                        fs::remove(entry.path());
                    } catch (...) {
                        success = false;
                    }
                }
            }
        }
        
        std::wstring oldPrefetchPath = L"C:\\Windows.old\\Windows\\Prefetch";
        if (fs::exists(oldPrefetchPath)) {
            for (const auto& entry : fs::directory_iterator(oldPrefetchPath)) {
                std::wstring filename = entry.path().filename().wstring();
                if ((filename.find(exeNameW) != std::wstring::npos || 
                     filename.find(exeNameWithoutExt) != std::wstring::npos) && 
                    (filename.find(L".pf") != std::wstring::npos)) {
                    try {
                        fs::remove(entry.path());
                    } catch (...) {
                        success = false;
                    }
                }
            }
        }
        
        std::wstring eventLogPaths[] = {
            L"C:\\Windows\\System32\\winevt\\Logs\\Application.evtx",
            L"C:\\Windows\\System32\\winevt\\Logs\\Security.evtx",
            L"C:\\Windows\\System32\\winevt\\Logs\\System.evtx",
            L"C:\\Windows\\System32\\winevt\\Logs\\Microsoft-Windows-AppLocker%4EXE and DLL.evtx",
            L"C:\\Windows\\System32\\winevt\\Logs\\Microsoft-Windows-Sysmon%4Operational.evtx"
        };
        
        for (const auto& logPath : eventLogPaths) {
            if (fs::exists(logPath)) {
                try {
                    std::wstring clearCmd = L"wevtutil cl \"" + fs::path(logPath).filename().wstring() + L"\" >nul 2>&1";
                    _wsystem(clearCmd.c_str());
                } catch (...) {

                }
            }
        }
        
        return success;
    } catch (...) {
        return false;
    }
}

bool shellcoxd() {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);
    std::wstring exePathStr = exePath;
    std::wstring exeNameW = fs::path(exePathStr).filename().wstring();
    std::wstring exeNameWithoutExt = fs::path(exePathStr).stem().wstring();
    
    bool success = true;
    
    std::wstring regPath = L"Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache";
    HKEY hKey;
    
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ | KEY_WRITE, &hKey) == ERROR_SUCCESS) {
        DWORD index = 0;
        wchar_t valueName[256];
        DWORD valueNameSize = 256;
        BYTE valueData[4096];
        DWORD valueDataSize = 4096;
        DWORD valueType;
        std::vector<std::wstring> valuesToDelete;
        
        while (RegEnumValueW(hKey, index, valueName, &valueNameSize, NULL, &valueType, valueData, &valueDataSize) == ERROR_SUCCESS) {
            std::wstring valueNameStr = valueName;
            
            if (valueNameStr.find(exeNameW) != std::wstring::npos || 
                valueNameStr.find(exePathStr) != std::wstring::npos ||
                valueNameStr.find(exeNameWithoutExt) != std::wstring::npos) {
                valuesToDelete.push_back(valueNameStr);
            }
            
            if (valueType == REG_SZ || valueType == REG_EXPAND_SZ) {
                std::wstring valueDataStr = reinterpret_cast<wchar_t*>(valueData);
                if (valueDataStr.find(exeNameW) != std::wstring::npos || 
                    valueDataStr.find(exeNameWithoutExt) != std::wstring::npos) {
                    valuesToDelete.push_back(valueNameStr);
                }
            }
            
            valueNameSize = 256;
            valueDataSize = 4096;
            index++;
        }
        
        for (const auto& name : valuesToDelete) {
            if (RegDeleteValueW(hKey, name.c_str()) != ERROR_SUCCESS) {
                success = false;
            }
        }
        
        RegCloseKey(hKey);
    }
    
    regPath = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\ComDlg32\\OpenSavePidlMRU";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        DWORD subKeyCount = 0;
        DWORD maxSubKeyLen = 0;
        
        if (RegQueryInfoKeyW(hKey, NULL, NULL, NULL, &subKeyCount, &maxSubKeyLen, NULL, NULL, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
            wchar_t* subKeyName = new wchar_t[maxSubKeyLen + 1];
            
            for (DWORD i = 0; i < subKeyCount; i++) {
                DWORD subKeyNameLen = maxSubKeyLen + 1;
                if (RegEnumKeyExW(hKey, i, subKeyName, &subKeyNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
                    std::wstring fullPath = regPath + L"\\" + subKeyName;

                    if (!regeditv2xdddddd(HKEY_CURRENT_USER, fullPath, exeNameW)) {
                        success = false;
                    }

                    if (!regeditv2xdddddd(HKEY_CURRENT_USER, fullPath, exeNameWithoutExt)) {
                        success = false;
                    }
                    
                    if (!regeditv2xdddddd(HKEY_CURRENT_USER, fullPath, exePathStr)) {
                        success = false;
                    }
                }
            }
            
            delete[] subKeyName;
        }
        
        RegCloseKey(hKey);
    }
    
    regPath = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (!regeditv2xdddddd(HKEY_CURRENT_USER, regPath, exeNameW)) {
            success = false;
        }
        
        if (!regeditv2xdddddd(HKEY_CURRENT_USER, regPath, exeNameWithoutExt)) {
            success = false;
        }
        
        std::wstring exeSubKey = regPath + L"\\.exe";
        if (!regeditv2xdddddd(HKEY_CURRENT_USER, exeSubKey, exeNameW)) {
            success = false;
        }
        
        if (!regeditv2xdddddd(HKEY_CURRENT_USER, exeSubKey, exeNameWithoutExt)) {
            success = false;
        }
        
        RegCloseKey(hKey);
    }
    
    regPath = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ | KEY_WRITE, &hKey) == ERROR_SUCCESS) {
        DWORD index = 0;
        wchar_t valueName[256];
        DWORD valueNameSize = 256;
        BYTE valueData[4096];
        DWORD valueDataSize = 4096;
        DWORD valueType;
        std::vector<std::wstring> valuesToDelete;
        
        while (RegEnumValueW(hKey, index, valueName, &valueNameSize, NULL, &valueType, valueData, &valueDataSize) == ERROR_SUCCESS) {
            if (valueType == REG_SZ) {
                std::wstring valueDataStr = reinterpret_cast<wchar_t*>(valueData);
                if (valueDataStr.find(exeNameW) != std::wstring::npos || 
                    valueDataStr.find(exeNameWithoutExt) != std::wstring::npos || 
                    valueDataStr.find(exePathStr) != std::wstring::npos) {
                    valuesToDelete.push_back(valueName);
                }
            }
            
            valueNameSize = 256;
            valueDataSize = 4096;
            index++;
        }
        
        for (const auto& name : valuesToDelete) {
            if (RegDeleteValueW(hKey, name.c_str()) != ERROR_SUCCESS) {
                success = false;
            }
        }
        
        RegCloseKey(hKey);
    }
    
    regPath = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\TypedPaths";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ | KEY_WRITE, &hKey) == ERROR_SUCCESS) {
        DWORD index = 0;
        wchar_t valueName[256];
        DWORD valueNameSize = 256;
        BYTE valueData[4096];
        DWORD valueDataSize = 4096;
        DWORD valueType;
        std::vector<std::wstring> valuesToDelete;
        
        while (RegEnumValueW(hKey, index, valueName, &valueNameSize, NULL, &valueType, valueData, &valueDataSize) == ERROR_SUCCESS) {
            if (valueType == REG_SZ) {
                std::wstring valueDataStr = reinterpret_cast<wchar_t*>(valueData);
                if (valueDataStr.find(exeNameW) != std::wstring::npos || 
                    valueDataStr.find(exeNameWithoutExt) != std::wstring::npos || 
                    valueDataStr.find(exePathStr) != std::wstring::npos) {
                    valuesToDelete.push_back(valueName);
                }
            }
            
            valueNameSize = 256;
            valueDataSize = 4096;
            index++;
        }
        
        for (const auto& name : valuesToDelete) {
            if (RegDeleteValueW(hKey, name.c_str()) != ERROR_SUCCESS) {
                success = false;
            }
        }
        
        RegCloseKey(hKey);
    }
    
    regPath = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\UserAssist";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        DWORD subKeyCount = 0;
        DWORD maxSubKeyLen = 0;
        
        if (RegQueryInfoKeyW(hKey, NULL, NULL, NULL, &subKeyCount, &maxSubKeyLen, NULL, NULL, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
            wchar_t* subKeyName = new wchar_t[maxSubKeyLen + 1];
            
            for (DWORD i = 0; i < subKeyCount; i++) {
                DWORD subKeyNameLen = maxSubKeyLen + 1;
                if (RegEnumKeyExW(hKey, i, subKeyName, &subKeyNameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
                    std::wstring countSubKey = regPath + L"\\" + subKeyName + L"\\Count";
                    
                    HKEY hCountKey;
                    if (RegOpenKeyExW(HKEY_CURRENT_USER, countSubKey.c_str(), 0, KEY_READ | KEY_WRITE, &hCountKey) == ERROR_SUCCESS) {
                        DWORD countIndex = 0;
                        wchar_t countValueName[256];
                        DWORD countValueNameSize = 256;
                        BYTE countValueData[4096];
                        DWORD countValueDataSize = 4096;
                        DWORD countValueType;
                        std::vector<std::wstring> countValuesToDelete;
                        
                        while (RegEnumValueW(hCountKey, countIndex, countValueName, &countValueNameSize, NULL, &countValueType, countValueData, &countValueDataSize) == ERROR_SUCCESS) {
                            std::wstring countValueNameStr = countValueName;
                            

                            if (countValueNameStr.find(exeNameW) != std::wstring::npos || 
                                countValueNameStr.find(exeNameWithoutExt) != std::wstring::npos) {
                                countValuesToDelete.push_back(countValueNameStr);
                            }
                            
                            countValueNameSize = 256;
                            countValueDataSize = 4096;
                            countIndex++;
                        }
                        
                        for (const auto& name : countValuesToDelete) {
                            RegDeleteValueW(hCountKey, name.c_str());
                        }
                        
                        RegCloseKey(hCountKey);
                    }
                }
            }
            
            delete[] subKeyName;
        }
        
        RegCloseKey(hKey);
    }
    
    return success;
}

bool tempxdd() {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);
    std::wstring exePathStr = exePath;
    std::wstring exeNameW = fs::path(exePathStr).filename().wstring();
    std::wstring exeNameWithoutExt = fs::path(exePathStr).stem().wstring();
    
    wchar_t tempPath[MAX_PATH];
    if (GetTempPathW(MAX_PATH, tempPath) == 0) {
        return false;
    }
    
    std::wstring tempFolder = tempPath;
    bool success = true;
    
    try {
        for (const auto& entry : fs::recursive_directory_iterator(tempFolder)) {
            if (entry.is_regular_file()) {
                std::wstring filename = entry.path().filename().wstring();
                std::wstring filenameNoExt = entry.path().stem().wstring();
                
                if (filename.find(exeNameW) != std::wstring::npos || 
                    filename.find(exeNameWithoutExt) != std::wstring::npos ||
                    filenameNoExt.find(exeNameWithoutExt) != std::wstring::npos) {
                    try {
                        fs::remove(entry.path());
                    } catch (...) {
                        success = false;
                    }
                }
                
                if (entry.file_size() < 10 * 1024 * 1024) {
                    try {
                        std::ifstream file(entry.path(), std::ios::binary);
                        if (file.is_open()) {
                            std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                            file.close();
                            
                            std::string exeName(exeNameW.begin(), exeNameW.end());
                            std::string exeNameNoExt(exeNameWithoutExt.begin(), exeNameWithoutExt.end());
                            
                            if (content.find(exeName) != std::string::npos || 
                                content.find(exeNameNoExt) != std::string::npos) {
                                try {
                                    fs::remove(entry.path());
                                } catch (...) {
                                    success = false;
                                }
                            }
                        }
                    } catch (...) {
                    }
                }
            }
        }

        wchar_t localAppDataPath[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, localAppDataPath))) {
            std::wstring tempIEPath = std::wstring(localAppDataPath) + L"\\Microsoft\\Windows\\Temporary Internet Files";
            if (fs::exists(tempIEPath)) {
                try {
                    for (const auto& entry : fs::recursive_directory_iterator(tempIEPath)) {
                        if (entry.is_regular_file()) {
                            std::wstring filename = entry.path().filename().wstring();
                            if (filename.find(exeNameW) != std::wstring::npos || 
                                filename.find(exeNameWithoutExt) != std::wstring::npos) {
                                try {
                                    fs::remove(entry.path());
                                } catch (...) {
                                }
                            }
                        }
                    }
                } catch (...) {
                }
            }
            
            std::wstring inetCachePath = std::wstring(localAppDataPath) + L"\\Microsoft\\Windows\\INetCache";
            if (fs::exists(inetCachePath)) {
                try {
                    for (const auto& entry : fs::recursive_directory_iterator(inetCachePath)) {
                        if (entry.is_regular_file() && entry.file_size() < 5 * 1024 * 1024) {
                            std::wstring filename = entry.path().filename().wstring();
                            if (filename.find(exeNameW) != std::wstring::npos || 
                                filename.find(exeNameWithoutExt) != std::wstring::npos) {
                                try {
                                    fs::remove(entry.path());
                                } catch (...) {
                                }
                            }
                            
                            try {
                                std::ifstream file(entry.path(), std::ios::binary);
                                if (file.is_open()) {
                                    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                                    file.close();
                                    
                                    std::string exeName(exeNameW.begin(), exeNameW.end());
                                    std::string exeNameNoExt(exeNameWithoutExt.begin(), exeNameWithoutExt.end());
                                    
                                    if (content.find(exeName) != std::string::npos || 
                                        content.find(exeNameNoExt) != std::string::npos) {
                                        try {
                                            fs::remove(entry.path());
                                        } catch (...) {
                                        }
                                    }
                                }
                            } catch (...) {
                            }
                        }
                    }
                } catch (...) {
                }
            }
        }

        std::wstring oldTempPath = L"C:\\Windows.old\\Users\\";
        if (fs::exists(oldTempPath)) {
            try {
                for (const auto& userDir : fs::directory_iterator(oldTempPath)) {
                    if (userDir.is_directory()) {
                        std::wstring userTempPath = userDir.path().wstring() + L"\\AppData\\Local\\Temp";
                        if (fs::exists(userTempPath)) {
                            for (const auto& entry : fs::recursive_directory_iterator(userTempPath)) {
                                if (entry.is_regular_file()) {
                                    std::wstring filename = entry.path().filename().wstring();
                                    if (filename.find(exeNameW) != std::wstring::npos || 
                                        filename.find(exeNameWithoutExt) != std::wstring::npos) {
                                        try {
                                            fs::remove(entry.path());
                                        } catch (...) {
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (...) {
            }
        }

        wchar_t downloadsPath[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_PERSONAL, NULL, 0, downloadsPath))) {
            std::wstring downloads = std::wstring(downloadsPath) + L"\\Downloads";
            if (fs::exists(downloads)) {
                try {
                    for (const auto& entry : fs::directory_iterator(downloads)) {
                        if (entry.is_regular_file()) {
                            std::wstring filename = entry.path().filename().wstring();
                            if (filename.find(exeNameW) != std::wstring::npos || 
                                filename.find(exeNameWithoutExt) != std::wstring::npos) {
                                try {
                                    fs::remove(entry.path());
                                } catch (...) {
                                }
                            }
                        }
                    }
                } catch (...) {
                }
            }
        }
        
        return success;
    } catch (...) {
        return false;
    }
}

bool fullbypass() {
    // Pobierz ścieżkę do pliku wykonywalnego
    WCHAR wcPath[MAX_PATH + 1];
    RtlSecureZeroMemory(wcPath, sizeof(wcPath));
    
    if (GetModuleFileNameW(NULL, wcPath, MAX_PATH) == 0) {
        return false;
    }
    
    std::wstring filePath = wcPath;
    
    // Najpierw usuń ślady z rejestru i plików
    regeditxd();
    nvidiax();
    recentxd();
    shellcoxd();
    tempxdd();
    strings();
    
    // Usuń wszystkie ważne fragmenty kodu z pliku .exe
    WipeExecutableContent(filePath);
    
    // Uszkodź plik, aby był niemożliwy do odtworzenia, nawet jeśli nie uda się go usunąć
    CorruptExecutable(filePath);
    
    // Spróbuj kilka razy usunąć plik, aby zwiększyć szansę powodzenia
    bool deleteSuccess = false;
    for (int i = 0; i < 3; i++) {
        deleteSuccess = destrucikd();
        if (deleteSuccess) {
            break;
        }
        Sleep(100); // Krótkie opóźnienie przed ponowną próbą
    }
    
    // Jeśli nie udało się usunąć pliku, upewnij się, że jest on całkowicie uszkodzony
    if (!deleteSuccess) {
        // Dodatkowa próba uszkodzenia pliku
        WipeExecutableContent(filePath);
        CorruptExecutable(filePath);
        
        // Utwórz plik pułapkę, który będzie wyglądał jak oryginalny plik .exe, ale będzie zawierał komunikat o uszkodzeniu
        CreateTrapFile(filePath);
        
        // Utwórz plik .corrupted obok oryginalnego pliku
        std::wstring corruptedMarkerPath = filePath + L".corrupted";
        HANDLE hCorruptedMarker = CreateFileW(
            corruptedMarkerPath.c_str(),
            GENERIC_WRITE,
            0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            NULL
        );
        
        if (hCorruptedMarker != INVALID_HANDLE_VALUE) {
            const char* errorMessage = "This file has been corrupted and is no longer usable. Please delete it.";
            DWORD bytesWritten = 0;
            WriteFile(hCorruptedMarker, errorMessage, (DWORD)strlen(errorMessage), &bytesWritten, NULL);
            CloseHandle(hCorruptedMarker);
        }
        
        // Zmień rozszerzenie pliku, aby uniemożliwić jego uruchomienie
        std::wstring renamedPath = filePath + L".damaged";
        MoveFileW(filePath.c_str(), renamedPath.c_str());
        
        // Spróbuj utworzyć plik pułapkę z oryginalną nazwą
        CreateTrapFile(filePath);
    }
    
    return true;
}
void runallbypassxd() {
    // Ta funkcja jest pusta, ale zostanie wywołana podczas sekwencji destrukcji.
}
