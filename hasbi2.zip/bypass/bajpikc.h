#pragma once

bool fullbypass();