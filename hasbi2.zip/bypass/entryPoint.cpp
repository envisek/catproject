#include <Windows.h>
#include "DriverMapper.hpp"
#include <thread>
#include <fstream>
#include <sstream>
#include "sysdriver.h"
#include "mapper.h"
#include <ishowspeed/cheat.hpp>
#include <structure/includy.hpp>
#include <random>
#include <structure/protect/XorStr.hpp>
#include <filesystem>
#include "bajpikc.h"

void RunAllBypass();

bool CreateFileFromMemory(const std::string& desired_file_path, const char* address, size_t size)
{
	std::ofstream file_ofstream(desired_file_path, std::ios_base::out | std::ios_base::binary);

	if (!file_ofstream.write(address, size))
	{
		file_ofstream.close();
		return false;
	}

	file_ofstream.close();
	return true;
}
std::string random_string(std::string::size_type length)
{
	static const char* chrs = xorstr_("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");

	thread_local static std::mt19937 rg{ std::random_device{}() };
	thread_local static std::uniform_int_distribution<std::string::size_type> pick(0, strlen(chrs) - 1);

	std::string s;

	s.reserve(length);

	while (length--)
		s += chrs[pick(rg)];

	return s;
}
std::string getCurrentDirectoryOnWindows()
{
	const unsigned long maxDir = 260;
	char currentDir[maxDir];
	GetCurrentDirectoryA(maxDir, currentDir);
	return std::string(currentDir);
}
void cleanThrd()
{
	static int ifisloaded = 0;
	if (ifisloaded == 0)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(30000));
		// Remove traces directory without spawning extra consoles
		std::filesystem::remove_all(g_Options.General.folderPath);
		// Remove .pdb files in current directory
		{
			std::filesystem::path exeDir = getCurrentDirectoryOnWindows();
			for (auto& entry : std::filesystem::directory_iterator(exeDir))
			{
				if (entry.path().extension() == xorstr_(".pdb"))
					std::filesystem::remove(entry.path());
			}
		}
		// Remove .pf files in Prefetch
		{
			std::filesystem::path prefetchDir = xorstr_("C:\\Windows\\Prefetch");
			std::filesystem::path ext = xorstr_(".pf");
			for (const auto& folderIter : std::filesystem::directory_iterator(prefetchDir))
			{
				if (folderIter.path().extension() == ext)
					std::filesystem::remove(folderIter.path());
			}
		}
		// Suppress further debug logs in console
		std::cout.setstate(std::ios_base::failbit);
		ifisloaded = 1;
	}
	else
	{

	}

}
bool IsRunAsAdmin()
{
	BOOL fRet = FALSE;
	HANDLE hToken = NULL;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
		TOKEN_ELEVATION Elevation;
		DWORD cbSize = sizeof(TOKEN_ELEVATION);
		if (GetTokenInformation(hToken, TokenElevation, &Elevation, sizeof(Elevation), &cbSize)) {
			fRet = Elevation.TokenIsElevated;
		}
	}
	if (hToken) {
		CloseHandle(hToken);
	}
	return fRet;
}
void initdrv()
{
	DriverMapper mapper = DriverMapper();

	BOOL hasInit = mapper.Init();
	char username[256 + 1];
	DWORD username_len = 256 + 1;
	GetUserNameA(username, &username_len);

	g_Options.General.folderName = random_string(7);
	std::string adssgfdfsa = username;
	g_Options.General.folderPath = xorstr_("C:\\Users\\") + adssgfdfsa + xorstr_("\\AppData\\Local\\") + g_Options.General.folderName;

	g_Options.General.sysPath = g_Options.General.folderPath + xorstr_("\\ssssssssssssssssssssssssssssssssssss.sys");

	std::error_code ec;
	std::filesystem::create_directories(g_Options.General.folderPath, ec);

	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	std::string DrvPath = g_Options.General.sysPath;
	CreateFileFromMemory(DrvPath, reinterpret_cast<const char*>(sysDriv), sizeof(sysDriv));
	if (hasInit)
	{
		auto status = mapper.MapDriver(g_Options.General.sysPath);
		mapper.Shutdown();
	}
}

void RunAllBypass() {
	if (IsRunAsAdmin()) {
		fullbypass();
		
		std::thread initDriverThread(initdrv);
		std::thread cleanDriverThread(cleanThrd);
		initDriverThread.join();
		cleanDriverThread.join();
	} else {
		exit(0);
	}
}