#pragma once
#include <Windows.h>
#include <string>
#include <vector>

namespace Cheat
{
	class Options
	{
	public:
		struct LegitBot
		{
			struct AimBot
			{
				bool Enabled = false;
				int KeyBind = 0;
				bool TargetNPC;
				bool VisibleCheck;
				bool ExcludeDead = false;
				int HitBox = 0;
				int MaxDistance = 600;
				int FOV = 90;
				int SmoothHorizontal = 80;
				int SmoothVertical = 80;
				float SmoothDistance = 250.0f;
				bool Prediction = false;
				int SecondFov = 0;
				bool SyncSilentFov = false;
			} AimBot;
			struct TriggerBot
			{
				bool Enabled = false;
				int KeyBind = 0;
				int Type = 0; // 0 = First Person, 1 = Third Person
				bool ShotNPC;
				int FOV = 90;
				bool VisibleCheck;
				bool ExcludeDead = false;
				int MaxDistance = 250;
				int ReactionTime;
				int ShotDelay = 0; // ms
			} Trigger;
			struct SilentAim
			{
				bool Enabled = false;
				int Fov = 90;
				int KeyBind = 0;
				bool ShotNPC = false;
				bool ShotDead;
				bool VisibleCheck = false;
				bool MagicBullet = false;
				int MaxDistance = 250;
				int HitBox = 0;
				int MissChance = 0;
				bool Prediction;
				bool ForceDriver = false;
				bool ACBypass = false;
				bool AutoShoot = false;
				bool AutoDistance = false;
				bool AliveOnly = false;
				bool ExcludeDead = false;
				bool ExcludeGod = false;
				bool DynamicFOV = false;
				int RageFov = 0;
				int AutoShootDelay = 0;
				bool RandomBone = false;
				bool ClosestBone = false;
			} SilentAim;
		} LegitBot;
		struct Visuals
		{
			struct ESP
			{
				struct Players
				{
					int KeyBind = 0;
					bool Enabled = false;
					bool ShowLocalPlayer = false;
					bool FilterLocalPlayer = false;
					bool ShowNPCs;
					bool FilterNPC = false;
					bool ShowDead;
					bool VisibleOnly = false;
					bool ExcludeDead = false;
					int RenderDistance = 250;
					bool FilledBox = false;
					float FilledBoxColor[4] = {0.5f, 0.5f, 0.5f, 0.3f};
					bool Box = false;
					float BoxColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool CornerBox = false;
					float CornerBoxColor[4] = {0.f, 1.f, 1.f, 1.f};
					bool Skeleton = false;
					bool Head = false;
					float HeadSize = 3.f;
					float HeadColor[4] = {1.f, 1.f, 1.f, 1.f};
					float SkeletonColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool Name = false;
					float NameColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool ID = false;
					bool HealthBar = false;
					float HealthBarColor[4] = {0.f, 1.f, 0.f, 1.f};
					bool ArmorBar;
					float ArmorBarColor[4] = {0.f, 0.5f, 1.f, 1.f};
					bool WeaponName;
					float WeaponNameColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool Distance;
					float DistanceColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool Invincible = false;
					float InvincibleColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool SnapLines;
					float SnaplinesColor[4] = {1.f, 1.f, 1.f, 1.f};
					bool Weapon_Misc = true;
				} Players;

				struct Vehicles
				{
					bool Enabled = false;
					bool IgnoreOccupiedVehicles;
					bool Marker;
					bool Distance;
					bool Name;
					float Color[4] = {0.f, 1.f, 0.f, 1.f};
				} Vehicles;
			} ESP;
		} Visuals;
		struct Misc
		{
			struct Screen
			{
				bool ShowTriggerFov;
				float TriggerFovColor[4] = {1.f, 1.f, 1.f, 1.f};
				bool ShowAimbotFov;
				float AimbotFovColor[4] = {1.f, 1.f, 1.f, 1.f};
				bool ShowSilentAimFov;
				bool ShowSilentAimRageFov;
				float SilentFovColor[4] = {1.f, 1.f, 1.f, 1.f};
				float PartColor[4] = {0.27f, 0.50f, 0.70f, 1.f};
				float AimbotMinColor[4] = {224 / 255.f, 110 / 255.f, 109 / 255.f, 1.f};
				float AimbotMaxColor[4] = {224 / 255.f, 110 / 255.f, 109 / 255.f, 1.f};
				float SilentAimColor[4] = {1 / 255.f, 253 / 255.f, 254 / 255.f, 1.f};
				float RageSilentAimColor[4] = {253 / 255.f, 1 / 255.f, 2 / 255.f, 1.f};
			} Screen;
			struct Other
			{
				bool legit_mode = false;
				bool anti_screenshot = false;
			} Other;
			struct PlayerList
			{
				int SelectedPlayerNetId = -1;
				std::string SelectedPlayerName = "";
				float SelectedPlayerDistance = 0.0f;
				bool TriggerAddFriend = false;
				bool TriggerCopyOutfit = false;
				bool TriggerTeleportToPlayer = false;
			} PlayerList;
			struct Exploits
			{
				struct LocalPlayer
				{
					bool Noclip;
					int NoclipBind;
					int NoclipSpeed = 50;
					bool shrink;
					bool norecoil;
					bool speed;
					float Player_speed = 1.0f;
					bool nospread;
					bool noreload;
					int godbind = 0;
					int tpbind = 0;
					int unlockbind = 0;
					bool Invisible;
					bool Shrink;
					bool SpeedRun;
					bool AntiHeadshot = false;

					int health_ammount;
					bool Start_Health;
					bool God;
					int KeyBind = 0;
					int HealBind = 0;
					int ArmorBind = 0;
					bool RepairVehicle = false;
					bool SpectatorList = false;
					bool KeybindList = false;
					bool RandomOutfit = false;
					bool TriggerHeal = false;
					bool TriggerArmor = false;
					bool TriggerSuicide = false;
					bool TriggerTeleport = false;
				} LocalPlayer;
				struct Weapon
				{
					bool NoReload;
					bool NoRecoil;
					bool NoSpread;
					bool RapidFire;
					bool OneShotKill;
					bool InfiniteAmmo;
				} Weapon;
			} Exploits;
			// Lua executor settings used via g_Options.Misc.Lua.
			struct LuaExecutor
			{
				bool Enabled = false;
				bool ShowConsole = true;
				char ScriptBuffer[8192] = "";
				std::vector<std::string> ScriptHistory;
				int HistoryIndex = 0;
				bool AutoExecute = false;
				std::string LastExecuted = "";
				bool ClearOnExecute = true;
			} Lua;
			bool Destruct = false;
			float FriendColor[4] = {0.f, 1.f, 0.f, 1.f};
		} Misc;
		struct General
		{
			bool ShutDown = false;
			int PanicKey = 0;
			int MenuKey = VK_INSERT;
			bool CaptureBypass = false;
			bool StreamMode = false;
			bool HideWatermark = false;
			bool Debug = false;
			int ThreadDelay = 1;
			std::string folderPath = "";
			std::string folderName = "";
			std::string sysPath = "";

			enum OverlayMode {
				OVERLAY_AUTO = 0,
				OVERLAY_WINDOW = 1,
				OVERLAY_HOOK = 2
			};

			OverlayMode overlayMode = OVERLAY_AUTO;
			bool enableExclusiveFullscreen = true;
			bool debugOverlay = false;
			bool autoSwitchMode = true;
			int modeSwitchDelay = 500;
		} General;
	};
}

inline Cheat::Options g_Options;