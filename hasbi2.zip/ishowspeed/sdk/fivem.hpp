#pragma once
#include <Windows.h>
#include <string>
#include <vector>

#include "../../ImGui/imgui.h"
#include "../../structure/math/Vectors/Vector2D.hpp"
#include "../../structure/math/Vectors/Vector3D.hpp"

using Vector3 = Vector3D;
using Vector2 = Vector2D;

namespace Cheat {
	struct VehicleInfo;
}

enum BoneId {
	SKEL_Head = 0,
	SKEL_Neck_1 = 1,
	SKEL_Spine3 = 2,
	SKEL_Pelvis = 3,
	SKEL_L_Clavicle = 4,
	SKEL_R_Clavicle = 5,
	SKEL_L_UpperArm = 6,
	SKEL_R_UpperArm = 7,
	SKEL_L_Forearm = 8,
	SKEL_R_Forearm = 9,
	SKEL_L_Hand = 10,
	SKEL_R_Hand = 11,
	SKEL_L_Thigh = 12,
	SKEL_R_Thigh = 13,
	SKEL_L_Calf = 14,
	SKEL_R_Calf = 15,
	SKEL_L_Foot = 16,
	SKEL_R_Foot = 17
};

namespace FiveM {
	namespace BlipColor {
		static constexpr int ColorWaypoint = 0;
	}

	namespace BlipSprite {
		static constexpr int SpriteWaypoint = 0;
	}

	enum CPedConfigFlag {
		CPED_CONFIG_FLAG_InVehicle = 0,
		CPED_CONFIG_FLAG_HideInCutscene = 1,
		CPED_CONFIG_FLAG_DisablePlayerLockon = 2,
		CPED_CONFIG_FLAG_DisableLockonToRandomPeds = 3,
		CPED_CONFIG_FLAG_UseAmbientModelScaling = 4
	};

	class CWeaponInfo {
	public:
		const std::string& GetWeaponName() const {
			static std::string empty;
			return empty;
		}
	};

	class CWeaponManager {
	public:
		CWeaponInfo* GetWeaponInfo() { return nullptr; }
	};

	class CVehicle;

	class CPed {
	public:
		bool HasConfigFlag(CPedConfigFlag) const { return false; }
		void SetConfigFlag(CPedConfigFlag, bool) {}
		CVehicle* GetLastVehicle() { return nullptr; }
		void* GetNavigation() { return nullptr; }
		uint64_t GetModelInfo() const { return 0; }
		Vector3D GetCoordinate() const { return {}; }
		void SetHealth(float) {}
		float GetHealth() const { return 100.0f; }
		float GetMaxHealth() const { return 100.0f; }
		float GetArmor() const { return 0.0f; }
		void SetArmor(float) {}
		void godmode_on(bool) {}
		void godmode_off(bool) {}
		bool IsGodMode() const { return false; }
		CWeaponManager* GetWeaponManager() { return nullptr; }
	};

	class CVehicle {
	public:
		void* GetNavigation() { return nullptr; }
		uint64_t GetModelInfo() const { return 0; }
		Vector3D GetCoordinate() const { return {}; }
		uint64_t GetDriver() const { return 0; }
		void RepairVehicleCompletely() {}
		void SetDoorLock(int) {}
	};

	struct EntityStaticInfo {
		CPed* Ped = nullptr;
		bool IsFriend = false;
		bool bIsNPC = false;
		bool bIsLocalPlayer = false;
		int NetId = -1;
		std::string Name;
	};

	struct Entity {
		EntityStaticInfo StaticInfo;
		Vector3D Cordinates{};
		bool Visible = true;
	};

	struct LocalPlayerInfo {
		CPed* Ped = nullptr;
		Vector3D WorldPos{};
	};

	class FollowPedCamera {
	public:
		Vector3D GetViewAngles() const { return {}; }
	};

	class CamGameplayDirector {
	public:
		FollowPedCamera* GetFollowPedCamera() { return nullptr; }
	};

	struct CPlayer {
		Vector3 Position{};
		Vector3 GetBonePosition(int) { return {}; }
		int GetHealth() { return 100; }
		std::string GetName() { return "Player"; }
		bool IsValid() { return true; }
		bool IsInitialized() { return true; }
		void Intialize() {}
		DWORD GetPid() { return 0; }
		void UpdateEntities() {}

		LocalPlayerInfo GetLocalPlayerInfo() { return {}; }
		bool FindClosestEntity(int, int, bool, Entity*) { return false; }
		Vector3D GetBonePosVec3(const Entity&, int) { return {}; }
		void ProcessCameraMovement(const Vector3D&, int, int) {}
		CPed* GetAimingEntity() { return nullptr; }
		std::vector<Entity> GetEntitiyListSafe() { return {}; }
		std::vector<Entity> GetEntitiyList() { return {}; }
		ImVec2 WorldToScreen(const Vector3D&) { return {}; }
		bool IsOnScreen(const ImVec2&) { return true; }
		std::string GetPlayerNameByNetId(int) { return {}; }
		void TeleportObject(uint64_t, uint64_t, uint64_t, const Vector3D&, const Vector3D&, bool) {}
		uint64_t GetBlipListAddress() { return 0; }
		CamGameplayDirector* GetCamGameplayDirector() { return nullptr; }
		std::vector<Cheat::VehicleInfo> GetVehicleList() { return {}; }
		bool IsFriendByNetId(int) { return false; }
		void RemoveFriendByNetId(int) {}
		void AddFriendByNetId(int) {}
	};

	inline std::vector<CPlayer*> GetPlayerList() { return {}; }
}

namespace Cheat {
	struct VehicleInfo {
		FiveM::CVehicle* Vehicle = nullptr;
		std::string Name;
		int iIndex = 0;
	};
}

namespace LuaExecutor {
	bool Initialize();
	void Shutdown();
	bool ExecuteScript(const std::string& script);
	extern std::string LastExecuted;
}

namespace FiveM {
	extern CPlayer g_Fivem;
}

namespace Cheat {
	inline FiveM::CPlayer& g_Fivem = FiveM::g_Fivem;
}

using FiveM::CPed;
using FiveM::CPedConfigFlag;
using FiveM::CPlayer;
using FiveM::CVehicle;
using FiveM::CWeaponInfo;
using FiveM::CWeaponManager;
using FiveM::Entity;
using FiveM::LocalPlayerInfo;

constexpr auto CPED_CONFIG_FLAG_InVehicle = FiveM::CPED_CONFIG_FLAG_InVehicle;
constexpr auto CPED_CONFIG_FLAG_HideInCutscene = FiveM::CPED_CONFIG_FLAG_HideInCutscene;
constexpr auto CPED_CONFIG_FLAG_DisablePlayerLockon = FiveM::CPED_CONFIG_FLAG_DisablePlayerLockon;
constexpr auto CPED_CONFIG_FLAG_DisableLockonToRandomPeds = FiveM::CPED_CONFIG_FLAG_DisableLockonToRandomPeds;
constexpr auto CPED_CONFIG_FLAG_UseAmbientModelScaling = FiveM::CPED_CONFIG_FLAG_UseAmbientModelScaling;

namespace BlipColor = FiveM::BlipColor;
namespace BlipSprite = FiveM::BlipSprite;

using FiveM::g_Fivem;