#include "PlayerNames.hpp"
#include "fivem.hpp"

#include <Psapi.h>
#include <TlHelp32.h>

std::vector<std::string> GetPlayerNames()
{
    std::vector<std::string> names;

    auto players = FiveM::GetPlayerList();
    for (auto player : players)
    {
        if (player && player->IsValid())
        {
            names.push_back(player->GetName());
        }
    }

    return names;
}

DWORD GetFiveMPid()
{
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (Process32First(snapshot, &pe32))
    {
        do
        {
            std::wstring name = pe32.szExeFile;
            if (name.find(L"FiveM.exe") != std::wstring::npos ||
                name.find(L"FiveM_GTAProcess.exe") != std::wstring::npos)
            {
                CloseHandle(snapshot);
                return pe32.th32ProcessID;
            }
        } while (Process32Next(snapshot, &pe32));
    }

    CloseHandle(snapshot);
    return 0;
}

std::string ReadPlayerNameFromProcess(DWORD pid)
{
    HANDLE hProcess = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!hProcess)
    {
        return "Unknown";
    }

    char buffer[256] = { 0 };

    CloseHandle(hProcess);
    return std::string(buffer);
}

void UpdatePlayerNames()
{
    DWORD pid = GetFiveMPid();
    if (pid)
    {
        if (FiveM::g_Fivem.IsValid())
        {
            std::string name = ReadPlayerNameFromProcess(pid);
            (void)name;
        }
    }
}