#pragma once

#include <Windows.h>

#include <string>
#include <vector>

std::vector<std::string> GetPlayerNames();
DWORD GetFiveMPid();
std::string ReadPlayerNameFromProcess(DWORD pid);
void UpdatePlayerNames();