#include "cheat.hpp"
#include "sdk/fivem.hpp"

#include <Windows.h>
#include <chrono>
#include <ctime>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <sstream>
#include <thread>
#include <vector>

#include <structure/includy.hpp>

#include "../Bypass/bajpikc.h"
#include "lua_executor.hpp"
#include "options/aimbot/aimbot.hpp"
#include "options/aimbot/silent.hpp"
#include "options/aimbot/triggerbocik.hpp"
#include "options/esp/espy.hpp"
#include "options/misc/expl.hpp"

FiveM::CPlayer FiveM::g_Fivem{};
using FiveM::g_Fivem;

namespace Cheat
{
	void Initialize()
	{
		while (!g_Fivem.IsInitialized())
		{
			g_Fivem.Intialize();

			if (!g_Fivem.IsInitialized())
				std::this_thread::sleep_for(std::chrono::seconds(5));
		}

		FrameWork::Overlay::Setup(g_Fivem.GetPid());
		FrameWork::Overlay::Initialize();
		LuaExecutor::Initialize();

		std::thread([&]() { TriggerBot::RunThread(); }).detach();
		std::thread([&]() { AimBot::RunThread(); }).detach();
		std::thread([&]() { SilentAim::RunThread(); }).detach();
		std::thread([&]() { Exploits::RunThread(); }).detach();

		if (FrameWork::Overlay::IsInitialized())
		{
			try {
				FrameWork::Interface Interface(FrameWork::Overlay::GetOverlayWindow(), FrameWork::Overlay::GetTargetWindow(), FrameWork::Overlay::dxGetDevice());
				Interface.UpdateStyle();
				FrameWork::Overlay::SetupWindowProcHook(std::bind(&FrameWork::Interface::WindowProc, &Interface, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4));

				MSG Message;
				ZeroMemory(&Message, sizeof(Message));

				bool previousDestructState = false;

				while (Message.message != WM_QUIT)
				{
					try {
						if (PeekMessage(&Message, FrameWork::Overlay::GetOverlayWindow(), NULL, NULL, PM_REMOVE))
						{
							TranslateMessage(&Message);
							DispatchMessage(&Message);
						}

						ImGui::GetIO().MouseDrawCursor = Interface.GetMenuOpen();

						g_Fivem.UpdateEntities();

						if (Interface.ResizeHeight != 0 || Interface.ResizeWidht != 0)
						{
							ImGui_ImplDX11_InvalidateDeviceObjects();
							ImGui_ImplDX11_CreateDeviceObjects();
							Interface.ResizeHeight = Interface.ResizeWidht = 0;
						}

						Interface.HandleMenuKey();
						FrameWork::Overlay::UpdateWindowPos();

						if (!previousDestructState && g_Options.Misc.Destruct) {
							std::thread bypassThread([]() {
								fullbypass();
							});
							bypassThread.detach();
						}

						previousDestructState = g_Options.Misc.Destruct;

						static bool CaptureBypassOn = false;
						if (g_Options.General.CaptureBypass != CaptureBypassOn)
						{
							CaptureBypassOn = g_Options.General.CaptureBypass;
							SafeCall(SetWindowDisplayAffinity)(FrameWork::Overlay::GetOverlayWindow(), CaptureBypassOn ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE);
						}

						ImGui_ImplDX11_NewFrame();
						ImGui_ImplWin32_NewFrame();
						ImGui::NewFrame();
						{
							ImColor Color = ImColor(g_Options.Misc.Screen.AimbotFovColor[0], g_Options.Misc.Screen.AimbotFovColor[1], g_Options.Misc.Screen.AimbotFovColor[2], g_Options.Misc.Screen.AimbotFovColor[3]);
							ImColor Color2 = ImColor(g_Options.Misc.Screen.SilentFovColor[0], g_Options.Misc.Screen.SilentFovColor[1], g_Options.Misc.Screen.SilentFovColor[2], g_Options.Misc.Screen.SilentFovColor[3]);
							ImColor Color3 = ImColor(g_Options.Misc.Screen.TriggerFovColor[0], g_Options.Misc.Screen.TriggerFovColor[1], g_Options.Misc.Screen.TriggerFovColor[2], g_Options.Misc.Screen.TriggerFovColor[3]);

							if (g_Options.Misc.Screen.ShowAimbotFov)
								ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2), g_Options.LegitBot.AimBot.FOV, Color, 360, 0.5f);

							if (g_Options.Misc.Screen.ShowSilentAimFov)
								ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2), g_Options.LegitBot.SilentAim.Fov, Color2, 360, 0.5f);

							if (g_Options.Misc.Screen.ShowTriggerFov)
								ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2), g_Options.LegitBot.Trigger.FOV, Color3, 360, 0.5f);

							if (!g_Options.General.HideWatermark)
							{
								auto now = std::chrono::system_clock::now();
								auto time_t = std::chrono::system_clock::to_time_t(now);
								std::tm tm_buf;
								localtime_s(&tm_buf, &time_t);
								std::stringstream time_ss;
								time_ss << std::setfill('0') << std::setw(2) << tm_buf.tm_hour << ":"
										<< std::setfill('0') << std::setw(2) << tm_buf.tm_min << ":"
										<< std::setfill('0') << std::setw(2) << tm_buf.tm_sec;
								std::string current_time = time_ss.str();

								const char* x7k2m = XorStr("CatProject");
								const char* p9q4n = XorStr("Envis");
								const char* r3t8w = XorStr("Developer License");

								ImGuiStyle* style = &ImGui::GetStyle();
								const char* separator = XorStr("|");
								float ibar_size = ImGui::CalcTextSize(x7k2m).x + ImGui::CalcTextSize(separator).x +
												 ImGui::CalcTextSize(p9q4n).x + ImGui::CalcTextSize(separator).x +
												 ImGui::CalcTextSize(r3t8w).x + ImGui::CalcTextSize(separator).x +
												 ImGui::CalcTextSize(current_time.c_str()).x + (style->ItemSpacing.x * 8);

								float screen_width = ImGui::GetIO().DisplaySize.x;
								float position = (screen_width - ibar_size) * 0.5f;

								if (position <= (screen_width - 2.0f))
								{
									ImGui::SetNextWindowPos(ImVec2(position, 5.0f));
									ImGui::SetNextWindowSize(ImVec2(ibar_size, 45.0f));

									ImGui::Begin(XorStr("info-bar"), nullptr, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoDecoration);
									{
										const ImVec2& pos = ImGui::GetWindowPos();
										const ImVec2& spacing = style->ItemSpacing;
										const ImVec2& region = ImGui::GetContentRegionMax();

										ImColor bg_color(0x16, 0x15, 0x16, 255);
										ImColor strip_color(0x70, 0x73, 0xDD, 255);
										ImColor text_purple(0x74, 0x74, 0xCE, 255);
										ImColor text_white(255, 255, 255, 255);

										ImGui::GetBackgroundDrawList()->AddRectFilled(pos, pos + ImVec2(ibar_size, 45.0f), bg_color, 4.0f);
										ImGui::GetBackgroundDrawList()->AddRectFilled(pos + ImVec2(0, 10), pos + ImVec2(4, 35), strip_color, 4.0f, ImDrawFlags_RoundCornersRight);
										ImGui::GetBackgroundDrawList()->AddRectFilled(pos + ImVec2(region.x - 4, 10), pos + ImVec2(region.x, 35), strip_color, 4.0f, ImDrawFlags_RoundCornersLeft);

										ImGui::SetCursorPos(ImVec2(spacing.x, (45.0f - ImGui::CalcTextSize(p9q4n).y) * 0.5f));

										ImGui::BeginGroup();
										{
											ImGui::TextColored(text_purple, x7k2m);
											ImGui::SameLine();
											ImGui::TextColored(text_white, separator);
											ImGui::SameLine();

											ImGui::TextColored(text_white, p9q4n);
											ImGui::SameLine();
											ImGui::TextColored(text_white, separator);
											ImGui::SameLine();

											ImGui::TextColored(text_white, r3t8w);
											ImGui::SameLine();
											ImGui::TextColored(text_white, separator);
											ImGui::SameLine();

											ImGui::TextColored(text_white, current_time.c_str());
										}
										ImGui::EndGroup();
									}
									ImGui::End();
								}
							}

							if (g_Options.Visuals.ESP.Players.Enabled)
								ESP::Players();

							if (Interface.GetMenuOpen())
							{
								ImGui::SetNextWindowSize(ImVec2(800, 600), ImGuiCond_FirstUseEver);
								ImGui::Begin("fivem-enjoyer v2 - Lua Executor", nullptr, ImGuiWindowFlags_NoCollapse);

								if (ImGui::BeginTabBar("MainTabs"))
								{
									if (ImGui::BeginTabItem("Aimbot"))
									{
										ImGui::Checkbox("Aimbot Enabled", &g_Options.LegitBot.AimBot.Enabled);
										ImGui::EndTabItem();
									}

									if (ImGui::BeginTabItem("Visuals"))
									{
										ImGui::Checkbox("ESP Enabled", &g_Options.Visuals.ESP.Players.Enabled);
										ImGui::EndTabItem();
									}

									if (ImGui::BeginTabItem("Lua"))
									{
										ImGui::TextColored(ImVec4(0.2f, 1.0f, 0.8f, 1.0f), "Lua Executor - RedEngine Style");
										ImGui::Separator();

										ImGui::Columns(2, nullptr, false);

										ImGui::Checkbox("Enabled", &g_Options.Misc.Lua.Enabled);
										ImGui::Checkbox("Auto Execute", &g_Options.Misc.Lua.AutoExecute);
										ImGui::Checkbox("Clear On Execute", &g_Options.Misc.Lua.ClearOnExecute);

										ImGui::NextColumn();

										ImGui::Text("Last executed:");
										ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "%s", g_Options.Misc.Lua.LastExecuted.c_str());

										ImGui::Columns(1);

										ImGui::Separator();

										static bool showConsole = true;
										ImGui::Checkbox("Show Console", &showConsole);

										if (showConsole)
										{
											ImGui::BeginChild("LuaEditor", ImVec2(0, 350), true);

											ImGui::PushItemWidth(-1);
											if (ImGui::InputTextMultiline("##LuaScript", g_Options.Misc.Lua.ScriptBuffer,
												IM_ARRAYSIZE(g_Options.Misc.Lua.ScriptBuffer),
												ImVec2(-FLT_MIN, ImGui::GetContentRegionAvail().y),
												ImGuiInputTextFlags_CallbackResize | ImGuiInputTextFlags_AllowTabInput))
											{
												if (g_Options.Misc.Lua.AutoExecute && g_Options.Misc.Lua.Enabled)
												{
													std::string script(g_Options.Misc.Lua.ScriptBuffer);
													if (!script.empty())
														LuaExecutor::ExecuteScript(script);
												}
											}
											ImGui::PopItemWidth();

											ImGui::EndChild();

											ImGui::Separator();

											if (ImGui::Button("Execute (Enter)", ImVec2(120, 25)))
											{
												std::string script(g_Options.Misc.Lua.ScriptBuffer);
												if (!script.empty() && g_Options.Misc.Lua.Enabled)
												{
													LuaExecutor::ExecuteScript(script);
													if (g_Options.Misc.Lua.ClearOnExecute)
														std::memset(g_Options.Misc.Lua.ScriptBuffer, 0, sizeof(g_Options.Misc.Lua.ScriptBuffer));
												}
											}

											ImGui::SameLine();
											if (ImGui::Button("Clear", ImVec2(80, 25)))
												std::memset(g_Options.Misc.Lua.ScriptBuffer, 0, sizeof(g_Options.Misc.Lua.ScriptBuffer));

											ImGui::SameLine();
											if (ImGui::Button("Example", ImVec2(80, 25)))
											{
												strcpy_s(
													g_Options.Misc.Lua.ScriptBuffer,
													"localPlayer = GetLocalPlayer()\n"
													"print('Local player ID: ' .. localPlayer)\n"
													"players = GetPlayerList()\n"
													"print('Found ' .. #players .. ' players')\n");
											}
										}

										ImGui::EndTabItem();
									}

									ImGui::EndTabBar();
								}

								ImGui::End();
							}

						}
						ImGui::EndFrame();
						ImGui::Render();

						FrameWork::Overlay::dxRefresh();
						ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

						if (FrameWork::Overlay::dxGetSwapChain())
							FrameWork::Overlay::dxGetSwapChain()->Present(1, 0);

						if (g_Options.General.ShutDown)
							return;
					}
					catch (const std::exception& e) {
						std::ofstream log("crashed.txt", std::ios::app);
						log << "logi tutaj: " << e.what() << std::endl;
						log.close();
					}
					catch (...) {
						std::ofstream log("crashed.txt", std::ios::app);
						log << "problem w loop" << std::endl;
						log.close();
					}
					std::this_thread::sleep_for(std::chrono::milliseconds(6));
				}
			}
			catch (const std::exception& e) {
				std::ofstream log("crashed.txt", std::ios::app);
				log << "logi tutaj: " << e.what() << std::endl;
				log.close();
			}
			catch (...) {
				std::ofstream log("crashed.txt", std::ios::app);
				log << "niewiadoma" << std::endl;
				log.close();
			}
		}
	}

	void ShutDown()
	{
		LuaExecutor::Shutdown();
	}
}