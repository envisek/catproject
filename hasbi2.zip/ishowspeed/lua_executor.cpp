#include "lua_executor.hpp"
#include <imgui.h>
#include "options/aimbot/triggerbocik.hpp"
#include <fstream>
#include <sstream>

lua_State* LuaExecutor::L = nullptr;

bool LuaExecutor::Initialize()
{
    L = luaL_newstate();
    if (!L) return false;
    
    luaL_openlibs(L);
    
    // Register FiveM functions
    lua_register(L, "GetLocalPlayer", GetLocalPlayer);
    lua_register(L, "GetPlayerList", GetPlayerList);
    lua_register(L, "GetPlayerPos", GetPlayerPos);
    lua_register(L, "SetPlayerPos", SetPlayerPos);
    lua_register(L, "TeleportToPlayer", TeleportToPlayer);
    lua_register(L, "TriggerEvent", TriggerEvent);
    lua_register(L, "GetEntityHealth", GetEntityHealth);
    lua_register(L, "SetEntityHealth", SetEntityHealth);
    lua_register(L, "GetScreenSize", GetScreenSize);
    lua_register(L, "WorldToScreen", WorldToScreen);
    
    // Utilities
    lua_register(L, "print", Print);
    lua_register(L, "log", Log);
    lua_register(L, "GetDistance", GetDistance);
    
    return true;
}

void LuaExecutor::Shutdown()
{
    if (L) {
        lua_close(L);
        L = nullptr;
    }
}

void LuaExecutor::ExecuteScript(const std::string& script)
{
    if (!L || script.empty()) return;
    
    int result = luaL_dostring(L, script.c_str());
    if (result != LUA_OK) {
        const char* error = lua_tostring(L, -1);
        // Log error to console/file
        char errorMsg[1024];
        sprintf_s(errorMsg, "[Lua Error] %s\n", error);
        OutputDebugStringA(errorMsg);
        lua_pop(L, 1);
    }
    
    // Add to history
    if (!script.empty()) {
        g_Options.Misc.Lua.ScriptHistory.push_back(script);
        if (g_Options.Misc.Lua.ScriptHistory.size() > 50)
            g_Options.Misc.Lua.ScriptHistory.erase(g_Options.Misc.Lua.ScriptHistory.begin());
        g_Options.Misc.Lua.LastExecuted = script.substr(0, 100);
    }
}

void LuaExecutor::RunThread()
{
    // Lua executor runs in main thread via ImGui callbacks
}

// Lua function implementations
int LuaExecutor::Print(lua_State* L)
{
    int n = lua_gettop(L);
    std::string result;
    for (int i = 1; i <= n; i++) {
        result += lua_tostring(L, i);
        if (i < n) result += "\t";
    }
    printf("[Lua] %s\n", result.c_str());
    OutputDebugStringA(("[Lua] " + result + "\n").c_str());
    return 0;
}

int LuaExecutor::Log(lua_State* L)
{
    int n = lua_gettop(L);
    std::string result;
    for (int i = 1; i <= n; i++) {
        result += lua_tostring(L, i);
        if (i < n) result += "\t";
    }
    
    // Save to log file
    std::ofstream log("lua_log.txt", std::ios::app);
    log << "[Lua] " << result << std::endl;
    log.close();
    
    return 0;
}

int LuaExecutor::GetLocalPlayer(lua_State* L)
{
    lua_pushinteger(L, g_Fivem.GetLocalPlayer());
    return 1;
}

int LuaExecutor::GetPlayerList(lua_State* L)
{
    lua_newtable(L);
    auto players = g_Fivem.GetPlayers();
    for (int i = 0; i < players.size(); i++) {
        lua_pushinteger(L, i + 1);
        lua_pushinteger(L, players[i]);
        lua_settable(L, -3);
    }
    return 1;
}

int LuaExecutor::GetPlayerPos(lua_State* L)
{
    int player = lua_tointeger(L, 1);
    auto pos = g_Fivem.GetPlayerPosition(player);
    
    lua_newtable(L);
    lua_pushstring(L, "x"); lua_pushnumber(L, pos.x); lua_settable(L, -3);
    lua_pushstring(L, "y"); lua_pushnumber(L, pos.y); lua_settable(L, -3);
    lua_pushstring(L, "z"); lua_pushnumber(L, pos.z); lua_settable(L, -3);
    
    return 1;
}

int LuaExecutor::SetPlayerPos(lua_State* L)
{
    int player = lua_tointeger(L, 1);
    float x = (float)lua_tonumber(L, 2);
    float y = (float)lua_tonumber(L, 3);
    float z = (float)lua_tonumber(L, 4);
    
    g_Fivem.SetPlayerPosition(player, {x, y, z});
    return 0;
}

int LuaExecutor::TeleportToPlayer(lua_State* L)
{
    int target = lua_tointeger(L, 1);
    auto targetPos = g_Fivem.GetPlayerPosition(target);
    g_Fivem.SetPlayerPosition(g_Fivem.GetLocalPlayer(), targetPos);
    return 0;
}

// Add other functions similarly...
int LuaExecutor::GetEntityHealth(lua_State* L)
{
    int entity = lua_tointeger(L, 1);
    lua_pushnumber(L, g_Fivem.GetEntityHealth(entity));
    return 1;
}

int LuaExecutor::SetEntityHealth(lua_State* L)
{
    int entity = lua_tointeger(L, 1);
    float health = (float)lua_tonumber(L, 2);
    g_Fivem.SetEntityHealth(entity, health);
    return 0;
}

int LuaExecutor::GetScreenSize(lua_State* L)
{int LuaExecutor::GetScreenSize(lua_State* L)
{
    ImVec2 size = ImGui::GetIO().DisplaySize;
    lua_newtable(L);
    lua_pushstring(L, "w"); lua_pushnumber(L, size.x); lua_settable(L, -3);
    lua_pushstring(L, "h"); lua_pushnumber(L, size.y); lua_settable(L, -3);
    lua_pushstring(L, "x"); lua_pushnumber(L, size.x); lua_settable(L, -3);
    lua_pushstring(L, "y"); lua_pushnumber(L, size.y); lua_settable(L, -3);
    return 1;
}

int LuaExecutor::WorldToScreen(lua_State* L)
{
    Vector3 worldPos = {
        (float)lua_tonumber(L, 1),
        (float)lua_tonumber(L, 2),
        (float)lua_tonumber(L, 3)
    };
    
    Vector2 screenPos;
    if (g_Fivem.WorldToScreen(worldPos, screenPos)) {
        lua_newtable(L);
        lua_pushstring(L, "x"); lua_pushnumber(L, screenPos.x); lua_settable(L, -3);
        lua_pushstring(L, "y"); lua_pushnumber(L, screenPos.y); lua_settable(L, -3);
        lua_pushstring(L, "onscreen"); lua_pushboolean(L, true); lua_settable(L, -3);
    } else {
        lua_pushboolean(L, false);
    }
    return 1;
}

int LuaExecutor::GetDistance(lua_State* L)
{
    float x1 = (float)lua_tonumber(L, 1);
    float y1 = (float)lua_tonumber(L, 2);
    float z1 = (float)lua_tonumber(L, 3);
    float x2 = (float)lua_tonumber(L, 4);
    float y2 = (float)lua_tonumber(L, 5);
    float z2 = (float)lua_tonumber(L, 6);
    
    float dx = x2 - x1;
    float dy = y2 - y1;
    float dz = z2 - z1;
    lua_pushnumber(L, sqrt(dx*dx + dy*dy + dz*dz));
    return 1;
}