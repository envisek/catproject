#pragma once

#include <string>
#include <vector>
#include <set>

#include <structure/includy.hpp>
#include <structure/services/base64.hpp>

#include "options.hpp"

namespace Cheat
{
	class ConfigManager
	{
	public:
		class C_ConfigItem
		{
		public:
			std::string Name;
			void* Pointer;
			std::string Type;

			C_ConfigItem(std::string Name, void* Pointer, std::string Type)
			{
				this->Name = Name;
				this->Pointer = Pointer;
				this->Type = Type;
			}
		};

		std::vector<C_ConfigItem*> Items;

		void AddItem(void* Pointer, const char* Name, const std::string& Type);

		void SetupItem(int* Pointer, float Value, const std::string& Name);

		void SetupItem(float* Pointer, float Value, const std::string& Name);

		void SetupItem(bool* Pointer, float Value, const std::string& Name);

		void Setup();

		ConfigManager()
		{
			Setup();
		};

		void ExportToClipboard();
		void ExportToFile();
		void ImportFromClipboard();
		void ImportFromFile();

		bool LoadConfig(); // Returns true if config was successfully loaded, false otherwise
		void SaveConfig();

		void LoadConfigFromFile(const std::string& filePath);
		void SaveConfigToFile(const std::string& filePath);
	};
}



















