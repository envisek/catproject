#pragma once

#include "options.hpp"

namespace Cheat {
	void Initialize();
	void ShutDown();
}