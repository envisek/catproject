#pragma once

#include <Windows.h>
#include <string>
#include <vector>

#if defined(__has_include)
#if __has_include(<lua.hpp>)
#include <lua.hpp>
#define LUA_EXECUTOR_HAS_LUA 1
#elif __has_include("lua.hpp")
#include "lua.hpp"
#define LUA_EXECUTOR_HAS_LUA 1
#elif __has_include(<lua/lua.hpp>)
#include <lua/lua.hpp>
#define LUA_EXECUTOR_HAS_LUA 1
#else
#define LUA_EXECUTOR_HAS_LUA 0
struct lua_State;
#endif
#else
#include <lua.hpp>
#define LUA_EXECUTOR_HAS_LUA 1
#endif

#if !LUA_EXECUTOR_HAS_LUA
struct lua_State;
#endif

#include "sdk/fivem.hpp"
#include "cheat.hpp"

namespace LuaExecutor
{
    extern lua_State* L;

    bool Initialize();
    void Shutdown();
    bool ExecuteScript(const std::string& script);
    void RunThread();

    // FiveM/Lua API bindings
    int GetLocalPlayer(lua_State* L);
    int GetPlayerList(lua_State* L);
    int GetPlayerPos(lua_State* L);
    int SetPlayerPos(lua_State* L);
    int TeleportToPlayer(lua_State* L);
    int TriggerEvent(lua_State* L);
    int GetEntityHealth(lua_State* L);
    int SetEntityHealth(lua_State* L);
    int GetScreenSize(lua_State* L);
    int WorldToScreen(lua_State* L);

    // Utility functions
    int Print(lua_State* L);
    int Log(lua_State* L);
    int GetDistance(lua_State* L);
}