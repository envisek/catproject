#include "configs.hpp"
#include <fstream>
#include <filesystem>
#include <Windows.h>
#include <wincrypt.h>
#pragma comment(lib, "crypt32.lib")

namespace Cheat
{
    namespace {
        static bool DpapiEncryptToBase64(const std::string& plain, std::string& outBase64)
        {
            DATA_BLOB in{}; in.cbData = static_cast<DWORD>(plain.size()); in.pbData = (BYTE*)plain.data();
            const char* entropyChars = "HasbiCfgV1";
            DATA_BLOB entropy{}; entropy.cbData = static_cast<DWORD>(strlen(entropyChars)); entropy.pbData = (BYTE*)entropyChars;
            DATA_BLOB out{};
            if (!CryptProtectData(&in, L"HasbiCfg", &entropy, nullptr, nullptr, 0, &out))
                return false;
            std::string cipher(reinterpret_cast<char*>(out.pbData), reinterpret_cast<char*>(out.pbData) + out.cbData);
            outBase64 = base64::encode(cipher);
            if (out.pbData) LocalFree(out.pbData);
            return true;
        }

        static bool DpapiDecryptFromBase64(const std::string& inBase64, std::string& outPlain)
        {
            std::string cipher = base64::decode(inBase64);
            if (cipher.empty()) return false;
            DATA_BLOB in{}; in.cbData = static_cast<DWORD>(cipher.size()); in.pbData = (BYTE*)cipher.data();
            const char* entropyChars = "HasbiCfgV1";
            DATA_BLOB entropy{}; entropy.cbData = static_cast<DWORD>(strlen(entropyChars)); entropy.pbData = (BYTE*)entropyChars;
            DATA_BLOB out{};
            LPWSTR desc = nullptr;
            if (!CryptUnprotectData(&in, &desc, &entropy, nullptr, nullptr, 0, &out))
                return false;
            outPlain.assign(reinterpret_cast<char*>(out.pbData), reinterpret_cast<char*>(out.pbData) + out.cbData);
            if (desc) LocalFree(desc);
            if (out.pbData) LocalFree(out.pbData);
            return true;
        }
    }
	void ConfigManager::AddItem(void* Pointer, const char* Name, const std::string& Type)
	{
		Items.push_back(new C_ConfigItem(std::string(Name), Pointer, Type));
	}

	void ConfigManager::SetupItem(int* Pointer, float Value, const std::string& Name)
	{
		AddItem(Pointer, Name.c_str(), ("int"));
		*Pointer = Value;
	}

	void ConfigManager::SetupItem(float* Pointer, float Value, const std::string& Name)
	{
		AddItem(Pointer, Name.c_str(), ("float"));
		*Pointer = Value;
	}

	void ConfigManager::SetupItem(bool* Pointer, float Value, const std::string& Name)
	{
		AddItem(Pointer, Name.c_str(), ("bool"));
		*Pointer = Value;
	}

	void ConfigManager::Setup()
	{
		// aimbot
		SetupItem(&g_Options.LegitBot.AimBot.Enabled, true, ("abt_enabled"));
		SetupItem(&g_Options.LegitBot.AimBot.KeyBind, 0, ("abt_key"));
		SetupItem(&g_Options.LegitBot.AimBot.TargetNPC, false, ("abt_targetnpc"));
		SetupItem(&g_Options.LegitBot.AimBot.HitBox, 0, ("abt_hitbox"));
		SetupItem(&g_Options.LegitBot.AimBot.MaxDistance, 250, ("abt_maxdistance"));
		SetupItem(&g_Options.LegitBot.AimBot.FOV, 90, ("abt_fov"));
		SetupItem(&g_Options.LegitBot.AimBot.SmoothVertical, 80, ("abt_smoothvertical"));
		SetupItem(&g_Options.LegitBot.AimBot.SmoothHorizontal, 80, ("abt_smoothhorizontal"));
		SetupItem(&g_Options.LegitBot.AimBot.Prediction, false, ("abt_prediction"));
		SetupItem(&g_Options.LegitBot.AimBot.VisibleCheck, false, ("VisibleCheck"));
		SetupItem(&g_Options.LegitBot.AimBot.SecondFov, 0, ("abt_secondfov"));
		SetupItem(&g_Options.LegitBot.AimBot.SyncSilentFov, false, ("abt_syncsilentfov"));
		// trigger
		SetupItem(&g_Options.LegitBot.Trigger.Enabled, true, ("trtg_enabled"));
		SetupItem(&g_Options.LegitBot.Trigger.KeyBind, 0, ("trtg_key"));
		SetupItem(&g_Options.LegitBot.Trigger.FOV, 90, ("triggerfov_key"));
		SetupItem(&g_Options.LegitBot.Trigger.ShotNPC, false, ("trtg_shotnpc"));
		SetupItem(&g_Options.LegitBot.Trigger.MaxDistance, 250, ("trtg_maxdistance"));
		SetupItem(&g_Options.LegitBot.Trigger.ReactionTime, 0, ("trtg_reactiontime"));
		SetupItem(&g_Options.LegitBot.Trigger.VisibleCheck, false, ("VisibleCheck_trigger"));
		// silent aim
		SetupItem(&g_Options.LegitBot.SilentAim.Enabled, true, ("slt_enabled"));
		SetupItem(&g_Options.LegitBot.SilentAim.Fov, 90, ("slt_fov"));
		SetupItem(&g_Options.LegitBot.SilentAim.KeyBind, 0, ("slt_key"));
		SetupItem(&g_Options.LegitBot.SilentAim.ShotNPC, false, ("slt_shotnpc"));
		SetupItem(&g_Options.LegitBot.SilentAim.ShotDead, true, ("trtg_shotdead"));
		SetupItem(&g_Options.LegitBot.SilentAim.MaxDistance, 250, ("slt_maxdistance"));
		SetupItem(&g_Options.LegitBot.SilentAim.HitBox, 0, ("slt_hitbox"));
		SetupItem(&g_Options.LegitBot.SilentAim.VisibleCheck, false, ("VisibleCheck_silent"));
		SetupItem(&g_Options.LegitBot.SilentAim.Prediction, false, ("slt_prediction"));
		SetupItem(&g_Options.LegitBot.SilentAim.MagicBullet, false, ("slt_magicbullet"));
		SetupItem(&g_Options.LegitBot.SilentAim.ForceDriver, false, ("slt_forcedriver"));
		SetupItem(&g_Options.LegitBot.SilentAim.AutoShoot, false, ("slt_autoshoot"));
		SetupItem(&g_Options.LegitBot.SilentAim.AutoDistance, false, ("slt_autodistance"));
		SetupItem(&g_Options.LegitBot.SilentAim.AliveOnly, false, ("slt_aliveonly"));
		SetupItem(&g_Options.LegitBot.SilentAim.RageFov, 0, ("slt_ragefov"));
		SetupItem(&g_Options.LegitBot.SilentAim.AutoShootDelay, 500, ("slt_autoshootdelay"));
		// miscellaneous
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.norecoil, false, ("norecoil"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.nospread, false, ("nospread"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.speed, false, ("speedwalkenabled"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.Player_speed, 1.f, ("speedwalkamount"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.noreload, false, ("noreload"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.God, false, ("God Mode"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.shrink, false, ("shrink"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.Noclip, false, ("Noclip"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.NoclipBind, false, ("NoclipBind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.NoclipSpeed, 50, ("NoclipSpeed"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.Invisible, false, ("Invisible"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.Shrink, false, ("Shrink"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.SpeedRun, false, ("SpeedRun"));
		SetupItem(&g_Options.Misc.Destruct, false, ("Destruct"));
		// weapon
		SetupItem(&g_Options.Misc.Exploits.Weapon.NoReload, false, ("weapon_noreload"));
		SetupItem(&g_Options.Misc.Exploits.Weapon.NoRecoil, false, ("weapon_norecoil"));
		SetupItem(&g_Options.Misc.Exploits.Weapon.NoSpread, false, ("weapon_nospread"));
		SetupItem(&g_Options.Misc.Exploits.Weapon.RapidFire, false, ("weapon_rapidfire"));
		SetupItem(&g_Options.Misc.Exploits.Weapon.OneShotKill, false, ("weapon_oneshotkill"));
		SetupItem(&g_Options.Misc.Exploits.Weapon.InfiniteAmmo, false, ("weapon_infiniteammo"));
		// esp player
		SetupItem(&g_Options.Visuals.ESP.Players.Enabled, true, ("esp_players_enabled"));
		SetupItem(&g_Options.Visuals.ESP.Players.ShowLocalPlayer, false, ("esp_players_localplayer"));
		SetupItem(&g_Options.Visuals.ESP.Players.ShowNPCs, false, ("esp_players_npscs"));
		SetupItem(&g_Options.Visuals.ESP.Players.ShowDead, false, ("esp_players_showdead"));
		SetupItem(&g_Options.Visuals.ESP.Players.RenderDistance, 250, ("esp_players_renderdist"));
		SetupItem(&g_Options.Visuals.ESP.Players.Box, false, ("esp_players_box"));
		SetupItem(&g_Options.Visuals.ESP.Players.FilledBox, false, ("esp_players_filledbox"));
		SetupItem(&g_Options.Visuals.ESP.Players.Skeleton, false, ("esp_players_skel"));
		SetupItem(&g_Options.Visuals.ESP.Players.Name, false, ("esp_players_name"));
		SetupItem(&g_Options.Visuals.ESP.Players.HealthBar, 0, ("esp_players_healthbar"));
		SetupItem(&g_Options.Visuals.ESP.Players.ArmorBar, 0, ("esp_players_armorbar"));
		SetupItem(&g_Options.Visuals.ESP.Players.WeaponName, 0, ("esp_players_weapname"));
		SetupItem(&g_Options.Visuals.ESP.Players.Distance, false, ("esp_players_distance"));
		SetupItem(&g_Options.Visuals.ESP.Players.SnapLines, false, ("esp_players_snampli"));
		// esp color
		SetupItem(&g_Options.Visuals.ESP.Players.SkeletonColor[0], 1.f, ("esp_players_skelco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.SkeletonColor[1], 1.f, ("esp_players_skelco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.SkeletonColor[2], 1.f, ("esp_players_skelco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.SkeletonColor[3], 1.f, ("esp_players_skelco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.NameColor[0], 1.f, ("esp_players_NAMEco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.NameColor[1], 1.f, ("esp_players_NAMEco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.NameColor[2], 1.f, ("esp_players_NAMEco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.NameColor[3], 1.f, ("esp_players_NAMEco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.WeaponNameColor[0], 1.f, ("esp_players_weaponNAMEco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.WeaponNameColor[1], 1.f, ("esp_players_weaponNAMEco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.WeaponNameColor[2], 1.f, ("esp_players_weaponNAMEco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.WeaponNameColor[3], 1.f, ("esp_players_weaponNAMEco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.DistanceColor[0], 1.f, ("esp_players_distanceco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.DistanceColor[1], 1.f, ("esp_players_distanceco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.DistanceColor[2], 1.f, ("esp_players_distanceco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.DistanceColor[3], 1.f, ("esp_players_distanceco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.SnaplinesColor[0], 1.f, ("esp_players_snaplinesco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.SnaplinesColor[1], 1.f, ("esp_players_snaplinesco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.SnaplinesColor[2], 1.f, ("esp_players_snaplinesco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.SnaplinesColor[3], 1.f, ("esp_players_snaplinesco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.HeadColor[0], 1.f, ("esp_players_headco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.HeadColor[1], 1.f, ("esp_players_headco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.HeadColor[2], 1.f, ("esp_players_headco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.HeadColor[3], 1.f, ("esp_players_headco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.BoxColor[0], 1.f, ("esp_players_boxco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.BoxColor[1], 1.f, ("esp_players_boxco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.BoxColor[2], 1.f, ("esp_players_boxco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.BoxColor[3], 1.f, ("esp_players_boxco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.CornerBoxColor[0], 0.f, ("esp_players_cornerboxco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.CornerBoxColor[1], 1.f, ("esp_players_cornerboxco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.CornerBoxColor[2], 1.f, ("esp_players_cornerboxco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.CornerBoxColor[3], 1.f, ("esp_players_cornerboxco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.FilledBoxColor[0], 0.33f, ("esp_players_filledboxco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.FilledBoxColor[1], 0.33f, ("esp_players_filledboxco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.FilledBoxColor[2], 0.33f, ("esp_players_filledboxco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.FilledBoxColor[3], 0.33f, ("esp_players_filledboxco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.HealthBarColor[0], 1.f, ("esp_players_hltco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.HealthBarColor[1], 1.f, ("esp_players_hltco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.HealthBarColor[2], 1.f, ("esp_players_hltco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.HealthBarColor[3], 1.f, ("esp_players_hltco3"));
		SetupItem(&g_Options.Visuals.ESP.Players.ArmorBarColor[0], 1.f, ("esp_players_armco0"));
		SetupItem(&g_Options.Visuals.ESP.Players.ArmorBarColor[1], 1.f, ("esp_players_armco1"));
		SetupItem(&g_Options.Visuals.ESP.Players.ArmorBarColor[2], 1.f, ("esp_players_armco2"));
		SetupItem(&g_Options.Visuals.ESP.Players.ArmorBarColor[3], 1.f, ("esp_players_armco3"));

		// esp vehicle
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Enabled, false, ("esp_vehicles_enabled"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Color[0], 1.f, ("esp_vehicles_col0"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Color[1], 1.f, ("esp_vehicles_col1"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Color[2], 1.f, ("esp_vehicles_col2"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Color[3], 1.f, ("esp_vehicles_col3"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Name, false, ("esp_vehicles_name"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Distance, false, ("esp_vehicles_distance"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.Marker, false, ("esp_vehicles_marker"));
		SetupItem(&g_Options.Visuals.ESP.Vehicles.IgnoreOccupiedVehicles, false, ("esp_vehicles_ignoreoccupied"));

		// screen
		SetupItem(&g_Options.Misc.Screen.ShowAimbotFov, 0, ("misc_screen_showaimbotfov"));
		SetupItem(&g_Options.Misc.Screen.AimbotFovColor[0], 1.f, ("aimbotfovco0"));
		SetupItem(&g_Options.Misc.Screen.AimbotFovColor[1], 1.f, ("aimbotfovco1"));
		SetupItem(&g_Options.Misc.Screen.AimbotFovColor[2], 1.f, ("aimbotfovco2"));
		SetupItem(&g_Options.Misc.Screen.AimbotFovColor[3], 1.f, ("aimbotfovco3"));
		SetupItem(&g_Options.Misc.Screen.ShowSilentAimFov, 0, ("misc_screen_showsilentfov"));
		SetupItem(&g_Options.Misc.Screen.ShowSilentAimRageFov, 0, ("misc_screen_showsilentragefov"));
		SetupItem(&g_Options.Misc.Screen.SilentFovColor[0], 1.f, ("silentfovco0"));
		SetupItem(&g_Options.Misc.Screen.SilentFovColor[1], 1.f, ("silentfovco1"));
		SetupItem(&g_Options.Misc.Screen.SilentFovColor[2], 1.f, ("silentfovco2"));
		SetupItem(&g_Options.Misc.Screen.SilentFovColor[3], 1.f, ("silentfovco3"));
		SetupItem(&g_Options.Misc.Screen.ShowTriggerFov, 0, ("misc_screen_showtriggerfov"));
		SetupItem(&g_Options.Misc.Screen.TriggerFovColor[0], 1.f, ("triggerfovco0"));
		SetupItem(&g_Options.Misc.Screen.TriggerFovColor[1], 1.f, ("triggerfovco1"));
		SetupItem(&g_Options.Misc.Screen.TriggerFovColor[2], 1.f, ("triggerfovco2"));
		SetupItem(&g_Options.Misc.Screen.TriggerFovColor[3], 1.f, ("triggerfovco3"));

		// aimbot colors
		SetupItem(&g_Options.Misc.Screen.AimbotMinColor[0], 224 / 255.f, ("aimbotminco0"));
		SetupItem(&g_Options.Misc.Screen.AimbotMinColor[1], 110 / 255.f, ("aimbotminco1"));
		SetupItem(&g_Options.Misc.Screen.AimbotMinColor[2], 109 / 255.f, ("aimbotminco2"));
		SetupItem(&g_Options.Misc.Screen.AimbotMinColor[3], 1.f, ("aimbotminco3"));
		SetupItem(&g_Options.Misc.Screen.AimbotMaxColor[0], 224 / 255.f, ("aimbotmaxco0"));
		SetupItem(&g_Options.Misc.Screen.AimbotMaxColor[1], 110 / 255.f, ("aimbotmaxco1"));
		SetupItem(&g_Options.Misc.Screen.AimbotMaxColor[2], 109 / 255.f, ("aimbotmaxco2"));
		SetupItem(&g_Options.Misc.Screen.AimbotMaxColor[3], 1.f, ("aimbotmaxco3"));
		SetupItem(&g_Options.Misc.Screen.SilentAimColor[0], 1 / 255.f, ("silentaimco0"));
		SetupItem(&g_Options.Misc.Screen.SilentAimColor[1], 253 / 255.f, ("silentaimco1"));
		SetupItem(&g_Options.Misc.Screen.SilentAimColor[2], 254 / 255.f, ("silentaimco2"));
		SetupItem(&g_Options.Misc.Screen.SilentAimColor[3], 1.f, ("silentaimco3"));
		SetupItem(&g_Options.Misc.Screen.RageSilentAimColor[0], 253 / 255.f, ("ragesilentaimco0"));
		SetupItem(&g_Options.Misc.Screen.RageSilentAimColor[1], 1 / 255.f, ("ragesilentaimco1"));
		SetupItem(&g_Options.Misc.Screen.RageSilentAimColor[2], 2 / 255.f, ("ragesilentaimco2"));
		SetupItem(&g_Options.Misc.Screen.RageSilentAimColor[3], 1.f, ("ragesilentaimco3"));

		// other
		SetupItem(&g_Options.Misc.Other.legit_mode, false, ("misc_other_legitmode"));
		SetupItem(&g_Options.Misc.Other.anti_screenshot, false, ("misc_other_antiscreenshot"));

		// friend color
		SetupItem(&g_Options.Misc.FriendColor[0], 1.f, ("esp_FriendsColor0"));
		SetupItem(&g_Options.Misc.FriendColor[1], 1.f, ("esp_FriendsColor1"));
		SetupItem(&g_Options.Misc.FriendColor[2], 1.f, ("esp_FriendsColor2"));
		SetupItem(&g_Options.Misc.FriendColor[3], 1.f, ("esp_FriendsColor3"));

		// menu
		SetupItem(&g_Options.General.CaptureBypass, false, ("captbypss"));
		SetupItem(&g_Options.General.MenuKey, VK_INSERT, ("mnkey"));

		// bind
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.godbind, 0, ("godmodekeybind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.tpbind, 0, ("tpwaykeybind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.unlockbind, 0, ("unlockkeybind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.HealBind, 0, ("healbind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.ArmorBind, 0, ("armorbind"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.RepairVehicle, false, ("repairvehicle"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.SpectatorList, false, ("spectatorlist"));
		SetupItem(&g_Options.Misc.Exploits.LocalPlayer.KeybindList, false, ("keybindlist"));
	}

	bool ConfigManager::LoadConfig()
	{
		static auto ReadFromFile = [](const std::string& filePath) -> std::string
			{
				std::ifstream inFile(filePath);
				if (!inFile.is_open()) {
					return "";
				}

				std::string fileContent((std::istreambuf_iterator<char>(inFile)),
					std::istreambuf_iterator<char>());
				inFile.close();
				return fileContent;
			};

		static auto find_item = [](std::vector< C_ConfigItem* > items, std::string name) -> C_ConfigItem*
			{
				for (int i = 0; i < (int)items.size(); i++)
					if (!items[i]->Name.compare(name))
						return items[i];

				return nullptr;
			};

		auto fileContent = ReadFromFile("C:\\Windows\\System32\\readme.txt");

		if (fileContent.empty()) {
			return false; // Config file doesn't exist, defaults from Setup() will be used
		}

		auto decoded_string = base64::decode(fileContent);

		if (decoded_string.length() < 8 ||
			decoded_string[0] != 'n' ||
			decoded_string[1] != 'i' ||
			decoded_string[2] != 'g' ||
			decoded_string[3] != 'a' ||
			decoded_string[4] != 't' ||
			decoded_string[5] != 'v' ||
			decoded_string[6] != '-' ||
			decoded_string[7] != ' ')
			return false; // Invalid config file, defaults from Setup() will be used

		try {
			auto parsed_config = nlohmann::json::parse(decoded_string.erase(0, 8));

			nlohmann::json allJson = parsed_config;

			for (auto it = allJson.begin(); it != allJson.end(); ++it)
			{
				nlohmann::json j = *it;

				std::string name = j[("name")];
				std::string type = j[("type")];

				auto item = find_item(Items, name);

				if (item)
				{
					if (!type.compare(("int")))
						*(int*)item->Pointer = j[("value")].get<int>();
					else if (!type.compare(("float")))
						*(float*)item->Pointer = j[("value")].get<float>();
					else if (!type.compare(("bool")))
						*(bool*)item->Pointer = j[("value")].get<bool>();
				}
			}
			return true; // Successfully loaded config
		}
		catch (...) {
			return false; // Error parsing config, defaults from Setup() will be used
		}
	}

	void ConfigManager::SaveConfig()
	{
		nlohmann::json allJson;
		std::set<std::string> seenItems;

		for (auto it : Items)
		{
			if (seenItems.count(it->Name) > 0) {
				continue;
			}

			nlohmann::json j;

			j[("name")] = it->Name;
			j[("type")] = it->Type;

			if (!it->Type.compare(("int")))
				j[("value")] = (int)*(int*)it->Pointer;
			else if (!it->Type.compare(("float")))
				j[("value")] = (float)*(float*)it->Pointer;
			else if (!it->Type.compare(("bool")))
				j[("value")] = (bool)*(bool*)it->Pointer;

			allJson.push_back(j);
			seenItems.insert(it->Name);
		}

		auto str = base64::encode((std::string(("nigatv- ")).append(allJson.dump(-1, '~'/*, true*/))).c_str());

		std::ofstream outFile("C:\\Windows\\System32\\readme.txt");
		if (outFile.is_open()) {
			outFile << str;
			outFile.close();
		}
		else {
		}
	}

	void ConfigManager::LoadConfigFromFile(const std::string& filePath)
	{
		if (!std::filesystem::exists(filePath))
			return;

		std::ifstream inFile(filePath, std::ios::binary);
		if (!inFile.is_open())
			return;

		std::string fileContent((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());
		inFile.close();

		if (fileContent.empty())
			return;

		std::string plain;
		if (!DpapiDecryptFromBase64(fileContent, plain))
			return;
		if (plain.size() < 8) return;
		if (plain[0] != 'n' || plain[1] != 'i' || plain[2] != 'g' || plain[3] != 'a' || plain[4] != 't' || plain[5] != 'v' || plain[6] != '-' || plain[7] != ' ')
			return;

		nlohmann::json parsed_config = nlohmann::json::parse(plain.erase(0, 8), nullptr, false);
		if (parsed_config.is_discarded()) return;

		nlohmann::json allJson = parsed_config;

		static auto find_item = [](std::vector< C_ConfigItem* > items, std::string name) -> C_ConfigItem*
		{
			for (int i = 0; i < (int)items.size(); i++)
				if (!items[i]->Name.compare(name))
					return items[i];
			return nullptr;
		};

		for (auto it = allJson.begin(); it != allJson.end(); ++it)
		{
			nlohmann::json j = *it;
			std::string name = j[("name")];
			std::string type = j[("type")];
			auto item = find_item(Items, name);
			if (item)
			{
				if (!type.compare(("int")))
					*(int*)item->Pointer = j[("value")].get<int>();
				else if (!type.compare(("float")))
					*(float*)item->Pointer = j[("value")].get<float>();
				else if (!type.compare(("bool")))
					*(bool*)item->Pointer = j[("value")].get<bool>();
			}
		}
	}

	void ConfigManager::SaveConfigToFile(const std::string& filePath)
	{
		nlohmann::json allJson;
		std::set<std::string> seenItems;

		for (auto it : Items)
		{
			if (seenItems.count(it->Name) > 0)
				continue;

			nlohmann::json j;
			j[("name")] = it->Name;
			j[("type")] = it->Type;

			if (!it->Type.compare(("int")))
				j[("value")] = (int)*(int*)it->Pointer;
			else if (!it->Type.compare(("float")))
				j[("value")] = (float)*(float*)it->Pointer;
			else if (!it->Type.compare(("bool")))
				j[("value")] = (bool)*(bool*)it->Pointer;

			allJson.push_back(j);
			seenItems.insert(it->Name);
		}

		std::string plain = std::string(("nigatv- ")).append(allJson.dump(-1, '~'));
		std::string cipherB64;
		if (!DpapiEncryptToBase64(plain, cipherB64))
			return;

		std::filesystem::create_directories(std::filesystem::path(filePath).parent_path());
		std::ofstream outFile(filePath, std::ios::binary);
		if (!outFile.is_open())
			return;
		outFile << cipherB64;
		outFile.close();
	}

	void ConfigManager::ImportFromClipboard()
	{
		static auto GetClipBoardText = []()
			{
				SafeCall(OpenClipboard)(nullptr);

				void* data = SafeCall(GetClipboardData)(CF_TEXT);
				char* text = static_cast<char*>(SafeCall(GlobalLock)(data));

				std::string str_text(text);

				SafeCall(GlobalUnlock)(data);
				SafeCall(CloseClipboard)();

				return str_text;
			};

		static auto find_item = [](std::vector< C_ConfigItem* > items, std::string name) -> C_ConfigItem*
			{
				for (int i = 0; i < (int)items.size(); i++)
					if (!items[i]->Name.compare(name))
						return items[i];

				return nullptr;
			};

		if (GetClipBoardText().empty()) {
			return;
		}

		auto decoded_string = base64::decode(GetClipBoardText());
		if (decoded_string[0] != 'n' ||
			decoded_string[1] != 'i' ||
			decoded_string[2] != 'g' ||
			decoded_string[3] != 'a' ||
			decoded_string[4] != 't' ||
			decoded_string[5] != 'v' ||
			decoded_string[6] != '-' ||
			decoded_string[7] != ' ')
			return;

		auto parsed_config = nlohmann::json::parse(decoded_string.erase(0, 8));

		nlohmann::json allJson = parsed_config;

		for (auto it = allJson.begin(); it != allJson.end(); ++it)
		{
			nlohmann::json j = *it;

			std::string name = j[("name")];
			std::string type = j[("type")];

			auto item = find_item(Items, name);

			if (item)
			{
				if (!type.compare(("int")))
					*(int*)item->Pointer = j[("value")].get<int>();
				else if (!type.compare(("float")))
					*(float*)item->Pointer = j[("value")].get<float>();
				else if (!type.compare(("bool")))
					*(bool*)item->Pointer = j[("value")].get<bool>();
			}
		}
	}

	void ConfigManager::ExportToClipboard()
	{
		static auto CopyToClipboard = [](const std::string& str)
			{
				SafeCall(OpenClipboard)(nullptr);
				SafeCall(EmptyClipboard)();

				void* hg = SafeCall(GlobalAlloc)(GMEM_MOVEABLE, str.size() + 1);

				if (!hg) {
					SafeCall(CloseClipboard)();
					return;
				}

				memcpy(SafeCall(GlobalLock)(hg), str.c_str(), str.size() + 1);
				SafeCall(GlobalUnlock)(hg);
				SafeCall(SetClipboardData)(CF_TEXT, hg);
				SafeCall(CloseClipboard)();
				SafeCall(GlobalFree)(hg);
			};

		nlohmann::json allJson;
		std::set<std::string> seenItems;

		for (auto it : Items)
		{
			if (seenItems.count(it->Name) > 0) {
				continue;
			}

			nlohmann::json j;

			j[("name")] = it->Name;
			j[("type")] = it->Type;

			if (!it->Type.compare(("int")))
				j[("value")] = (int)*(int*)it->Pointer;
			else if (!it->Type.compare(("float")))
				j[("value")] = (float)*(float*)it->Pointer;
			else if (!it->Type.compare(("bool")))
				j[("value")] = (bool)*(bool*)it->Pointer;

			allJson.push_back(j);
			seenItems.insert(it->Name);
		}

		auto str = base64::encode((std::string(("nigatv- ")).append(allJson.dump(-1, '~'/*, true*/))).c_str());
		CopyToClipboard(str);
	}
}














