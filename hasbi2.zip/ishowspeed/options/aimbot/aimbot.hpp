#pragma once

#include "../../options.hpp"

namespace Cheat {
	struct AimBot {
		static void RunThread();
	};
}