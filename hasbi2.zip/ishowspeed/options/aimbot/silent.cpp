#include "silent.hpp"

#include "../../options.hpp"
#include "../../sdk/fivem.hpp"

#include <Windows.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <random>
#include <thread>
#include <vector>

namespace Cheat {
namespace {
    constexpr int kHeadIndex = 0;
    constexpr int kNeckIndex = 1;
    constexpr int kChestIndex = 2;

    const std::vector<int> kAvailableBones = {
        SKEL_Head,
        SKEL_Neck_1,
        SKEL_Spine3,
        SKEL_Pelvis,
        SKEL_L_UpperArm,
        SKEL_R_UpperArm,
        SKEL_L_Thigh,
        SKEL_R_Thigh
    };

    int GetRandomBone() {
        if (kAvailableBones.empty()) {
            return SKEL_Head;
        }
        int random_index = rand() % static_cast<int>(kAvailableBones.size());
        return kAvailableBones[static_cast<size_t>(random_index)];
    }

    bool IsPedInVehicle(const CPed* ped) {
        return ped && ped->HasConfigFlag(CPED_CONFIG_FLAG_InVehicle);
    }

    bool IsEntityDriver(const Entity& entity) {
        if (!entity.StaticInfo.Ped) {
            return false;
        }
        if (!IsPedInVehicle(entity.StaticInfo.Ped)) {
            return false;
        }
        CVehicle* vehicle = entity.StaticInfo.Ped->GetLastVehicle();
        if (!vehicle) {
            return false;
        }
        uint64_t driver = vehicle->GetDriver();
        return driver == reinterpret_cast<uint64_t>(entity.StaticInfo.Ped);
    }

    float GetScreenDistance(const ImVec2& point, const ImVec2& center) {
        float dx = point.x - center.x;
        float dy = point.y - center.y;
        return std::sqrt(dx * dx + dy * dy);
    }

    bool IsEntitySelectable(const Entity& entity, const LocalPlayerInfo& local_player) {
        if (!entity.StaticInfo.Ped) {
            return false;
        }
        if (entity.StaticInfo.bIsLocalPlayer) {
            return false;
        }
        if (entity.StaticInfo.IsFriend) {
            return false;
        }
        if (entity.StaticInfo.Ped->GetHealth() <= 0.1f && !g_Options.LegitBot.SilentAim.ShotDead) {
            return false;
        }
        if (entity.StaticInfo.bIsNPC && !g_Options.LegitBot.SilentAim.ShotNPC) {
            return false;
        }
        float world_distance = entity.Cordinates.DistTo(local_player.WorldPos);
        if (world_distance > g_Options.LegitBot.SilentAim.MaxDistance) {
            return false;
        }
        if (g_Options.LegitBot.SilentAim.VisibleCheck && !entity.Visible) {
            return false;
        }
        return true;
    }

    int GetDesiredBone() {
        switch (g_Options.LegitBot.SilentAim.HitBox) {
        case kHeadIndex:
            return SKEL_Head;
        case kNeckIndex:
            return SKEL_Neck_1;
        case kChestIndex:
            return SKEL_Spine3;
        default:
            return SKEL_Head;
        }
    }
} // namespace

void SilentAim::RunThread() {
    std::mt19937 rng(std::random_device{}());
    std::uniform_real_distribution<float> offset_distribution(-0.015f, 0.015f);

    while (!g_Options.General.ShutDown) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1 + g_Options.General.ThreadDelay));

        if (!g_Options.LegitBot.SilentAim.Enabled) {
            continue;
        }

        if (g_Options.LegitBot.SilentAim.KeyBind != 0 &&
            !(GetAsyncKeyState(g_Options.LegitBot.SilentAim.KeyBind) & 0x8000)) {
            continue;
        }

        LocalPlayerInfo local_player = g_Fivem.GetLocalPlayerInfo();
        if (!local_player.Ped) {
            continue;
        }

        ImVec2 screen_center = ImVec2(
            ImGui::GetIO().DisplaySize.x * 0.5f,
            ImGui::GetIO().DisplaySize.y * 0.5f);

        float fov = static_cast<float>(g_Options.LegitBot.SilentAim.Fov);
        if (fov <= 0.f) {
            fov = 50.f;
        }

        std::vector<std::pair<float, const Entity*>> targets;
        for (const auto& entity : g_Fivem.GetEntitiyListSafe()) {
            if (!IsEntitySelectable(entity, local_player)) {
                continue;
            }

            int target_bone = GetDesiredBone();
            if (g_Options.LegitBot.SilentAim.RandomBone && !g_Options.LegitBot.SilentAim.ClosestBone) {
                target_bone = GetRandomBone();
            }

            Vector3D bone_pos = g_Fivem.GetBonePosVec3(entity, target_bone);
            if (bone_pos.x == 0.f && bone_pos.y == 0.f && bone_pos.z == 0.f) {
                continue;
            }

            ImVec2 screen_pos = g_Fivem.WorldToScreen(bone_pos);
            if (!g_Fivem.IsOnScreen(screen_pos)) {
                continue;
            }

            float screen_distance = GetScreenDistance(screen_pos, screen_center);
            if (screen_distance > fov) {
                continue;
            }

            targets.emplace_back(screen_distance, &entity);
        }

        if (targets.empty()) {
            continue;
        }

        std::sort(targets.begin(), targets.end(), [](const auto& left, const auto& right) {
            return left.first < right.first;
        });

        const Entity* selected_entity = nullptr;
        if (g_Options.LegitBot.SilentAim.ForceDriver) {
            for (const auto& target_pair : targets) {
                const Entity* candidate = target_pair.second;
                if (!IsPedInVehicle(candidate->StaticInfo.Ped) || IsEntityDriver(*candidate)) {
                    selected_entity = candidate;
                    break;
                }
            }
        }

        if (!selected_entity) {
            selected_entity = targets.front().second;
        }

        if (!selected_entity) {
            continue;
        }

        float miss_roll = static_cast<float>(rand() % 10000) / 100.f;
        if (miss_roll < g_Options.LegitBot.SilentAim.MissChance) {
            continue;
        }

        int target_bone = GetDesiredBone();
        if (g_Options.LegitBot.SilentAim.RandomBone && !g_Options.LegitBot.SilentAim.ClosestBone) {
            target_bone = GetRandomBone();
        }

        Vector3D bone_pos = g_Fivem.GetBonePosVec3(*selected_entity, target_bone);
        bone_pos.x += offset_distribution(rng);
        bone_pos.y += offset_distribution(rng);
        bone_pos.z += offset_distribution(rng);

        g_Fivem.ProcessCameraMovement(
            bone_pos,
            g_Options.LegitBot.AimBot.SmoothHorizontal,
            g_Options.LegitBot.AimBot.SmoothVertical);

        if (g_Options.LegitBot.SilentAim.AutoShoot) {
            if (g_Options.LegitBot.SilentAim.AutoShootDelay > 0) {
                std::this_thread::sleep_for(
                    std::chrono::milliseconds(g_Options.LegitBot.SilentAim.AutoShootDelay));
            }

            INPUT input = {};
            input.type = INPUT_MOUSE;
            input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
            SendInput(1, &input, static_cast<int>(sizeof(INPUT)));
            input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
            SendInput(1, &input, static_cast<int>(sizeof(INPUT)));
        }
    }
}
} // namespace Cheat