#include "triggerbocik.hpp"

#include <thread>

#include "../../sdk/fivem.hpp"
#include <structure/includy.hpp>

namespace Cheat
{
    namespace TriggerBot
    {
        void RunThread()
        {
            while (!g_Options.General.ShutDown)
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(1 + g_Options.General.ThreadDelay));

                if (!g_Options.LegitBot.Trigger.Enabled)
                    continue;

                if (!g_Fivem.GetLocalPlayerInfo().Ped)
                    continue;

                static bool Shooting = false;

                bool CanShoot = false;

                CPed* aimingEntity = g_Fivem.GetAimingEntity();
                if (aimingEntity)
                {
                    Entity foundEntity;
                    bool entityFound = false;
                    for (const auto& entity : g_Fivem.GetEntitiyListSafe())
                    {
                        if (entity.StaticInfo.Ped == aimingEntity)
                        {
                            foundEntity = entity;
                            entityFound = true;
                            break;
                        }
                    }

                    if (entityFound)
                    {
                        if (foundEntity.StaticInfo.IsFriend || !foundEntity.Visible)
                        {
                            continue;
                        }

                        if (!g_Options.LegitBot.Trigger.ShotNPC && foundEntity.StaticInfo.bIsNPC)
                        {
                            continue;
                        }

                        Vector3D headPos = g_Fivem.GetBonePosVec3(foundEntity, SKEL_Head);
                        Vector3D localPos = g_Fivem.GetLocalPlayerInfo().WorldPos;
                        float distance = localPos.DistTo(headPos);

                        if (distance < g_Options.LegitBot.Trigger.MaxDistance)
                        {
                            if (g_Options.LegitBot.Trigger.KeyBind == 0 || GetAsyncKeyState(g_Options.LegitBot.Trigger.KeyBind))
                            {
                                CanShoot = true;
                            }
                        }
                    }
                }

                if (CanShoot && !Shooting)
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(g_Options.LegitBot.Trigger.ReactionTime));

                    INPUT input = {0};
                    input.type = INPUT_MOUSE;
                    input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
                    SafeCall(SendInput)(1, &input, static_cast<int>(sizeof(INPUT)));

                    Shooting = true;
                }
                else if (Shooting && !CanShoot)
                {
                    INPUT input = {0};
                    input.type = INPUT_MOUSE;
                    input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
                    SafeCall(SendInput)(1, &input, static_cast<int>(sizeof(INPUT)));

                    Shooting = false;
                }
            }
        }
    }
}