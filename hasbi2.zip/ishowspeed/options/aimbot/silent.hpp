#pragma once

namespace Cheat {
    struct SilentAim {
        static void RunThread();
    };
}