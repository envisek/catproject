#pragma once

#include "../../options.hpp"

namespace Cheat {
namespace TriggerBot {
    void RunThread();
}
}