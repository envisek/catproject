#include "VehicleESP.hpp"
#include "../../cheat.hpp"
#include "../../sdk/fivem.hpp"

#include "../../../structure/ui/ImGui/imgui.h"

bool WorldToScreen(const Vector3& position, ImVec2& screen)
{
    screen.x = position.x * 10;
    screen.y = position.z * 10;
    return true;
}

void VehicleESP()
{
    if (!g_Options.Visuals.ESP.Vehicles.Enabled)
    {
        return;
    }

    if (!FiveM::g_Fivem.IsValid())
    {
        return;
    }

    auto draw_list = ImGui::GetBackgroundDrawList();
    ImColor shadowColor(0, 0, 0, 200);
    ImColor textColor(255, 255, 255, 255);
    ImColor boxColor(255, 0, 0, 200);

    ImVec2 pos_screen;
    if (!WorldToScreen(FiveM::g_Fivem.Position, pos_screen))
    {
        return;
    }

    float box_height = 50.0f;
    float box_width = 80.0f;
    draw_list->AddRect(
        ImVec2(pos_screen.x - box_width / 2, pos_screen.y - box_height),
        ImVec2(pos_screen.x + box_width / 2, pos_screen.y),
        boxColor, 2.0f);

    char health_buf[64];
    sprintf_s(health_buf, "Vehicle HP: %d", FiveM::g_Fivem.GetHealth());

    ImVec2 text_size = ImGui::CalcTextSize(health_buf);

    draw_list->AddRectFilled(
        ImVec2(pos_screen.x - text_size.x / 2 - 2, pos_screen.y + 5 - 2),
        ImVec2(pos_screen.x + text_size.x / 2 + 2, pos_screen.y + 5 + text_size.y + 2),
        shadowColor);

    draw_list->AddText(
        ImVec2(pos_screen.x - text_size.x / 2, pos_screen.y + 5),
        textColor,
        health_buf);
}