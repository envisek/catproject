#define IMGUI_DEFINE_MATH_OPERATORS
#include "espy.hpp"

#include <cmath>

#include "../../sdk/fivem.hpp"
#include "../../options.hpp"
#include <optional>
#include <utility>
#include <vector>
#include "ImGui/imgui.h"
#include <structure/includy.hpp>

struct Position
{
	ImVec2 Pos;
};

namespace Cheat
{
	namespace ESP
	{
		void Players()
		{
			if (!g_Fivem.GetLocalPlayerInfo().Ped)
				return;

			for (Entity Current : g_Fivem.GetEntitiyList())
			{
				if (Current.StaticInfo.bIsLocalPlayer && !g_Options.Visuals.ESP.Players.ShowLocalPlayer)
					continue;

				if (Current.StaticInfo.bIsNPC && !g_Options.Visuals.ESP.Players.ShowNPCs)
					continue;

				if (g_Options.Visuals.ESP.Players.VisibleOnly && !Current.Visible)
					continue;

				Vector3D PedCoordinates = Current.Cordinates;

				float Distance = PedCoordinates.DistTo(g_Fivem.GetLocalPlayerInfo().WorldPos);

				if (Distance > g_Options.Visuals.ESP.Players.RenderDistance)
					continue;

				ImVec2 PedLocation = g_Fivem.WorldToScreen(PedCoordinates);

				ImVec2 Head = g_Fivem.WorldToScreen(g_Fivem.GetBonePosVec3(Current, SKEL_Head));
				if (!g_Fivem.IsOnScreen(Head))
					continue;

				ImVec2 LeftFoot = g_Fivem.WorldToScreen(g_Fivem.GetBonePosVec3(Current, SKEL_L_Foot));
				if (!g_Fivem.IsOnScreen(LeftFoot))
					continue;

				ImVec2 RightFoot = g_Fivem.WorldToScreen(g_Fivem.GetBonePosVec3(Current, SKEL_R_Foot));
				if (!g_Fivem.IsOnScreen(RightFoot))
					continue;

				float Height = -Head.y;

				if (LeftFoot.y > RightFoot.y)
					Height += LeftFoot.y;
				else
					Height += RightFoot.y;

				float Width = Height / 1.8f;
				float PedCenterY = Head.y + Height / 2.f;
				Height *= 1.2f;

				ImVec2 Padding[4] = {ImVec2(0, 0), ImVec2(0, 0), ImVec2(0, 0), ImVec2(0, 0)};

				ImDrawList* drawList = ImGui::GetBackgroundDrawList();
				if (!drawList) continue;

				ImColor BoxColor = (Current.StaticInfo.IsFriend)
					? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
					: ImColor(g_Options.Visuals.ESP.Players.BoxColor[0], g_Options.Visuals.ESP.Players.BoxColor[1], g_Options.Visuals.ESP.Players.BoxColor[2], g_Options.Visuals.ESP.Players.BoxColor[3]);

				ImColor CornerBoxColor = (Current.StaticInfo.IsFriend)
					? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
					: ImColor(g_Options.Visuals.ESP.Players.CornerBoxColor[0], g_Options.Visuals.ESP.Players.CornerBoxColor[1], g_Options.Visuals.ESP.Players.CornerBoxColor[2], g_Options.Visuals.ESP.Players.CornerBoxColor[3]);

				ImColor FilledBoxColor = (Current.StaticInfo.IsFriend)
					? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], 0.15f)
					: ImColor(g_Options.Visuals.ESP.Players.FilledBoxColor[0], g_Options.Visuals.ESP.Players.FilledBoxColor[1], g_Options.Visuals.ESP.Players.FilledBoxColor[2], 0.15f);

				ImColor NameColor = (Current.StaticInfo.IsFriend)
					? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
					: ImColor(g_Options.Visuals.ESP.Players.NameColor[0], g_Options.Visuals.ESP.Players.NameColor[1], g_Options.Visuals.ESP.Players.NameColor[2], g_Options.Visuals.ESP.Players.NameColor[3]);

				ImColor SkeletonColor = (Current.StaticInfo.IsFriend)
					? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
					: ImColor(g_Options.Visuals.ESP.Players.SkeletonColor[0], g_Options.Visuals.ESP.Players.SkeletonColor[1], g_Options.Visuals.ESP.Players.SkeletonColor[2], g_Options.Visuals.ESP.Players.SkeletonColor[3]);

				ImVec2 rectMin = ImVec2(PedLocation.x - Width / 2, PedCenterY - Height / 2.f);
				ImVec2 rectMax = ImVec2(PedLocation.x + Width / 2, PedCenterY + Height / 2.f);

				if (g_Options.Visuals.ESP.Players.Box)
				{
					float rounding = 0.0f;
					if (g_Options.Visuals.ESP.Players.FilledBox)
					{
						drawList->AddRectFilled(rectMin, rectMax, FilledBoxColor, rounding);
					}
					drawList->AddRect(rectMin, rectMax, BoxColor, rounding, ImDrawFlags_None, 1.5f);
				}

				if (g_Options.Visuals.ESP.Players.CornerBox)
				{
					float cornerSize = 15.0f;
					float thickness = 2.0f;

					drawList->AddLine(
						ImVec2(rectMin.x, rectMin.y + cornerSize),
						ImVec2(rectMin.x, rectMin.y),
						CornerBoxColor, thickness);
					drawList->AddLine(
						ImVec2(rectMin.x, rectMin.y),
						ImVec2(rectMin.x + cornerSize, rectMin.y),
						CornerBoxColor, thickness);

					drawList->AddLine(
						ImVec2(rectMax.x - cornerSize, rectMin.y),
						ImVec2(rectMax.x, rectMin.y),
						CornerBoxColor, thickness);
					drawList->AddLine(
						ImVec2(rectMax.x, rectMin.y),
						ImVec2(rectMax.x, rectMin.y + cornerSize),
						CornerBoxColor, thickness);

					drawList->AddLine(
						ImVec2(rectMin.x, rectMax.y - cornerSize),
						ImVec2(rectMin.x, rectMax.y),
						CornerBoxColor, thickness);
					drawList->AddLine(
						ImVec2(rectMin.x, rectMax.y),
						ImVec2(rectMin.x + cornerSize, rectMax.y),
						CornerBoxColor, thickness);

					drawList->AddLine(
						ImVec2(rectMax.x - cornerSize, rectMax.y),
						ImVec2(rectMax.x, rectMax.y),
						CornerBoxColor, thickness);
					drawList->AddLine(
						ImVec2(rectMax.x, rectMax.y),
						ImVec2(rectMax.x, rectMax.y - cornerSize),
						CornerBoxColor, thickness);
				}

				if (g_Options.Visuals.ESP.Players.Skeleton)
				{
					static const std::pair<int, int> bonePairs[] = {
						{SKEL_Pelvis, SKEL_Neck_1}, {SKEL_Neck_1, SKEL_L_Clavicle},
						{SKEL_Neck_1, SKEL_R_Clavicle}, {SKEL_L_Clavicle, SKEL_L_UpperArm},
						{SKEL_R_Clavicle, SKEL_R_UpperArm}, {SKEL_L_UpperArm, SKEL_L_Forearm},
						{SKEL_R_UpperArm, SKEL_R_Forearm}, {SKEL_L_Forearm, SKEL_L_Hand},
						{SKEL_R_Forearm, SKEL_R_Hand}, {SKEL_Pelvis, SKEL_L_Thigh},
						{SKEL_Pelvis, SKEL_R_Thigh}, {SKEL_L_Thigh, SKEL_L_Calf},
						{SKEL_R_Thigh, SKEL_R_Calf}, {SKEL_L_Calf, SKEL_L_Foot},
						{SKEL_R_Calf, SKEL_R_Foot},
					};

					auto GetBoneScreenPos = [&](int boneId) -> std::optional<ImVec2> {
						ImVec2 pos = g_Fivem.WorldToScreen(g_Fivem.GetBonePosVec3(Current, boneId));
						return g_Fivem.IsOnScreen(pos) ? std::optional<ImVec2>{pos} : std::nullopt;
					};

					for (const auto& [boneA, boneB] : bonePairs) {
						auto boneAPos = GetBoneScreenPos(boneA);
						auto boneBPos = GetBoneScreenPos(boneB);

						if (boneAPos && boneBPos) {
							drawList->AddLine(*boneAPos, *boneBPos, SkeletonColor, 0.8f);
						}
					}
				}

				if (g_Options.Visuals.ESP.Players.Head)
				{
					ImColor HeadColor = (Current.StaticInfo.IsFriend)
						? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
						: ImColor(g_Options.Visuals.ESP.Players.HeadColor[0], g_Options.Visuals.ESP.Players.HeadColor[1], g_Options.Visuals.ESP.Players.HeadColor[2], g_Options.Visuals.ESP.Players.HeadColor[3]);

					auto GetBoneScreenPos = [&](int boneId) -> std::optional<ImVec2> {
						ImVec2 pos = g_Fivem.WorldToScreen(g_Fivem.GetBonePosVec3(Current, boneId));
						return g_Fivem.IsOnScreen(pos) ? std::optional<ImVec2>{pos} : std::nullopt;
					};

					auto headPos = GetBoneScreenPos(SKEL_Head);
					if (headPos) {
						drawList->AddCircle(*headPos, g_Options.Visuals.ESP.Players.HeadSize, HeadColor, 12, 1.0f);
					}
				}

				if (g_Options.Visuals.ESP.Players.HealthBar)
				{
					float Health = Current.StaticInfo.Ped->GetHealth();
					float MaxHealth = Current.StaticInfo.Ped->GetMaxHealth();

					ImVec2 healthBarStart = ImVec2(rectMin.x - 6.0f, rectMin.y);
					ImVec2 healthBarEnd = ImVec2(rectMin.x - 3.0f, rectMax.y);

					drawList->AddRectFilled(
						healthBarStart,
						healthBarEnd,
						ImColor(0, 0, 0, 150),
						2.0f);

					float healthPercentage = Health / MaxHealth;
					ImColor healthColor;

					if (healthPercentage > 0.7f) {
						healthColor = ImColor(0, 255, 0);
					}
					else if (healthPercentage > 0.3f) {
						healthColor = ImColor(255, 255, 0);
					}
					else {
						healthColor = ImColor(255, 0, 0);
					}

					float healthHeight = (healthBarEnd.y - healthBarStart.y) * healthPercentage;
					drawList->AddRectFilled(
						ImVec2(healthBarStart.x, healthBarEnd.y - healthHeight),
						healthBarEnd,
						healthColor,
						2.0f);
				}

				if (g_Options.Visuals.ESP.Players.ArmorBar)
				{
					float Armor = Current.StaticInfo.Ped->GetArmor();
					const float MaxArmor = 100.0f;

					if (Armor > 0) {
						ImVec2 armorBarStart = ImVec2(rectMax.x + 3.0f, rectMin.y);
						ImVec2 armorBarEnd = ImVec2(rectMax.x + 6.0f, rectMax.y);

						drawList->AddRectFilled(
							armorBarStart,
							armorBarEnd,
							ImColor(0, 0, 0, 150),
							2.0f);

						float armorHeight = (armorBarEnd.y - armorBarStart.y) * (Armor / MaxArmor);
						drawList->AddRectFilled(
							ImVec2(armorBarStart.x, armorBarEnd.y - armorHeight),
							armorBarEnd,
							ImColor(0, 150, 255),
							2.0f);
					}
				}

				if (g_Options.Visuals.ESP.Players.Name)
				{
					std::string playerName;
					if (!Current.StaticInfo.bIsNPC)
					{
						playerName = g_Fivem.GetPlayerNameByNetId(Current.StaticInfo.NetId);
					}

					if (playerName.empty())
					{
						if (!Current.StaticInfo.Name.empty())
							playerName = Current.StaticInfo.Name;
						else if (Current.StaticInfo.NetId != -1)
							playerName = std::to_string(Current.StaticInfo.NetId);
						else
							playerName = "Unknown";
					}

					if (Current.StaticInfo.IsFriend) {
						playerName += " (FRIEND)";
					}
					ImVec2 TextSize = ImGui::CalcTextSize(playerName.c_str());
					ImVec2 DrawPos = ImVec2(PedLocation.x - TextSize.x / 2, rectMin.y - TextSize.y - 2);
					drawList->AddText(DrawPos + ImVec2(1, 1), ImColor(0.0f, 0.0f, 0.0f, NameColor.Value.w), playerName.c_str());
					drawList->AddText(DrawPos, NameColor, playerName.c_str());
				}

				if (g_Options.Visuals.ESP.Players.WeaponName)
				{
					if (CWeaponManager* WeaponManager = Current.StaticInfo.Ped->GetWeaponManager()) {
						if (CWeaponInfo* WeaponInfo = WeaponManager->GetWeaponInfo()) {
							const std::string& WeaponName = WeaponInfo->GetWeaponName();

							if (!WeaponName.empty()) {
								ImVec2 TextSize = ImGui::CalcTextSize(WeaponName.c_str());
								ImVec2 DrawPos = ImVec2(PedLocation.x - TextSize.x / 2, rectMax.y + 2);

								ImColor WeaponColor(
									g_Options.Visuals.ESP.Players.WeaponNameColor[0],
									g_Options.Visuals.ESP.Players.WeaponNameColor[1],
									g_Options.Visuals.ESP.Players.WeaponNameColor[2],
									g_Options.Visuals.ESP.Players.WeaponNameColor[3]);

								drawList->AddText(DrawPos + ImVec2(1, 1), ImColor(0.0f, 0.0f, 0.0f, WeaponColor.Value.w), WeaponName.c_str());
								drawList->AddText(DrawPos, WeaponColor, WeaponName.c_str());
						}
					}
				}
				}

				if (g_Options.Visuals.ESP.Players.Distance)
				{
					if (!Current.StaticInfo.bIsLocalPlayer)
					{
						std::string PlayerDistance = std::to_string(static_cast<int>(Distance)) + "m";

						ImVec2 TextSize = ImGui::CalcTextSize(PlayerDistance.c_str());

						float yOffset = 2.0f;
						if (g_Options.Visuals.ESP.Players.WeaponName) {
							yOffset += ImGui::CalcTextSize("W").y;
						}

						ImVec2 DrawPos = ImVec2(PedLocation.x - TextSize.x / 2, rectMax.y + yOffset);

						ImColor DistColor(
							g_Options.Visuals.ESP.Players.DistanceColor[0],
							g_Options.Visuals.ESP.Players.DistanceColor[1],
							g_Options.Visuals.ESP.Players.DistanceColor[2],
							g_Options.Visuals.ESP.Players.DistanceColor[3]);

						drawList->AddText(DrawPos + ImVec2(1, 1), ImColor(0.0f, 0.0f, 0.0f, DistColor.Value.w), PlayerDistance.c_str());
						drawList->AddText(DrawPos, DistColor, PlayerDistance.c_str());
					}
				}

				if (g_Options.Visuals.ESP.Players.SnapLines)
				{
					if (!Current.StaticInfo.bIsLocalPlayer) {
						ImColor LineColor = Current.StaticInfo.IsFriend
							? ImColor(g_Options.Misc.FriendColor[0], g_Options.Misc.FriendColor[1], g_Options.Misc.FriendColor[2], g_Options.Misc.FriendColor[3])
							: ImColor(g_Options.Visuals.ESP.Players.SnaplinesColor[0], g_Options.Visuals.ESP.Players.SnaplinesColor[1], g_Options.Visuals.ESP.Players.SnaplinesColor[2], g_Options.Visuals.ESP.Players.SnaplinesColor[3]);

						ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y);
						drawList->AddLine(screenCenter, ImVec2(PedLocation.x, rectMax.y), LineColor, 1.0f);
					}
				}

				if (g_Options.Visuals.ESP.Players.Weapon_Misc)
				{
					CWeaponManager* WeaponManager = Current.StaticInfo.Ped->GetWeaponManager();
					if (WeaponManager)
					{
						CWeaponInfo* WeaponInfo = WeaponManager->GetWeaponInfo();
						if (WeaponInfo)
						{
							if (g_Options.Misc.Exploits.LocalPlayer.norecoil)
							{
								if (WeaponManager)
								{
									auto weaponinfo = WeaponManager->GetWeaponInfo();

									FrameWork::Memory::WriteMemory<float>((uintptr_t)weaponinfo + 0x2F4, 0.f);
								}
							}
							if (g_Options.Misc.Exploits.LocalPlayer.noreload)
							{
								if (WeaponManager)
								{
									auto weaponinfo = WeaponManager->GetWeaponInfo();

									FrameWork::Memory::WriteMemory<float>((uintptr_t)weaponinfo + 0x134, 1000);
								}
							}
							if (g_Options.Misc.Exploits.LocalPlayer.nospread)
							{
								if (WeaponManager)
								{
									auto weaponinfo = WeaponManager->GetWeaponInfo();

									FrameWork::Memory::WriteMemory<float>((uintptr_t)weaponinfo + 0x84, 0.f);
								}
							}
						}
					}
				}
			}
		}
	}
}