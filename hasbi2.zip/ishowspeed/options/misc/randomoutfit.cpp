#include "randomoutfit.h"

#include "../../cheat.hpp"
#include "../../options.hpp"
#include "../../sdk/fivem.hpp"

#include <map>
#include <random>
#include <string>

void RandomOutfitTick()
{
    static std::map<std::string, BYTE> previousOutfit;

    if (!g_Options.Misc.Exploits.LocalPlayer.RandomOutfit)
    {
        return;
    }

    static std::mt19937 rng(std::random_device{}());
    auto Rand = [&](int min, int max) -> BYTE {
        std::uniform_int_distribution<int> dist(min, max);
        return static_cast<BYTE>(dist(rng));
    };

    auto pLocalPlayer = g_Fivem.GetLocalPlayerInfo().Ped;
    if (!pLocalPlayer)
    {
        return;
    }

    uintptr_t drawHandler = FrameWork::Memory::ReadMemory<uintptr_t>((uintptr_t)pLocalPlayer + 0x48);
    if (!drawHandler)
    {
        return;
    }

    struct OutfitPart
    {
        const char* name;
        uintptr_t offset;
        BYTE min;
        BYTE max;
        bool essential;
    };

    OutfitPart parts[] = {
        { "Shoes", 0x100, 1, 15, true },
        { "Legs", 0xF8, 1, 20, true },
        { "Body", 0x114, 1, 25, true },
        { "T-Shirt", 0x108, 0, 20, false },
        { "Mask", 0xEC, 0, 10, false },
        { "Hands", 0xF4, 0, 10, false },
        { "Bag", 0xFC, 0, 6, false },
        { "Armor", 0x10C, 0, 6, false },
        { "Decals", 0x110, 0, 6, false },
        { "Accessory1", 0x118, 0, 3, false },
        { "Accessory2", 0x11C, 0, 3, false },
        { "Hat", 0x120, 0, 10, false },
        { "Glasses", 0x124, 0, 6, false },
        { "Earpiece", 0x126, 0, 3, false }
    };

    for (const auto& part : parts)
    {
        BYTE oldVal = FrameWork::Memory::ReadMemory<BYTE>(drawHandler + part.offset);
        previousOutfit[part.name] = oldVal;
    }

    for (const auto& part : parts)
    {
        BYTE newVal = 0;
        if (!part.essential && Rand(0, 99) < 35)
        {
            newVal = 0;
        }
        else
        {
            newVal = Rand(part.min, part.max);
        }

        if (newVal < part.min && part.essential)
        {
            newVal = part.min;
        }
        if (newVal > part.max)
        {
            newVal = part.max;
        }

        FrameWork::Memory::WriteMemory<BYTE>(drawHandler + part.offset, newVal);
    }

    FrameWork::Memory::WriteMemory<float>(drawHandler + 0xAC, 0.0f);

    uintptr_t ped = (uintptr_t)pLocalPlayer;
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x2E, 1);
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x30C, 1);
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x2B, 1);
    FrameWork::Memory::WriteMemory<uint32_t>(ped + 0x2C, Rand(1, 50));
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0xE2, 1);
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x146, 0);
    FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x148, 0);

    uintptr_t playerInfo = FrameWork::Memory::ReadMemory<uintptr_t>(ped + PlayerInfo);
    if (playerInfo)
    {
        FrameWork::Memory::WriteMemory<uint32_t>(playerInfo + 0x24, 1);
        FrameWork::Memory::WriteMemory<uint8_t>(playerInfo + 0x58C, 1);
        FrameWork::Memory::WriteMemory<uint32_t>(playerInfo + 0x1F4, Rand(1, 200));
        FrameWork::Memory::WriteMemory<uint8_t>(playerInfo + 0x2A, 1);
    }

    uintptr_t skinTimer = FrameWork::Memory::ReadMemory<uintptr_t>(ped + 0x50);
    if (skinTimer)
    {
        FrameWork::Memory::WriteMemory<uint32_t>(skinTimer + 0x10, 0);
    }

    for (int i = 0; i < 10; i++)
    {
        BYTE textureId = Rand(0, 7);
        FrameWork::Memory::WriteMemory<uint8_t>(drawHandler + 0x130 + (i * 4), textureId);
    }

    uintptr_t fx = FrameWork::Memory::ReadMemory<uintptr_t>(ped + 0x78);
    if (fx)
    {
        FrameWork::Memory::WriteMemory<uint8_t>(fx + 0x4C, 1);
    }

    Sleep(50);
    g_Options.Misc.Exploits.LocalPlayer.RandomOutfit = false;
}