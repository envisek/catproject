#pragma once

#include "../../sdk/fivem.hpp"

namespace Cheat
{
	namespace Exploits
	{
		void TeleportToWaypoint();
		void RunThread();
		void SetInvisible(bool enable);
	}
}