#pragma once

#include <cstdint>

void RandomOutfitTick();