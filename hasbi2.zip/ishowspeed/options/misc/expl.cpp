#include "expl.hpp"

#include "randomoutfit.h"
#include "../../cheat.hpp"
#include "../../options.hpp"
#include "../../sdk/fivem.hpp"
#include <structure/includy.hpp>

#include <Windows.h>
#include <chrono>
#include <cfloat>
#include <cmath>
#include <cstdlib>
#include <map>
#include <optional>
#include <random>
#include <utility>
#include <vector>

bool TPVehicle = false;
uint64_t TPModelInfo = NULL;
uint64_t TPObject = NULL;
uint64_t TPNavigation = NULL;
Vector3D TPPosition = Vector3D(0, 0, 0);
constexpr uintptr_t WeaponManager = 0;
constexpr uintptr_t PlayerInfo = 0;

namespace Cheat
{
	void Noclip(Vector3D CameraPos)
	{
		if (!TPObject || !TPModelInfo)
		{
			return;
		}

		static float MagicValue = 0.0f;
		static bool Restoring = false;
		static std::chrono::steady_clock::time_point lastUpdate = std::chrono::steady_clock::now();

		if (!g_Options.Misc.Exploits.LocalPlayer.Noclip || !GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.NoclipBind))
		{
			if (Restoring)
			{
				FrameWork::Memory::WriteMemory<float>(TPModelInfo + 0x2C, MagicValue);
			}
			Restoring = false;
			return;
		}

		if (!Restoring)
		{
			MagicValue = FrameWork::Memory::ReadMemory<float>(TPModelInfo + 0x2C);
			FrameWork::Memory::WriteMemory<float>(TPModelInfo + 0x2C, 0.f);
			Restoring = true;
		}

		auto now = std::chrono::steady_clock::now();
		if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastUpdate).count() < 10)
		{
			return;
		}
		lastUpdate = now;

		auto Speed = static_cast<float>(g_Options.Misc.Exploits.LocalPlayer.NoclipSpeed) / 100.f;
		if (GetAsyncKeyState(VK_SHIFT))
		{
			Speed *= 5.f;
		}

		Vector3D forward = CameraPos;
		if (forward.LengthSqr() < 1e-4f)
		{
			forward = Vector3D(0.f, 1.f, 0.f);
		}
		else
		{
			forward.NormalizeInPlace();
		}

		Vector3D worldUp(0.f, 0.f, 1.f);
		if (fabsf(forward.Dot(worldUp)) > 0.98f)
		{
			worldUp = Vector3D(0.f, 1.f, 0.f);
		}

		Vector3D right = worldUp.Cross(forward);
		if (right.LengthSqr() < 1e-4f)
		{
			right = Vector3D(1.f, 0.f, 0.f);
		}
		else
		{
			right.NormalizeInPlace();
		}

		Vector3D cameraUp = forward.Cross(right);
		if (cameraUp.LengthSqr() < 1e-4f)
		{
			cameraUp = Vector3D(0.f, 0.f, 1.f);
		}
		else
		{
			cameraUp.NormalizeInPlace();
		}

		Vector3D NewPosition = TPPosition;

		if (GetAsyncKeyState('W'))
		{
			NewPosition += forward * Speed;
		}

		if (GetAsyncKeyState('S'))
		{
			NewPosition -= forward * Speed;
		}

		if (GetAsyncKeyState('A'))
		{
			NewPosition -= right * Speed;
		}

		if (GetAsyncKeyState('D'))
		{
			NewPosition += right * Speed;
		}

		if (GetAsyncKeyState(VK_SPACE))
		{
			NewPosition += cameraUp * Speed;
		}

		if (GetAsyncKeyState(VK_LCONTROL))
		{
			NewPosition -= cameraUp * Speed;
		}

		TPPosition = NewPosition;
		g_Fivem.TeleportObject(TPObject, TPNavigation, TPModelInfo, NewPosition, NewPosition, false);
	}

	namespace Exploits
	{
		void TeleportToWaypoint()
		{
			for (int i = 0; i < 2000; i++)
			{
				uint64_t Blip = FrameWork::Memory::ReadMemory<uint64_t>(g_Fivem.GetBlipListAddress() + (i * 8));
				if (!Blip)
				{
					continue;
				}

				int BlipIcon = FrameWork::Memory::ReadMemory<int>(Blip + 0x40);
				int BlipColor = FrameWork::Memory::ReadMemory<int>(Blip + 0x48);

				if ((BlipColor != BlipColor::ColorWaypoint) || (BlipIcon != BlipSprite::SpriteWaypoint))
				{
					continue;
				}

				Vector2D WaypointPos = FrameWork::Memory::ReadMemory<Vector2D>(Blip + 0x10);

				if (WaypointPos.x != 0 && WaypointPos.y != 0)
				{
					uint64_t Object = NULL;
					uint64_t Navigation = NULL;
					uint64_t ModelInfo = NULL;

					if (g_Fivem.GetLocalPlayerInfo().Ped && g_Fivem.GetLocalPlayerInfo().Ped->HasConfigFlag(CPED_CONFIG_FLAG_InVehicle))
					{
						CVehicle* Vehicle = g_Fivem.GetLocalPlayerInfo().Ped->GetLastVehicle();
						if (Vehicle)
						{
							Object = (uint64_t)Vehicle;
							Navigation = (uint64_t)Vehicle->GetNavigation();
							ModelInfo = Vehicle->GetModelInfo();
						}
					}

					if (!Object || !Navigation || !ModelInfo)
					{
						Object = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped;
						Navigation = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped->GetNavigation();
						ModelInfo = g_Fivem.GetLocalPlayerInfo().Ped->GetModelInfo();
					}

					Vector3D TeleportPos = Vector3D(WaypointPos.x, WaypointPos.y, -210.f);

					g_Fivem.TeleportObject(Object, Navigation, ModelInfo, TeleportPos, TeleportPos, true);
				}
			}
		}

		void SetInvisible(bool enable)
		{
			if (!g_Fivem.GetLocalPlayerInfo().Ped)
			{
				return;
			}

			if (enable)
			{
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_HideInCutscene, true);
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_DisablePlayerLockon, true);
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_DisableLockonToRandomPeds, true);
			}
			else
			{
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_HideInCutscene, false);
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_DisablePlayerLockon, false);
				g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_DisableLockonToRandomPeds, false);
			}
		}

		void RunThread()
		{
			while (!g_Options.General.ShutDown)
			{
				if (!g_Fivem.GetLocalPlayerInfo().Ped)
				{
					continue;
				}

				uintptr_t weaponinfo = FrameWork::Memory::ReadMemory<uintptr_t>(WeaponManager + 0x20);
				uintptr_t playerInfo = FrameWork::Memory::ReadMemory<uintptr_t>(reinterpret_cast<uintptr_t>(g_Fivem.GetLocalPlayerInfo().Ped) + PlayerInfo);

				(void)weaponinfo;

				if (g_Options.Misc.Exploits.LocalPlayer.Invisible)
				{
					SetInvisible(true);
				}
				else
				{
					SetInvisible(false);
				}

				if (g_Options.Misc.Exploits.LocalPlayer.Start_Health)
				{
					g_Fivem.GetLocalPlayerInfo().Ped->SetHealth(g_Options.Misc.Exploits.LocalPlayer.health_ammount);
					g_Options.Misc.Exploits.LocalPlayer.Start_Health = false;
				}

				if (GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.unlockbind) & 0x8000)
				{
					Cheat::VehicleInfo nearestVehicle;
					float minDistance = FLT_MAX;

					for (Cheat::VehicleInfo Current : Cheat::g_Fivem.GetVehicleList())
					{
						if (Current.Vehicle)
						{
							float distance = Current.Vehicle->GetCoordinate().DistTo(Cheat::g_Fivem.GetLocalPlayerInfo().WorldPos);

							if (distance < minDistance && distance < 600.0f)
							{
								minDistance = distance;
								nearestVehicle = Current;
							}
						}
					}

					if (nearestVehicle.Vehicle)
					{
						nearestVehicle.Vehicle->SetDoorLock(1);
					}
				}

				if (GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.godbind) & 0x8000)
				{
					if (g_Options.Misc.Exploits.LocalPlayer.God)
					{
						g_Fivem.GetLocalPlayerInfo().Ped->godmode_off(false);
					}
					else
					{
						g_Fivem.GetLocalPlayerInfo().Ped->godmode_on(true);
					}
					g_Options.Misc.Exploits.LocalPlayer.God = !g_Options.Misc.Exploits.LocalPlayer.God;
					Sleep(500);
				}

				if (GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.tpbind) & 0x8000 || g_Options.Misc.Exploits.LocalPlayer.TriggerTeleport)
				{
					TeleportToWaypoint();
					g_Options.Misc.Exploits.LocalPlayer.TriggerTeleport = false;
					Sleep(500);
				}

				if (GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.HealBind) & 0x8000 || g_Options.Misc.Exploits.LocalPlayer.TriggerHeal)
				{
					if (g_Fivem.GetLocalPlayerInfo().Ped)
					{
						float maxHealth = g_Fivem.GetLocalPlayerInfo().Ped->GetMaxHealth();
						if (maxHealth > 0)
						{
							g_Fivem.GetLocalPlayerInfo().Ped->SetHealth(maxHealth);
						}
						else
						{
							g_Fivem.GetLocalPlayerInfo().Ped->SetHealth(200.0f);
						}
					}
					g_Options.Misc.Exploits.LocalPlayer.TriggerHeal = false;
					Sleep(500);
				}

				if (GetAsyncKeyState(g_Options.Misc.Exploits.LocalPlayer.ArmorBind) & 0x8000 || g_Options.Misc.Exploits.LocalPlayer.TriggerArmor)
				{
					if (g_Fivem.GetLocalPlayerInfo().Ped)
					{
						g_Fivem.GetLocalPlayerInfo().Ped->SetArmor(100.0f);
					}
					g_Options.Misc.Exploits.LocalPlayer.TriggerArmor = false;
					Sleep(500);
				}

				if (g_Options.Misc.Exploits.LocalPlayer.RepairVehicle)
				{
					auto localPed = g_Fivem.GetLocalPlayerInfo().Ped;
					if (localPed && localPed->HasConfigFlag(CPED_CONFIG_FLAG_InVehicle))
					{
						CVehicle* vehicle = localPed->GetLastVehicle();
						if (vehicle)
						{
							vehicle->RepairVehicleCompletely();
						}
					}
					g_Options.Misc.Exploits.LocalPlayer.RepairVehicle = false;
				}

				if (g_Options.Misc.Exploits.LocalPlayer.TriggerSuicide)
				{
					if (g_Fivem.GetLocalPlayerInfo().Ped)
					{
						g_Fivem.GetLocalPlayerInfo().Ped->SetHealth(0.0f);
					}
					g_Options.Misc.Exploits.LocalPlayer.TriggerSuicide = false;
				}

				if (g_Options.Misc.PlayerList.TriggerAddFriend)
				{
					if (g_Options.Misc.PlayerList.SelectedPlayerNetId != -1)
					{
						if (g_Fivem.IsFriendByNetId(g_Options.Misc.PlayerList.SelectedPlayerNetId))
						{
							g_Fivem.RemoveFriendByNetId(g_Options.Misc.PlayerList.SelectedPlayerNetId);
						}
						else
						{
							g_Fivem.AddFriendByNetId(g_Options.Misc.PlayerList.SelectedPlayerNetId);
						}
					}
					g_Options.Misc.PlayerList.TriggerAddFriend = false;
				}

				if (g_Options.Misc.PlayerList.TriggerCopyOutfit)
				{
					if (g_Options.Misc.PlayerList.SelectedPlayerNetId != -1)
					{
						auto entities = g_Fivem.GetEntitiyListSafe();
						for (const auto& entity : entities)
						{
							if (entity.StaticInfo.NetId == g_Options.Misc.PlayerList.SelectedPlayerNetId && !entity.StaticInfo.bIsNPC)
							{
								auto pLocalPlayer = g_Fivem.GetLocalPlayerInfo().Ped;
								auto pTargetPlayer = entity.StaticInfo.Ped;

								uintptr_t localDrawHandler = FrameWork::Memory::ReadMemory<uintptr_t>((uintptr_t)pLocalPlayer + 0x48);
								uintptr_t targetDrawHandler = FrameWork::Memory::ReadMemory<uintptr_t>((uintptr_t)pTargetPlayer + 0x48);

								if (localDrawHandler && targetDrawHandler)
								{
									struct OutfitPart
									{
										uintptr_t offset;
									};

									OutfitPart parts[] = {
										{0x100},
										{0xF8},
										{0x114},
										{0x108},
										{0xEC},
										{0xF4},
										{0xFC},
										{0x10C},
										{0x110},
										{0x118},
										{0x11C},
										{0x120},
										{0x124},
										{0x126}};

									for (const auto& part : parts)
									{
										BYTE value = FrameWork::Memory::ReadMemory<BYTE>(targetDrawHandler + part.offset);
										FrameWork::Memory::WriteMemory<BYTE>(localDrawHandler + part.offset, value);
									}

									for (int i = 0; i < 10; i++)
									{
										BYTE textureId = FrameWork::Memory::ReadMemory<uint8_t>(targetDrawHandler + 0x130 + (i * 4));
										FrameWork::Memory::WriteMemory<uint8_t>(localDrawHandler + 0x130 + (i * 4), textureId);
									}

									FrameWork::Memory::WriteMemory<float>(localDrawHandler + 0xAC, 0.0f);

									uintptr_t ped = (uintptr_t)pLocalPlayer;
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x2E, 1);
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x30C, 1);
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x2B, 1);
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0xE2, 1);
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x146, 0);
									FrameWork::Memory::WriteMemory<uint8_t>(ped + 0x148, 0);

									uintptr_t playerInfo = FrameWork::Memory::ReadMemory<uintptr_t>(ped + PlayerInfo);
									if (playerInfo)
									{
										FrameWork::Memory::WriteMemory<uint32_t>(playerInfo + 0x24, 1);
										FrameWork::Memory::WriteMemory<uint8_t>(playerInfo + 0x58C, 1);
										FrameWork::Memory::WriteMemory<uint8_t>(playerInfo + 0x2A, 1);
									}

									uintptr_t skinTimer = FrameWork::Memory::ReadMemory<uintptr_t>(ped + 0x50);
									if (skinTimer)
									{
										FrameWork::Memory::WriteMemory<uint32_t>(skinTimer + 0x10, 0);
									}

									uintptr_t fx = FrameWork::Memory::ReadMemory<uintptr_t>(ped + 0x78);
									if (fx)
									{
										FrameWork::Memory::WriteMemory<uint8_t>(fx + 0x4C, 1);
									}

									Sleep(50);
								}
								break;
							}
						}
					}
					g_Options.Misc.PlayerList.TriggerCopyOutfit = false;
				}

				if (g_Options.Misc.PlayerList.TriggerTeleportToPlayer)
				{
					if (g_Options.Misc.PlayerList.SelectedPlayerNetId != -1)
					{
						auto entities = g_Fivem.GetEntitiyListSafe();
						for (const auto& entity : entities)
						{
							if (entity.StaticInfo.NetId == g_Options.Misc.PlayerList.SelectedPlayerNetId && !entity.StaticInfo.bIsNPC)
							{
								uint64_t Object = NULL;
								uint64_t Navigation = NULL;
								uint64_t ModelInfo = NULL;

								if (g_Fivem.GetLocalPlayerInfo().Ped->HasConfigFlag(CPED_CONFIG_FLAG_InVehicle))
								{
									CVehicle* Vehicle = g_Fivem.GetLocalPlayerInfo().Ped->GetLastVehicle();
									if (Vehicle)
									{
										Object = (uint64_t)Vehicle;
										Navigation = (uint64_t)Vehicle->GetNavigation();
										ModelInfo = Vehicle->GetModelInfo();
									}
								}

								if (!Object || !Navigation || !ModelInfo)
								{
									Object = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped;
									Navigation = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped->GetNavigation();
									ModelInfo = g_Fivem.GetLocalPlayerInfo().Ped->GetModelInfo();
								}

								Vector3D targetPos = entity.Cordinates;
								g_Fivem.TeleportObject(Object, Navigation, ModelInfo, targetPos, targetPos, true);
								break;
							}
						}
					}
					g_Options.Misc.PlayerList.TriggerTeleportToPlayer = false;
				}

				if (g_Options.Misc.Exploits.LocalPlayer.shrink)
				{
					g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_UseAmbientModelScaling, true);
				}
				else
				{
					g_Fivem.GetLocalPlayerInfo().Ped->SetConfigFlag(CPED_CONFIG_FLAG_UseAmbientModelScaling, false);
				}

				if (g_Options.Misc.Exploits.LocalPlayer.God)
				{
					g_Fivem.GetLocalPlayerInfo().Ped->godmode_on(g_Options.Misc.Exploits.LocalPlayer.God);
				}
				else
				{
					g_Fivem.GetLocalPlayerInfo().Ped->godmode_off(g_Options.Misc.Exploits.LocalPlayer.God);
				}

				auto Vehicle = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped->GetLastVehicle();
				if (Vehicle)
				{
					auto VehDriver = ((CVehicle*)Vehicle)->GetDriver();
					if (VehDriver == (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped)
					{
						TPVehicle = true;
						TPModelInfo = ((CVehicle*)Vehicle)->GetModelInfo();
						TPObject = Vehicle;
						TPNavigation = (uint64_t)((CVehicle*)Vehicle)->GetNavigation();
						TPPosition = ((CVehicle*)Vehicle)->GetCoordinate();
					}
					else
					{
						TPVehicle = false;
					}
				}

				if (g_Options.Misc.Exploits.LocalPlayer.speed)
				{
					FrameWork::Memory::WriteMemory<float>(playerInfo + 0x0D40, g_Options.Misc.Exploits.LocalPlayer.Player_speed);
				}
				else
				{
					FrameWork::Memory::WriteMemory<float>(playerInfo + 0x0D40, 1.0f);
				}

				if (!TPVehicle)
				{
					TPModelInfo = g_Fivem.GetLocalPlayerInfo().Ped->GetModelInfo();
					TPObject = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped;
					TPNavigation = (uint64_t)g_Fivem.GetLocalPlayerInfo().Ped->GetNavigation();
					TPPosition = g_Fivem.GetLocalPlayerInfo().Ped->GetCoordinate();
				}

				Noclip(g_Fivem.GetCamGameplayDirector()->GetFollowPedCamera()->GetViewAngles());
				RandomOutfitTick();
			}
		}
	}
}