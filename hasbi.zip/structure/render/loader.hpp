#pragma once

#include <Windows.h>
#include "../ui/ImGui/imgui.h"
#include "../ui/ImGui/imgui_impl_win32.h"
#include "../ui/ImGui/imgui_impl_dx11.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace FrameWork {
namespace Loader {

void Render(HWND hwnd);
bool IsOpen();
void Open();
void Close();
bool WasGoClicked();
int ShowLoaderWindow(HINSTANCE hInstance);

class Interface {
private:
    bool bIsLoaderOpen = true;
    HWND hWindow = nullptr;
    ID3D11Device* IDevice = nullptr;
    UINT ResizeWidht = 0;
    UINT ResizeHeight = 0;

public:
    void Initialize(HWND Window, HWND TargetWindow, ID3D11Device* Device);
    void RenderLoader();
    void WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    void ShutDown();
};
}
}











