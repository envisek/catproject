#pragma once

#include <Windows.h>
#include <functional>

#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <tlhelp32.h>
#include <tchar.h>

#include <structure/includy.hpp>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

#ifndef ZBID_UIACCESS
#define ZBID_UIACCESS 2
#endif

namespace FrameWork
{
	class Overlay
	{
	public:
		static void Setup(DWORD TargetPid);
		static void Initialize();
		static void ShutDown();

		static void UpdateWindowPos();
		static void SetupWindowProcHook(std::function<LRESULT(HWND, UINT, WPARAM, LPARAM)> Funtion);

		static bool IsSettuped();
		static bool IsInitialized();
		static HWND GetOverlayWindow();
		static HWND GetTargetWindow();

		// DirectX
		static void dxInitialize();
		static void dxRefresh();
		static void dxShutDown();

		static void dxCreateRenderTarget();
		static void dxCleanupRenderTarget();
		static void dxCleanupDeviceD3D();

		static ID3D11Device* dxGetDevice();
		static ID3D11DeviceContext* dxGetDeviceContext();
		static IDXGISwapChain* dxGetSwapChain();

		static DWORD GetWinLogonToken(DWORD dwSessionId, DWORD dwDesiredAccess, PHANDLE phToken);
		static DWORD CreateUIAccessToken(PHANDLE phToken);
		static BOOL CheckForUIAccess(DWORD* pdwErr, DWORD* pfUIAccess);
		static DWORD PrepareForUIAccess();
	};
}











