#pragma once

#include <d3d11.h>

struct ImFont;

namespace FrameWork
{
	namespace Assets
	{
		extern ImFont* Manrope_Semmi_Font;
		extern ImFont* Benzin_Medium_Font;
		inline ID3D11ShaderResourceView* Logo = nullptr;

		void Initialize(ID3D11Device* Device);
	}
}	














