#include "assets.hpp"
#include "Assets/ImagesBytes.hpp"
#include "../ui/ImGui/imgui.h"
#include <d3d11.h>
#include "../ui/ImGui/d3dx11tex_helper.h"

namespace FrameWork
{
	namespace Assets
	{
		ImFont* Manrope_Semmi_Font = nullptr;
		ImFont* Benzin_Medium_Font = nullptr;
	}

	void Assets::Initialize(ID3D11Device* Device)
	{
		ImGuiIO& io = ImGui::GetIO();
		
		// Load default font with Cyrillic support
		Manrope_Semmi_Font = io.Fonts->AddFontDefault();
		Benzin_Medium_Font = io.Fonts->AddFontDefault();
		
		// Note: Logo loading removed - tc_logo not available
		// If needed, use DirectX11 texture loading functions
	}
}