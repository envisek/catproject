#include "overlay.hpp"
#include <tlhelp32.h>
#include <tchar.h>
#include <sddl.h>

struct WndRECT : public RECT
{
	int Width() { return right - left; }
	int Height() { return bottom - top; }
};

static inline std::function<LRESULT(HWND, UINT, WPARAM, LPARAM)> pWindowProc;

bool bSettuped = false;
bool bInitialized = false;

bool bDeviceInitialized;
bool bRenderTargetInitialized;

HWND hWindow;
WNDCLASSEX WindowClass;
HWND hTargetWindow;
WndRECT wTargetWindowRect;
DWORD sTargetPid;

ID3D11Device* ID3dDevice = nullptr;
ID3D11DeviceContext* ID3dDeviceContext = nullptr;
IDXGISwapChain* ID3dSwapChain = nullptr;
ID3D11RenderTargetView* ID3dRenderTargetView = nullptr;

inline HHOOK hKeyboardHook;

typedef HWND(WINAPI* CreateWindowInBand)(DWORD dwExStyle, ATOM atom, LPCWSTR lpWindowName, DWORD dwStyle, int X, int Y, int nWidth, int nHeight, HWND hWndParent, HMENU hMenu, HINSTANCE hInstance, LPVOID lpParam, DWORD band);

#ifndef ZBID_UIACCESS
#define ZBID_UIACCESS (2)
#endif

inline LRESULT CALLBACK dupcia(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode >= 0)
	{

	}
	return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
}


void CreateDeviceD3D()
{
	DXGI_SWAP_CHAIN_DESC sd = {};
	sd.BufferCount = 2;
	sd.BufferDesc.Width = 0;
	sd.BufferDesc.Height = 0;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;
	sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hWindow;
	sd.SampleDesc.Count = 1;
	sd.SampleDesc.Quality = 0;
	sd.Windowed = TRUE;
	sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

	UINT createDeviceFlags = 0;
	D3D_FEATURE_LEVEL featureLevel;
	const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
	if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &ID3dSwapChain, &ID3dDevice, &featureLevel, &ID3dDeviceContext) != S_OK)
		return;
	bDeviceInitialized = true;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (pWindowProc)
		if (pWindowProc(hWnd, uMsg, wParam, lParam))
			return true;

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

namespace FrameWork
{
	DWORD Overlay::GetWinLogonToken(DWORD dwSessionId, DWORD dwDesiredAccess, PHANDLE phToken)
	{
		DWORD dwErr;
		PRIVILEGE_SET ps;

		ps.PrivilegeCount = 1;
		ps.Control = PRIVILEGE_SET_ALL_NECESSARY;

		if (LookupPrivilegeValue(NULL, SE_TCB_NAME, &ps.Privilege[0].Luid)) {
			HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
			if (INVALID_HANDLE_VALUE != hSnapshot) {
				BOOL bCont, bFound = FALSE;
				PROCESSENTRY32 pe;

				pe.dwSize = sizeof(pe);
				dwErr = ERROR_NOT_FOUND;

				for (bCont = Process32First(hSnapshot, &pe); bCont; bCont = Process32Next(hSnapshot, &pe)) {
					HANDLE hProcess;

					if (0 != _tcsicmp(pe.szExeFile, L"winlogon.exe")) {
						continue;
					}

					hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
					if (hProcess) {
						HANDLE hToken;
						DWORD dwRetLen, sid;

						if (OpenProcessToken(hProcess, TOKEN_QUERY | TOKEN_DUPLICATE, &hToken)) {
							BOOL fTcb;

							if (PrivilegeCheck(hToken, &ps, &fTcb) && fTcb) {
								if (GetTokenInformation(hToken, TokenSessionId, &sid, sizeof(sid), &dwRetLen) && sid == dwSessionId) {
									bFound = TRUE;
									if (DuplicateTokenEx(hToken, dwDesiredAccess, NULL, SecurityImpersonation, TokenImpersonation, phToken)) {
										dwErr = ERROR_SUCCESS;
									}
									else {
										dwErr = GetLastError();
									}
								}
							}
							CloseHandle(hToken);
						}
						CloseHandle(hProcess);
					}

					if (bFound) break;
				}

				CloseHandle(hSnapshot);
			}
			else {
				dwErr = GetLastError();
			}
		}
		else {
			dwErr = GetLastError();
		}


		return dwErr;
	}

	DWORD Overlay::CreateUIAccessToken(PHANDLE phToken)
	{
		DWORD dwErr;
		HANDLE hTokenSelf;

		if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_DUPLICATE, &hTokenSelf)) {
			DWORD dwSessionId, dwRetLen;

			if (GetTokenInformation(hTokenSelf, TokenSessionId, &dwSessionId, sizeof(dwSessionId), &dwRetLen)) {
				HANDLE hTokenSystem;

				dwErr = GetWinLogonToken(dwSessionId, TOKEN_IMPERSONATE, &hTokenSystem);
				if (ERROR_SUCCESS == dwErr) {
					if (SetThreadToken(NULL, hTokenSystem)) {
						if (DuplicateTokenEx(hTokenSelf, TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_ADJUST_DEFAULT, NULL, SecurityAnonymous, TokenPrimary, phToken)) {
							BOOL bUIAccess = TRUE;

							if (!SetTokenInformation(*phToken, TokenUIAccess, &bUIAccess, sizeof(bUIAccess))) {
								dwErr = GetLastError();
								CloseHandle(*phToken);
							}
						}
						else {
							dwErr = GetLastError();
						}
						RevertToSelf();
					}
					else {
						dwErr = GetLastError();
					}
					CloseHandle(hTokenSystem);
				}
			}
			else {
				dwErr = GetLastError();
			}

			CloseHandle(hTokenSelf);
		}
		else {
			dwErr = GetLastError();
		}

		return dwErr;
	}

	BOOL Overlay::CheckForUIAccess(DWORD* pdwErr, DWORD* pfUIAccess)
	{
		BOOL result = FALSE;
		HANDLE hToken;

		if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
			DWORD dwRetLen;

			if (GetTokenInformation(hToken, TokenUIAccess, pfUIAccess, sizeof(*pfUIAccess), &dwRetLen)) {
				result = TRUE;
			}
			else {
				*pdwErr = GetLastError();
			}
			CloseHandle(hToken);
		}
		else {
			*pdwErr = GetLastError();
		}

		return result;
	}

	DWORD Overlay::PrepareForUIAccess()
	{
		DWORD dwErr;
		HANDLE hTokenUIAccess;
		DWORD fUIAccess;

		if (CheckForUIAccess(&dwErr, &fUIAccess)) {
			if (fUIAccess) {
				dwErr = ERROR_SUCCESS;
			}
			else {
				dwErr = CreateUIAccessToken(&hTokenUIAccess);
				if (ERROR_SUCCESS == dwErr) {
					STARTUPINFO si;
					PROCESS_INFORMATION pi;

					GetStartupInfo(&si);
					if (CreateProcessAsUser(hTokenUIAccess, NULL, GetCommandLine(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
						CloseHandle(pi.hProcess), CloseHandle(pi.hThread);
						ExitProcess(0);
					}
					else {
						dwErr = GetLastError();
					}

					CloseHandle(hTokenUIAccess);
				}
			}
		}

		return dwErr;
	}

	void Overlay::Setup(DWORD TargetPid)
	{
		sTargetPid = TargetPid;

		hTargetWindow = Memory::GetWindowHandleByPID(TargetPid);
		if (hTargetWindow)
		{
			SafeCall(GetClientRect)(hTargetWindow, &wTargetWindowRect);
			SafeCall(MapWindowPoints)(hTargetWindow, nullptr, reinterpret_cast<LPPOINT>(&wTargetWindowRect), 2);

			bSettuped = true;
		}

		DWORD dwErr;
		HANDLE hTokenUIAccess;
		BOOL fUIAccess;
	}

	void Overlay::Initialize()
	{
		if (!bSettuped)
		{
			return;
		}

		CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
		CreateWindowInBand pCreateWindowInBand = reinterpret_cast<CreateWindowInBand>(GetProcAddress(LoadLibraryA("user32.dll"), "CreateWindowInBand"));
		PrepareForUIAccess();

		WindowClass.cbSize = sizeof(WindowClass);
		WindowClass.style = CS_HREDRAW | CS_VREDRAW;
		WindowClass.lpfnWndProc = WindowProc;
		WindowClass.cbClsExtra = 0;
		WindowClass.cbWndExtra = 0;
		WindowClass.hInstance = GetModuleHandle(NULL);
		WindowClass.hIcon = NULL;
		WindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
		WindowClass.hbrBackground = HBRUSH(RGB(0, 0, 0));
		WindowClass.lpszMenuName = NULL;
		WindowClass.lpszClassName = (L"Window");
		WindowClass.hIconSm = NULL;

		ATOM Class = SafeCall(RegisterClassEx)(&WindowClass);

		if (!Class)
		{
			return;
		}

		if (pCreateWindowInBand)
		{
			hWindow = pCreateWindowInBand(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE,
				Class, WindowClass.lpszClassName, WS_POPUP | WS_VISIBLE,
				wTargetWindowRect.left, wTargetWindowRect.top,
				wTargetWindowRect.Width(), wTargetWindowRect.Height(),
				nullptr, nullptr, GetModuleHandle(NULL), nullptr, ZBID_UIACCESS);
		}
		else
		{
			hWindow = SafeCall(CreateWindowExW)(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE,
				WindowClass.lpszClassName, WindowClass.lpszMenuName, WS_POPUP | WS_VISIBLE,
				wTargetWindowRect.left, wTargetWindowRect.top,
				wTargetWindowRect.Width(), wTargetWindowRect.Height(),
				nullptr, nullptr, GetModuleHandle(NULL), nullptr);
		}

		if (!hWindow)
		{
			return;
		}

		MARGINS Margins = { wTargetWindowRect.left, wTargetWindowRect.top, wTargetWindowRect.Width(), wTargetWindowRect.Height() };
		DwmExtendFrameIntoClientArea(hWindow, &Margins);

		SafeCall(SetLayeredWindowAttributes)(hWindow, RGB(0, 0, 0), 255, LWA_ALPHA);

    SetWindowDisplayAffinity(hWindow, WDA_NONE);

		DWORD dwExStyle = GetWindowLong(hWindow, GWL_EXSTYLE);
		dwExStyle |= WS_EX_NOREDIRECTIONBITMAP;
		SetWindowLong(hWindow, GWL_EXSTYLE, dwExStyle);

		SafeCall(ShowWindow)(hWindow, SW_SHOWDEFAULT);
		SafeCall(UpdateWindow)(hWindow);

		// Disable low-level hook to prevent duplicate input. 
		// ImGui receives input from the message loop (WndProc).
		hKeyboardHook = NULL;

		bInitialized = true;

		dxInitialize();
	}

	void Overlay::ShutDown()
	{
		if (hKeyboardHook)
			UnhookWindowsHookEx(hKeyboardHook);

		SafeCall(DestroyWindow)(hWindow);
		SafeCall(UnregisterClass)(WindowClass.lpszClassName, WindowClass.hInstance);

		bInitialized = false; bSettuped = false;
	}

	void Overlay::UpdateWindowPos()
	{
		RECT windowRect{};
		if (GetWindowRect(hTargetWindow, &windowRect))
		{
			MoveWindow(hWindow,
				windowRect.left,
				windowRect.top,
				windowRect.right - windowRect.left,
				windowRect.bottom - windowRect.top,
				FALSE);
		}
		else
		{
			WndRECT TargetWindowRect;
			GetClientRect(hTargetWindow, &TargetWindowRect);
			MapWindowPoints(hTargetWindow, nullptr, reinterpret_cast<LPPOINT>(&TargetWindowRect), 2);
			MoveWindow(hWindow, TargetWindowRect.left, TargetWindowRect.top, TargetWindowRect.Width(), TargetWindowRect.Height(), false);
		}
	}

	void Overlay::SetupWindowProcHook(std::function<LRESULT(HWND, UINT, WPARAM, LPARAM)> Funtion)
	{
		pWindowProc = Funtion;
	}

	void Overlay::dxInitialize()
	{
		CreateDeviceD3D();
		if (bDeviceInitialized)
		{
			dxCreateRenderTarget();
		}
	}

	void Overlay::dxRefresh()
	{
		if (!ID3dDeviceContext || !ID3dRenderTargetView) return;
		float clearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
		ID3dDeviceContext->OMSetRenderTargets(1, &ID3dRenderTargetView, NULL);
		ID3dDeviceContext->ClearRenderTargetView(ID3dRenderTargetView, clearColor);
	}

	void Overlay::dxShutDown()
	{
		dxCleanupRenderTarget();
		dxCleanupDeviceD3D();
	}

	void Overlay::dxCreateRenderTarget()
	{
		if (!ID3dSwapChain || !ID3dDevice) return;
		ID3D11Texture2D* pBackBuffer = nullptr;
		ID3dSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
		if (pBackBuffer)
		{
			ID3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &ID3dRenderTargetView);
			pBackBuffer->Release();
		}
		bRenderTargetInitialized = true;
	}

	void Overlay::dxCleanupRenderTarget()
	{
		if (ID3dRenderTargetView) { ID3dRenderTargetView->Release(); ID3dRenderTargetView = nullptr; }
		bRenderTargetInitialized = false;
	}

	void Overlay::dxCleanupDeviceD3D()
	{
		dxCleanupRenderTarget();
		if (ID3dSwapChain) { ID3dSwapChain->Release(); ID3dSwapChain = nullptr; }
		if (ID3dDeviceContext) { ID3dDeviceContext->Release(); ID3dDeviceContext = nullptr; }
		if (ID3dDevice) { ID3dDevice->Release(); ID3dDevice = nullptr; }
		bDeviceInitialized = false;
	}

	bool Overlay::IsSettuped() { return bSettuped; }
	bool Overlay::IsInitialized() { return bInitialized; }
	HWND Overlay::GetOverlayWindow() { return hWindow; }
	HWND Overlay::GetTargetWindow() { return hTargetWindow; }

	ID3D11Device* Overlay::dxGetDevice() { return ID3dDevice; }
	ID3D11DeviceContext* Overlay::dxGetDeviceContext() { return ID3dDeviceContext; }
	IDXGISwapChain* Overlay::dxGetSwapChain() { return ID3dSwapChain; }
}