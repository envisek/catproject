#define IDI_UPDATER_ICON 101 
//jebac skidow pozdrawiam :3
 