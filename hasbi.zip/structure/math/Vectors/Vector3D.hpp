#pragma once












#include <cmath>
#include <algorithm>
#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

struct Vector3D {
    float x{0.0f}, y{0.0f}, z{0.0f};

    inline Vector3D() = default;
    inline Vector3D(float X, float Y, float Z) : x(X), y(Y), z(Z) {}

    inline float& operator[](size_t i) { return (&x)[i]; }
    inline float operator[](size_t i) const { return (&x)[i]; }

    inline float* Base() { return &x; }
    inline const float* Base() const { return &x; }

    inline Vector3D operator-() const { return Vector3D(-x, -y, -z); }

    inline Vector3D& operator+=(const Vector3D& v) { x += v.x; y += v.y; z += v.z; return *this; }
    inline Vector3D& operator-=(const Vector3D& v) { x -= v.x; y -= v.y; z -= v.z; return *this; }
    inline Vector3D& operator*=(float s) { x *= s; y *= s; z *= s; return *this; }
    inline Vector3D& operator/=(float s) { x /= s; y /= s; z /= s; return *this; }

    friend inline Vector3D operator+(Vector3D a, const Vector3D& b) { return a += b; }
    friend inline Vector3D operator-(Vector3D a, const Vector3D& b) { return a -= b; }
    friend inline Vector3D operator*(Vector3D v, float s) { return v *= s; }
    friend inline Vector3D operator/(Vector3D v, float s) { return v /= s; }
    friend inline Vector3D operator*(float s, Vector3D v) { return v *= s; }

    inline float Dot(const Vector3D& v) const { return x * v.x + y * v.y + z * v.z; }
    inline static float Dot(const Vector3D& a, const Vector3D& b) { return a.Dot(b); }

    inline Vector3D Cross(const Vector3D& v) const { return Vector3D(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x); }

    inline float Length() const { return std::sqrt(Dot(*this)); }
    inline float LengthSqr() const { return Dot(*this); }
    inline float Length2D() const { return std::sqrt(x * x + y * y); }

    inline Vector3D Normalize() const { Vector3D v = *this; float len = v.Length(); return len > 0 ? v / len : Vector3D(); }
    inline Vector3D Normalized() const { return Normalize(); }
    inline float NormalizeInPlace() { float len = Length(); if (len > 0) (*this) /= len; return len; }

    inline static float Distance(const Vector3D& a, const Vector3D& b) { return (a - b).Length(); }
    inline static float DistanceSqr(const Vector3D& a, const Vector3D& b) { return (a - b).LengthSqr(); }
    inline float DistTo(const Vector3D& v) const { return (*this - v).Length(); }
    inline float DistToSqr(const Vector3D& v) const { return (*this - v).LengthSqr(); }

    inline Vector3D Min(const Vector3D& v) const { return Vector3D(std::min(x, v.x), std::min(y, v.y), std::min(z, v.z)); }
    inline Vector3D Max(const Vector3D& v) const { return Vector3D(std::max(x, v.x), std::max(y, v.y), std::max(z, v.z)); }

    inline static Vector3D Zero() { return Vector3D(0.0f, 0.0f, 0.0f); }
};