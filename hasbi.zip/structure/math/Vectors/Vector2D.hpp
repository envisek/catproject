#pragma once












#include <cmath>
#include <algorithm>
#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

struct Vector2D {
    float x{0.0f}, y{0.0f};

    inline Vector2D() = default;
    inline Vector2D(float X, float Y) : x(X), y(Y) {}

    inline float& operator[](size_t i) { return i ? y : x; }
    inline float operator[](size_t i) const { return i ? y : x; }

    inline float* Base() { return &x; }
    inline const float* Base() const { return &x; }

    inline Vector2D operator-() const { return Vector2D(-x, -y); }

    inline Vector2D& operator+=(const Vector2D& v) { x += v.x; y += v.y; return *this; }
    inline Vector2D& operator-=(const Vector2D& v) { x -= v.x; y -= v.y; return *this; }
    inline Vector2D& operator*=(float s) { x *= s; y *= s; return *this; }
    inline Vector2D& operator/=(float s) { x /= s; y /= s; return *this; }

    friend inline Vector2D operator+(Vector2D a, const Vector2D& b) { return a += b; }
    friend inline Vector2D operator-(Vector2D a, const Vector2D& b) { return a -= b; }
    friend inline Vector2D operator*(Vector2D v, float s) { return v *= s; }
    friend inline Vector2D operator/(Vector2D v, float s) { return v /= s; }
    friend inline Vector2D operator*(float s, Vector2D v) { return v *= s; }

    inline float Dot(const Vector2D& v) const { return x * v.x + y * v.y; }
    inline static float Dot(const Vector2D& a, const Vector2D& b) { return a.Dot(b); }

    inline float Length() const { return std::sqrt(Dot(*this)); }
    inline float LengthSqr() const { return Dot(*this); }

    inline Vector2D Normalize() const { Vector2D v = *this; float len = v.Length(); return len > 0 ? v / len : Vector2D(); }
    inline float NormalizeInPlace() { float len = Length(); if (len > 0) (*this) /= len; return len; }

    inline static float Distance(const Vector2D& a, const Vector2D& b) { return (a - b).Length(); }
    inline static float DistanceSqr(const Vector2D& a, const Vector2D& b) { return (a - b).LengthSqr(); }

    inline Vector2D Min(const Vector2D& v) const { return Vector2D(std::min(x, v.x), std::min(y, v.y)); }
    inline Vector2D Max(const Vector2D& v) const { return Vector2D(std::max(x, v.x), std::max(y, v.y)); }

    inline static Vector2D Zero() { return Vector2D(0.0f, 0.0f); }
};