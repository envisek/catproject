#pragma once












#include <cmath>
#include <algorithm>
#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

struct Vector4D {
    float x{0.0f}, y{0.0f}, z{0.0f}, w{0.0f};

    inline Vector4D() = default;
    inline Vector4D(float X, float Y, float Z, float W) : x(X), y(Y), z(Z), w(W) {}

    inline float& operator[](size_t i) { return (&x)[i]; }
    inline float operator[](size_t i) const { return (&x)[i]; }

    inline float* Base() { return &x; }
    inline const float* Base() const { return &x; }

    inline Vector4D operator-() const { return Vector4D(-x, -y, -z, -w); }

    inline Vector4D& operator+=(const Vector4D& v) { x += v.x; y += v.y; z += v.z; w += v.w; return *this; }
    inline Vector4D& operator-=(const Vector4D& v) { x -= v.x; y -= v.y; z -= v.z; w -= v.w; return *this; }
    inline Vector4D& operator*=(float s) { x *= s; y *= s; z *= s; w *= s; return *this; }
    inline Vector4D& operator/=(float s) { x /= s; y /= s; z /= s; w /= s; return *this; }

    friend inline Vector4D operator+(Vector4D a, const Vector4D& b) { return a += b; }
    friend inline Vector4D operator-(Vector4D a, const Vector4D& b) { return a -= b; }
    friend inline Vector4D operator*(Vector4D v, float s) { return v *= s; }
    friend inline Vector4D operator/(Vector4D v, float s) { return v /= s; }
    friend inline Vector4D operator*(float s, Vector4D v) { return v *= s; }

    inline float Dot(const Vector4D& v) const { return x * v.x + y * v.y + z * v.z + w * v.w; }
    inline static float Dot(const Vector4D& a, const Vector4D& b) { return a.Dot(b); }

    inline float Length() const { return std::sqrt(Dot(*this)); }
    inline float LengthSqr() const { return Dot(*this); }

    inline Vector4D Normalize() const { Vector4D v = *this; float len = v.Length(); return len > 0 ? v / len : Vector4D(); }
    inline float NormalizeInPlace() { float len = Length(); if (len > 0) (*this) /= len; return len; }

    inline static float Distance(const Vector4D& a, const Vector4D& b) { return (a - b).Length(); }
    inline static float DistanceSqr(const Vector4D& a, const Vector4D& b) { return (a - b).LengthSqr(); }

    inline Vector4D Min(const Vector4D& v) const { return Vector4D(std::min(x, v.x), std::min(y, v.y), std::min(z, v.z), std::min(w, v.w)); }
    inline Vector4D Max(const Vector4D& v) const { return Vector4D(std::max(x, v.x), std::max(y, v.y), std::max(z, v.z), std::max(w, v.w)); }

    inline static Vector4D Zero() { return Vector4D(0.0f, 0.0f, 0.0f, 0.0f); }
};