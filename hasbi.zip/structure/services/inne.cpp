#include "inne.hpp"

#include <structure/includy.hpp>
#include <algorithm>
#include <winhttp.h>
#include <sstream>
#include <cstdio>
#include <memory>
#include <utility>
#include <windows.h>
#include <string>
#include <vector>
#include <TlHelp32.h>
#include <iostream>
#include "../ui/NlohmannJson.hpp"
#pragma comment(lib, "winhttp.lib")

namespace FrameWork
{
	int Misc::RandomInt(int Lower, int Max)
	{
		return (rand() % (Max - Lower + 1)) + Lower;
	}

	std::wstring Misc::RandomString(size_t Length)
	{
		auto Randchar = []() -> char
			{
				const char* Charset = xorstr_("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
				const size_t MaxIndex = (sizeof(Charset) - 1);
				return Charset[rand() % MaxIndex];
			};

		std::wstring Str(Length, 0);
		std::generate_n(Str.begin(), Length, Randchar);
		return Str;
	}

	std::string Misc::Wstring2String(std::wstring Input)
	{
		return std::string(Input.begin(), Input.end());
	}

	std::wstring Misc::String2WString(std::string Input)
	{
		return std::wstring(Input.begin(), Input.end());
	}

	void Misc::InitializeConsole()
	{
		SafeCall(AllocConsole)();
		freopen(xorstr_("CONIN$"), xorstr_("r"), stdin);
		freopen(xorstr_("CONOUT$"), xorstr_("w"), stdout);
		SafeCall(SetConsoleTitleA)(xorstr_("Debug Console"));
	}

	void Misc::ShutDownConsole()
	{
		SafeCall(FreeConsole)();
	}

	std::string Misc::DownloadServerInfo(std::wstring IP, int PORT)
	{
		std::wstring host = std::move(IP);
		std::wstring requestPath = xorstr_(L"/players.json");

		auto slashPos = host.find(L'/');
		if (slashPos != std::wstring::npos)
		{
			requestPath = host.substr(slashPos);
			host = host.substr(0, slashPos);

			if (!requestPath.empty() && requestPath.back() != L'/')
				requestPath += xorstr_(L"/");

			requestPath += xorstr_(L"players.json");
		}

		if (host.empty())
			return std::string();

		HINTERNET hSession = WinHttpOpen(xorstr_(L"A WinHTTP FiveM Request Program/1.0"), WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);

		if (hSession)
		{
			HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), PORT, 0);

			if (hConnect)
			{
				HINTERNET hRequest = WinHttpOpenRequest(hConnect, xorstr_(L"GET"), requestPath.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);

				if (hRequest)
				{
					if (WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0))
					{
						if (WinHttpReceiveResponse(hRequest, NULL)) 
						{
							DWORD dwSize = 0;
							DWORD dwDownloaded = 0;
							LPSTR pszOutBuffer;
							BOOL  bResults = FALSE;
							std::string Response;

							do 
							{
								dwSize = 0;
								if (WinHttpQueryDataAvailable(hRequest, &dwSize))
								{
									pszOutBuffer = new char[dwSize + 1];
									if (!pszOutBuffer)
									{
										dwSize = 0;
									}
									else
									{
										ZeroMemory(pszOutBuffer, dwSize + 1);

										if (WinHttpReadData(hRequest, (LPVOID)pszOutBuffer, dwSize, &dwDownloaded))
											Response.append(pszOutBuffer, dwDownloaded);
									}

									delete[] pszOutBuffer;
								}

							} while (dwSize > 0);

							std::string result = Response;
							WinHttpCloseHandle(hRequest);
							WinHttpCloseHandle(hConnect);
							WinHttpCloseHandle(hSession);
							return result;
						}
					}

					WinHttpCloseHandle(hRequest);
				}

				WinHttpCloseHandle(hConnect);
			}

			WinHttpCloseHandle(hSession);
		}

		return std::string();
	}

	RTL_OSVERSIONINFOW Misc::GetRealOSVersion()
	{
		HMODULE hMod = SafeCall(GetModuleHandleW)(xorstr_(L"ntdll.dll"));
		if (hMod)
		{
			RtlGetVersionPtr fxPtr = (RtlGetVersionPtr)SafeCall(GetProcAddress)(hMod, xorstr_("RtlGetVersion"));
			if (fxPtr != nullptr)
			{
				RTL_OSVERSIONINFOW rovi = { 0 };
				rovi.dwOSVersionInfoSize = sizeof(rovi);
				if (fxPtr(&rovi) == 0x00000000)
				{
					return rovi;
				}
			}
		}
		RTL_OSVERSIONINFOW rovi = { 0 };
		return rovi;
	}

	std::string Misc::GetWindowsFullBuildNumber()
	{
		DWORD Dummy;
		DWORD VersionSize = SafeCall(GetFileVersionInfoSizeA)(xorstr_("kernel32.dll"), &Dummy);
		if (VersionSize == 0)
			return NULL;

		std::unique_ptr<BYTE[]> pBuffer(new BYTE[VersionSize]);
		if (!SafeCall(GetFileVersionInfoA)(xorstr_("kernel32.dll"), 0, VersionSize, pBuffer.get()))
			return NULL;

		VS_FIXEDFILEINFO* pFileInfo;
		UINT VersionLength;
		if (!SafeCall(VerQueryValueA)(pBuffer.get(), xorstr_("\\"), reinterpret_cast<void**>(&pFileInfo), &VersionLength))
			return NULL;

		std::stringstream aa;

		aa << HIWORD(pFileInfo->dwProductVersionMS) << xorstr_(".") << LOWORD(pFileInfo->dwProductVersionMS) << xorstr_(".") << HIWORD(pFileInfo->dwProductVersionLS) << xorstr_(".") << LOWORD(pFileInfo->dwProductVersionLS);

		return aa.str();
	}

	std::string Misc::GetHWID() {
		char buffer[128];
		FILE* pipe = _popen(xorstr_("powershell -Command \"(Get-WmiObject Win32_ComputerSystemProduct).UUID\""), xorstr_("r"));
		if (!pipe) return xorstr_("");
		std::string result = xorstr_("");
		while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
			result += buffer;
		}
		_pclose(pipe);
		result.erase(std::remove(result.begin(), result.end(), '\n'), result.end());
		result.erase(std::remove(result.begin(), result.end(), '\r'), result.end());
		return result;
	}

	time_t Misc::GetNetworkTime()
	{
		DWORD dwSize = 0;
		DWORD dwDownloaded = 0;
		LPSTR pszOutBuffer;
		BOOL  bResults = FALSE;
		HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;
		time_t currentTime = 0;

		hSession = WinHttpOpen(L"Time Fetcher",
			WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
			WINHTTP_NO_PROXY_NAME,
			WINHTTP_NO_PROXY_BYPASS, 0);

		if (hSession)
			hConnect = WinHttpConnect(hSession, L"timeapi.io",
				INTERNET_DEFAULT_HTTPS_PORT, 0);

		if (hConnect)
			hRequest = WinHttpOpenRequest(hConnect, L"GET", L"/api/Time/current/zone?timeZone=Europe/Warsaw",
				NULL, WINHTTP_NO_REFERER,
				WINHTTP_DEFAULT_ACCEPT_TYPES,
				WINHTTP_FLAG_SECURE);

		if (hRequest)
			bResults = WinHttpSendRequest(hRequest,
				WINHTTP_NO_ADDITIONAL_HEADERS, 0,
				WINHTTP_NO_REQUEST_DATA, 0,
				0, 0);

		if (bResults)
			bResults = WinHttpReceiveResponse(hRequest, NULL);

		std::string response;
		if (bResults)
		{
			do
			{
				dwSize = 0;
				if (!WinHttpQueryDataAvailable(hRequest, &dwSize))
					break;

				if (dwSize == 0)
					break;

				pszOutBuffer = new char[dwSize + 1];
				ZeroMemory(pszOutBuffer, dwSize + 1);

				if (!WinHttpReadData(hRequest, (LPVOID)pszOutBuffer,
					dwSize, &dwDownloaded))
				{
					delete[] pszOutBuffer;
					break;
				}
				
				response.append(pszOutBuffer);
				delete[] pszOutBuffer;

			} while (dwSize > 0);
		}
		
		if (!response.empty())
		{
			auto j = nlohmann::json::parse(response, nullptr, false);
			if (!j.is_discarded() && j.contains("dateTime"))
			{
				std::string dateTimeStr = j["dateTime"];
                std::tm t = {};
                std::stringstream ss(dateTimeStr);
                ss >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S");
                currentTime = _mkgmtime(&t);
			}
		}

		if (hRequest) WinHttpCloseHandle(hRequest);
		if (hConnect) WinHttpCloseHandle(hConnect);
		if (hSession) WinHttpCloseHandle(hSession);

		return currentTime;
	}

	std::string Misc::get_hwid() {
		DWORD volumeSerialNumber;
		if (GetVolumeInformation(L"C:\\", NULL, 0, &volumeSerialNumber, NULL, NULL, NULL, 0)) {
			return std::to_string(volumeSerialNumber);
		}
		return "";
	}

	std::string Misc::get_computer_name() {
		wchar_t computerName[MAX_COMPUTERNAME_LENGTH + 1];
		DWORD size = sizeof(computerName) / sizeof(computerName[0]);
		if (GetComputerNameW(computerName, &size)) {
			std::wstring ws(computerName);
			return std::string(ws.begin(), ws.end());
		}
		return "";
	}
}












