#pragma once

// Windows Libraries
#include <Windows.h>
#include <iostream>
#include <dwmapi.h>
#include <TlHelp32.h>

// Security
#include "protect/XorStr.hpp"
#include "protect/LazyImporter.hpp"

// Math
#include "math/Matrix4x4.hpp"
#include "math/Vectors/Vector2D.hpp"
#include "math/Vectors/Vector3D.hpp"
#include "math/Vectors/Vector4D.hpp"

// services
#include "services/inne.hpp"
#include "services/recall.hpp"

// Render
#include "render/overlay.hpp"
#include "render/gui.hpp"
#include "render/assets.hpp"
#include "render/assets/FontAwesome.hpp"
#include "render/assets/FontInter.hpp"

// ImGui
#include "ui/ImGui/imgui.h"
#include "ui/ImGui/imgui_impl_dx11.h"
#include "ui/ImGui/imgui_impl_win32.h"

// Nlohmann
#include "ui/NlohmannJson.hpp"

// DirectX Include
#include <d3d11.h>
#include <dxgi.h>


#define XorStr(str) xorstr_(str)
#define SafeCall(str) lzimpLI_FN(str)















