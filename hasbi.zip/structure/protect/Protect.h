#pragma once
#include <Windows.h>
#include <thread>
namespace Protect {
    inline void ProtectAll() {}
}















