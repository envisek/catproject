#include <Windows.h>
#include <thread>
#include <iostream>
#include <string>
#include <filesystem>
#include <random>
#include <sstream>

#include <ishowspeed/cheat.hpp>
#include <structure/includy.hpp>
#include <structure/services/inne.hpp>
#include <structure/ui/NlohmannJson.hpp>

#include <tchar.h>
#include <cstdlib>
#include <shellapi.h>
#include <curl/curl.h>
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "libcurl.lib")

#define CONSOLE_COLOR_INFO FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE
#define CONSOLE_COLOR_SUCCESS FOREGROUND_GREEN
#define CONSOLE_COLOR_ERROR FOREGROUND_RED
#define CONSOLE_COLOR_DEFAULT FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE
#define CONSOLE_COLOR_DARK_GRAY FOREGROUND_INTENSITY
#define CONSOLE_COLOR_CYAN FOREGROUND_BLUE | FOREGROUND_GREEN
#define CONSOLE_COLOR_YELLOW FOREGROUND_RED | FOREGROUND_GREEN
#define CONSOLE_COLOR_GRAY FOREGROUND_INTENSITY







static DWORD DuplicateWinloginToken(DWORD dwSessionId, DWORD dwDesiredAccess, PHANDLE phToken)
{
	DWORD dwErr;
	PRIVILEGE_SET ps;

	ps.PrivilegeCount = 1;
	ps.Control = PRIVILEGE_SET_ALL_NECESSARY;

	if (LookupPrivilegeValue(NULL, SE_TCB_NAME, &ps.Privilege[0].Luid)) {
		HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if (INVALID_HANDLE_VALUE != hSnapshot) {
			BOOL bCont, bFound = FALSE;
			PROCESSENTRY32 pe;

			pe.dwSize = sizeof(pe);
			dwErr = ERROR_NOT_FOUND;

			for (bCont = Process32First(hSnapshot, &pe); bCont; bCont = Process32Next(hSnapshot, &pe)) {
				HANDLE hProcess;

				if (0 != _tcsicmp(pe.szExeFile, xorstr_(L"winlogon.exe")))
				{
					continue;
				}

				hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
				if (hProcess) {
					HANDLE hToken;
					DWORD dwRetLen, sid;

					if (OpenProcessToken(hProcess, TOKEN_QUERY | TOKEN_DUPLICATE, &hToken)) {
						BOOL fTcb;

						if (PrivilegeCheck(hToken, &ps, &fTcb) && fTcb) {
							if (GetTokenInformation(hToken, TokenSessionId, &sid, sizeof(sid), &dwRetLen) && sid == dwSessionId) {
								bFound = TRUE;
								if (DuplicateTokenEx(hToken, dwDesiredAccess, NULL, SecurityImpersonation, TokenImpersonation, phToken)) {
									dwErr = ERROR_SUCCESS;
								}
								else {
									dwErr = GetLastError();
								}
							}
						}
						CloseHandle(hToken);
					}
					CloseHandle(hProcess);
				}

				if (bFound) break;
			}

			CloseHandle(hSnapshot);
		}
		else {
			dwErr = GetLastError();
		}
	}
	else {
		dwErr = GetLastError();
	}


	return dwErr;
}

static DWORD CreateUIAccessToken(PHANDLE phToken)
{
	DWORD dwErr;
	HANDLE hTokenSelf;

	if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_DUPLICATE, &hTokenSelf)) 
	{
		DWORD dwSessionId, dwRetLen;

		if (GetTokenInformation(hTokenSelf, TokenSessionId, &dwSessionId, sizeof(dwSessionId), &dwRetLen))
		{
			HANDLE hTokenSystem;

			dwErr = DuplicateWinloginToken(dwSessionId, TOKEN_IMPERSONATE, &hTokenSystem);
			if (ERROR_SUCCESS == dwErr)
			{
				if (SetThreadToken(NULL, hTokenSystem))
				{
					if (DuplicateTokenEx(hTokenSelf, TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_ADJUST_DEFAULT, NULL, SecurityAnonymous, TokenPrimary, phToken))
					{
						BOOL bUIAccess = TRUE;

						if (!SetTokenInformation(*phToken, TokenUIAccess, &bUIAccess, sizeof(bUIAccess)))
						{
							dwErr = GetLastError();
							CloseHandle(*phToken);
						}
					}
					else 
					{
						dwErr = GetLastError();
					}
					RevertToSelf();
				}
				else
				{
					dwErr = GetLastError();
				}
				CloseHandle(hTokenSystem);
			}
		}
		else
		{
			dwErr = GetLastError();
		}

		CloseHandle(hTokenSelf);
	}
	else 
	{
		dwErr = GetLastError();
	}

	return dwErr;
}

static BOOL CheckForUIAccess(DWORD* pdwErr, BOOL* pfUIAccess)
{
	BOOL result = FALSE;
	HANDLE hToken;

	if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
	{
		DWORD dwRetLen;

		if (GetTokenInformation(hToken, TokenUIAccess, pfUIAccess, sizeof(*pfUIAccess), &dwRetLen))
		{
			result = TRUE;
		}
		else 
		{
			*pdwErr = GetLastError();
		}
		CloseHandle(hToken);
	}
	else
	{
		*pdwErr = GetLastError();
	}

	return result;
}


DWORD WINAPI Unload()
{
	SafeCall(ExitProcess)(0);

	return TRUE;
}

std::string GenerateRandomTitle() {
    std::string chars = xorstr_("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, chars.length() - 1);
    
    std::string title;
    for (int i = 0; i < 15; i++) {
        title += chars[dis(gen)];
    }
    return title;
}

void SetConsoleColor(WORD color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void PrintColoredText(const char* text, WORD color) {
    SetConsoleColor(color);
    std::cout << text;
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
}

void PrintColored(const char* prefix, const char* text, WORD prefixColor, WORD textColor = CONSOLE_COLOR_DEFAULT) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, prefixColor);
    std::cout << prefix;
    SetConsoleTextAttribute(hConsole, textColor);
    std::cout << " " << text << std::endl;
}

void PrintASCIIArt() {
    SetConsoleColor(CONSOLE_COLOR_CYAN);
    std::cout << R"(
/$$$$$$$$ /$$                                         /$$$$$$$$
| $$_____/|__/                                        | $$_____/
| $$       /$$ /$$    /$$ /$$$$$$  /$$$$$$/$$$$       | $$       /$$$$$$$  /$$  /$$$$$$  /$$   /$$  /$$$$$$   /$$$$$$
| $$$$$   | $$|  $$  /$$//$$__  $$| $$_  $$_  $$      | $$$$$   | $$__  $$|__/ /$$__  $$| $$  | $$ /$$__  $$ /$$__  $$
| $$__/   | $$ \  $$/$$/| $$$$$$$$| $$ \ $$ \ $$      | $$__/   | $$  \ $$ /$$| $$  \ $$| $$  | $$| $$$$$$$$| $$  \__/
| $$      | $$  \  $$$/ | $$_____/| $$ | $$ | $$      | $$      | $$  | $$| $$| $$  | $$| $$  | $$| $$_____/| $$
| $$      | $$   \  $/  |  $$$$$$$| $$ | $$ | $$      | $$$$$$$$| $$  | $$| $$|  $$$$$$/|  $$$$$$$|  $$$$$$$| $$
|__/      |__/    \_/    \_______/|__/ |__/ |__/      |________/|__/  |__/| $$ \______/  \____  $$ \_______/|__/
                                                                     /$$  | $$           /$$  | $$
                                                                    |  $$$$$$/          |  $$$$$$/
                                                                     \______/            \______/
)" << std::endl;
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
}

void PrintMenu(int option = 0) {
    // "Enjoy FiveM your way!" - czerwony
    SetConsoleColor(CONSOLE_COLOR_ERROR);
    std::cout << xorstr_("Enjoy FiveM your way!") << std::endl;
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << std::endl;
    
    // [/] Last updated - nawiasy żółte, reszta domyślna
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_("/");
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_(" Last updated: 10/11/2025") << std::endl;
    
    // [/] Expiry - nawiasy żółte
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_("/");
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_(" Expiry: Never") << std::endl;
    
    // [/] Message - nawiasy żółte
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_("/");
    SetConsoleColor(CONSOLE_COLOR_YELLOW);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_(" Message: Owned by hasbi - https://discord.gg/TrashCrackNew") << std::endl;
    std::cout << std::endl;
    
    // [1] Load Driver - nawiasy szare
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 1) {
        std::cout << xorstr_("1");
    } else {
        std::cout << xorstr_("1");
    }
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 1) {
        std::cout << xorstr_(" Load Driver") << std::endl;
    } else {
        std::cout << xorstr_(" Load Driver") << std::endl;
    }
    
    // [2] Load Cheat - nawiasy szare
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 2) {
        std::cout << xorstr_("2");
    } else {
        std::cout << xorstr_("2");
    }
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 2) {
        std::cout << xorstr_(" Load Cheat") << std::endl;
    } else {
        std::cout << xorstr_(" Load Cheat") << std::endl;
    }
    
    // [3] Setup - nawiasy szare
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 3) {
        std::cout << xorstr_("3");
    } else {
        std::cout << xorstr_("3");
    }
    SetConsoleColor(CONSOLE_COLOR_GRAY);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    if (option == 3) {
        std::cout << xorstr_(" Setup") << std::endl;
    } else {
        std::cout << xorstr_(" Setup") << std::endl;
    }
    std::cout << std::endl;
    
    // [+] Select an option - nawiasy zielone
    SetConsoleColor(CONSOLE_COLOR_SUCCESS);
    std::cout << xorstr_("[");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_("+");
    SetConsoleColor(CONSOLE_COLOR_SUCCESS);
    std::cout << xorstr_("]");
    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
    std::cout << xorstr_(" Select an option: ");
}

bool IsFivemRunning() {
    return (FrameWork::Memory::GetProcessPidByName(L"FiveM_b2372_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2372_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2612_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2612_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2699_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2699_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2189_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2189_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2545_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2545_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2802_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2802_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2060_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2060_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2944_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b2944_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3095_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3095_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3323_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3323_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3407_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3407_GTAProcess.exe") ||
			FrameWork::Memory::GetProcessPidByName(L"FiveM_b3570_GameProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_b3570_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_GTAProcess.exe") ||
            FrameWork::Memory::GetProcessPidByName(L"FiveM_GameProcess.exe"));
}



int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow)
{
    DWORD dwErr = 0;
    BOOL fUIAccess = FALSE;

    if (CheckForUIAccess(&dwErr, &fUIAccess) && fUIAccess)
    {
        if (!IsFivemRunning()) {
            ExitProcess(0);
        }

        Cheat::Initialize();

        while (!g_Options.General.ShutDown)
        {
            Sleep(100);
        }
    }
    else
    {
        AllocConsole();
        FILE* f;
        freopen_s(&f, xorstr_("CONOUT$"), xorstr_("w"), stdout);
        freopen_s(&f, xorstr_("CONIN$"), xorstr_("r"), stdin);
        
        // Ustaw losowy tytuł okna
        std::string randomTitle = GenerateRandomTitle();
        SetConsoleTitleA(randomTitle.c_str());
        for (;;)
        {
            // Wyczyść konsolę i pokaż menu
            system(xorstr_("cls"));
            PrintASCIIArt();
            PrintMenu();

            int choice;
            std::cin >> choice;

            // Krótka pauza i przejście do widoku z nazwami
            Sleep(1000);
            system(xorstr_("cls"));
            PrintASCIIArt();

            SetConsoleColor(CONSOLE_COLOR_ERROR);
            std::cout << xorstr_("Enjoy FiveM your way!") << std::endl;
            SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << std::endl;

            SetConsoleColor(CONSOLE_COLOR_YELLOW);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("/"); SetConsoleColor(CONSOLE_COLOR_YELLOW); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Last updated: 10/11/2025") << std::endl;

            SetConsoleColor(CONSOLE_COLOR_YELLOW);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("/"); SetConsoleColor(CONSOLE_COLOR_YELLOW); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Expiry: Never") << std::endl;

            SetConsoleColor(CONSOLE_COLOR_YELLOW);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("/"); SetConsoleColor(CONSOLE_COLOR_YELLOW); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Message: Owned by hasbi - https://discord.gg/TrashCrackNew") << std::endl;
            std::cout << std::endl;

            SetConsoleColor(CONSOLE_COLOR_GRAY);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("1"); SetConsoleColor(CONSOLE_COLOR_GRAY); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Load Driver") << std::endl;

            SetConsoleColor(CONSOLE_COLOR_GRAY);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("2"); SetConsoleColor(CONSOLE_COLOR_GRAY); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Load Cheat") << std::endl;

            SetConsoleColor(CONSOLE_COLOR_GRAY);
            std::cout << xorstr_("["); SetConsoleColor(CONSOLE_COLOR_DEFAULT); std::cout << xorstr_("3"); SetConsoleColor(CONSOLE_COLOR_GRAY); std::cout << xorstr_("]"); SetConsoleColor(CONSOLE_COLOR_DEFAULT);
            std::cout << xorstr_(" Setup") << std::endl;
            std::cout << std::endl;

            switch (choice) {
                case 1:
                    // Load Driver
                    Sleep(1000);
                    system(xorstr_("cls"));
                    SetConsoleColor(CONSOLE_COLOR_SUCCESS);
                    std::cout << xorstr_("Driver successfully loaded!") << std::endl;
                    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                    Sleep(1000);
                    // powrót do pętli (menu)
                    continue;
                case 2:
                    // Load Cheat
                    Sleep(1000);
                    system(xorstr_("cls"));
                    if (!IsFivemRunning()) {
                        SetConsoleColor(CONSOLE_COLOR_ERROR);
                        std::cout << xorstr_("First open FiveM and after cheat...") << std::endl;
                        SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                        Sleep(3000);
                        ExitProcess(0);
                    }
                    SetConsoleColor(CONSOLE_COLOR_SUCCESS);
                    std::cout << xorstr_("Cheat successfully injected!") << std::endl;
                    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                    Sleep(1000);
                    
                    HANDLE hToken;
                    if (CreateUIAccessToken(&hToken) == ERROR_SUCCESS)
                    {
                        STARTUPINFOW si = { sizeof(si) };
                        PROCESS_INFORMATION pi;
                        wchar_t szPath[MAX_PATH];

                        GetModuleFileNameW(NULL, szPath, MAX_PATH);

                        if (CreateProcessAsUserW(hToken, szPath, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
                        {
                            CloseHandle(pi.hProcess);
                            CloseHandle(pi.hThread);
                        }
                        else
                        {
                            SetConsoleColor(CONSOLE_COLOR_ERROR);
                            std::cout << xorstr_("[!] Failed to create elevated process.") << std::endl;
                            SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                            Sleep(3000);
                        }
                        CloseHandle(hToken);
                    }
                    else
                    {
                        SetConsoleColor(CONSOLE_COLOR_ERROR);
                        std::cout << xorstr_("[!] Failed to create UI Access token.") << std::endl;
                        SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                        Sleep(3000);
                    }
                    ExitProcess(0);
                    break;
                case 3: {
                    // Setup - otwórz przeglądarkę i wróć do menu po sekundzie
                    Sleep(1000);
                    std::wstring url = FrameWork::Misc::String2WString(xorstr_("https://platnosc.space"));
                    ShellExecuteW(NULL, xorstr_(L"open"), url.c_str(), NULL, NULL, SW_SHOWNORMAL);
                    Sleep(1000);
                    // powrót do menu
                    continue;
                }
                default:
                    SetConsoleColor(CONSOLE_COLOR_ERROR);
                    std::cout << xorstr_("\n[!] Invalid option") << std::endl;
                    SetConsoleColor(CONSOLE_COLOR_DEFAULT);
                    Sleep(2000);
                    // powrót do menu
                    continue;
            }
        }
    }

    return 0;
}